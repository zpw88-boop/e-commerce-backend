// com/kingso/ecommerce/module/procurement/entity/ProcurementOrder.java
package com.kingso.ecommerce.module.procurement.entity;

import java.time.LocalDateTime;

import lombok.Data;

/**
 * 采购订单实体类（映射tb_procurement_order表）
 */
@Data
public class ProcurementOrder {
    /**
     * 订单ID（主键，自增）
     */
    private Long id;

    /**
     * 采购单号
     */
    private String procurementNo;

    /**
     * 制单时间
     */
    private LocalDateTime createTime;

    /**
     * 操作员ID
     */
    private Long operatorId;

    /**
     * 入库仓库ID
     */
    private Long warehouseId;

    /**
     * 海关文件地址
     */
    private String customsFileUrl;

    /**
     * 备注信息
     */
    private String remark;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
    private String warehouseName;
    private String operatorName;

}