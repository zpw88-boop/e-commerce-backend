package com.kingso.ecommerce.module.stock.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.kingso.ecommerce.module.stock.dto.StockDTO;
import com.kingso.ecommerce.module.stock.entity.Stock;

/**
 * 库存Mapper
 */
public interface StockMapper {

    /**
     * 新增库存
     */
    int insert(Stock stock);

    /**
     * 根据ID更新库存
     */
    int updateById(Stock stock);

    /**
     * 根据ID删除库存
     */
    int deleteById(@Param("id") Long id);

    /**
     * 根据ID查询库存（基础信息）
     */
    Stock selectById(@Param("id") Long id);

    /**
     * 根据ID查询库存（含商品/仓库名称）
     */
    StockDTO selectDTOById(@Param("id") Long id);

    /**
     * 分页查询库存列表（含商品/仓库名称）
     */
    List<StockDTO> selectPage(Map<String, Object> params);

    /**
     * 查询库存总数（适配分页） - 修改方法签名
     */
    Integer selectTotal(Map<String, Object> params);

    /**
     * 校验商品是否存在（上架状态）
     */
    int checkGoodsExist(@Param("goodsId") Long goodsId);

    /**
     * 校验仓库是否存在且启用
     */
    Integer checkWarehouseEnable(@Param("warehouseId") Long warehouseId);

    /**
     * 校验商品库存是否已存在（唯一索引）
     */
    Integer checkGoodsStockExist(
        @Param("goodsId") Long goodsId,
        @Param("warehouseId") Long warehouseId
    );
    
    /**
     * 根据商品ID和仓库ID查询库存
     */
    Stock selectByGoodsIdAndWarehouseId(
        @Param("goodsId") Long goodsId,
        @Param("warehouseId") Long warehouseId
    );
    
    /**
     * 按商品ID+仓库ID增量更新库存数量
     */
    int updateStockNumByGoodsIdAndWarehouseId(
        @Param("goodsId") Long goodsId,
        @Param("warehouseId") Long warehouseId,
        @Param("increment") Integer increment
    );
    /**
     * 根据商品ID和仓库ID调整库存
     * @param paramMap 包含goodsId、warehouseId、changeQuantity
     * @return 受影响的行数
     */
    int updateInventorybyId(Map<String, Object> paramMap);
}