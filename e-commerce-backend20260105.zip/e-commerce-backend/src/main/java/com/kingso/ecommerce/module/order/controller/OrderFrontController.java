package com.kingso.ecommerce.module.order.controller;

import java.util.Map;

import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kingso.ecommerce.common.result.Result;
import com.kingso.ecommerce.module.order.dto.OrderAddDTO;
import com.kingso.ecommerce.module.order.dto.OrderQueryDTO;
import com.kingso.ecommerce.module.order.entity.Order;
import com.kingso.ecommerce.module.order.service.OrderService;

/**
 * 前台订单接口控制器
 * 接口前缀：/api/front/order
 */
@RestController
@RequestMapping("/api/front/order")
public class OrderFrontController {

    private final OrderService orderService;

    public OrderFrontController(OrderService orderService) {
        this.orderService = orderService;
    }

    /**
     * 新增订单（含明细）
     */
    @PostMapping("/add")
    public Result<Boolean> addOrder(
            @RequestBody @Validated OrderAddDTO addDTO,
            BindingResult bindingResult
    ) {
        if (bindingResult.hasErrors()) {
            return Result.fail(buildErrorMsg(bindingResult));
        }
        orderService.addOrder(addDTO);
        return Result.success(true, "订单创建成功");
    }

    /**
     * 根据ID查询订单（不含明细）
     */
    @GetMapping("/{id}")
    public Result<Order> getOrderById(@PathVariable Long id) {
        if (id == null || id <= 0) {
            return Result.fail("订单ID必须为正整数");
        }
        Order order = orderService.getOrderById(id);
        return Result.success(order, "订单查询成功");
    }

    /**
     * 根据ID查询订单及明细（关联查询）
     */
    @GetMapping("/withItem/{id}")
    public Result<Map<String, Object>> getOrderWithItemById(@PathVariable Long id) {
        if (id == null || id <= 0) {
            return Result.fail("订单ID必须为正整数");
        }
        Map<String, Object> result = orderService.getOrderWithItemById(id);
        return Result.success(result, "订单及明细查询成功");
    }

    /**
     * 根据订单编号查询订单
     */
    @GetMapping("/orderNo/{orderNo}")
    public Result<Order> getOrderByOrderNo(@PathVariable String orderNo) {
        if (orderNo == null || orderNo.trim().isEmpty()) {
            return Result.fail("订单编号不能为空");
        }
        Order order = orderService.getOrderByOrderNo(orderNo);
        return Result.success(order, "订单查询成功");
    }

    /**
     * 分页查询订单列表（多条件筛选）
     */
    @GetMapping("/page")
    public Result<Map<String, Object>> getOrderPage(OrderQueryDTO queryDTO) {
        Map<String, Object> pageResult = orderService.getOrderPage(queryDTO);
        return Result.success(pageResult, "订单列表查询成功");
    }

    /**
     * 取消订单（状态改为9：已取消）
     */
    @PutMapping("/cancel/{id}")
    public Result<Boolean> cancelOrder(@PathVariable Long id) {
        if (id == null || id <= 0) {
            return Result.fail("订单ID必须为正整数");
        }
        orderService.cancelOrder(id);
        return Result.success(true, "订单取消成功");
    }

    /**
     * 确认收货（状态改为2：待收货）
     */
    @PutMapping("/confirm/{id}")
    public Result<Boolean> confirmOrder(@PathVariable Long id) {
        if (id == null || id <= 0) {
            return Result.fail("订单ID必须为正整数");
        }
        orderService.confirmOrder(id);
        return Result.success(true, "确认收货成功");
    }

    /**
     * 删除订单（状态改为8：已删除）
     */
    @DeleteMapping("/delete/{id}")
    public Result<Boolean> deleteOrder(@PathVariable Long id) {
        if (id == null || id <= 0) {
            return Result.fail("订单ID必须为正整数");
        }
        orderService.deleteOrderStatus(id);
        return Result.success(true, "订单删除成功");
    }

    /**
     * 已完成订单（状态改为3：已完成）
     */
    @PutMapping("/complete/{id}")
    public Result<Boolean> completeOrder(@PathVariable Long id) {
        if (id == null || id <= 0) {
            return Result.fail("订单ID必须为正整数");
        }
        orderService.completeOrder(id);
        return Result.success(true, "订单已完成");
    }

    /**
     * 构建参数校验错误信息
     */
    private String buildErrorMsg(BindingResult bindingResult) {
        return bindingResult.getFieldErrors().stream()
                .map(FieldError::getDefaultMessage)
                .reduce((msg1, msg2) -> msg1 + "；" + msg2)
                .orElse("参数校验失败");
    }
}

