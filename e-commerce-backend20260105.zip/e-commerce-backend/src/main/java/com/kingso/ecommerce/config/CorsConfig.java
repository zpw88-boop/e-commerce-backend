package com.kingso.ecommerce.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * 跨域配置
 */
@Configuration
public class CorsConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        // 允许所有路径跨域
        registry.addMapping("/**")
                // 当 allowCredentials(true) 时，必须指定具体域名，不能使用 "*"
                // 允许两个 React 前端应用访问：3000 和 3080 端口
                .allowedOrigins("http://localhost:3000", "http://localhost:3080")
                // 允许的请求方法
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH")
                // 允许的请求头
                .allowedHeaders("*")
                // 是否允许携带Cookie（需要与具体域名配合使用）
                .allowCredentials(true)
                // 预检请求有效期（秒）
                .maxAge(3600);
    }
}