// com/kingso/ecommerce/module/procurement/service/ProcurementOrderService.java
package com.kingso.ecommerce.module.procurement.service;

import java.util.List;
import java.util.Map;

import com.kingso.ecommerce.module.procurement.dto.ProcurementOrderAddDTO;
import com.kingso.ecommerce.module.procurement.dto.ProcurementOrderQueryDTO;
import com.kingso.ecommerce.module.procurement.entity.ProcurementOrder;
import com.kingso.ecommerce.module.procurement.entity.ProcurementOrderItem;

/**
 * 采购订单服务接口
 */
public interface ProcurementOrderService {
    /**
     * 创建采购订单
     */
    void createProcurementOrder(ProcurementOrderAddDTO addDTO);

    /**
     * 根据ID查询采购订单
     */
    ProcurementOrder getById(Long id);

    /**
     * 根据采购单号查询采购订单
     */
    ProcurementOrder getByProcurementNo(String procurementNo);

    /**
     * 分页查询采购订单列表
     */
    Map<String, Object> getPage(ProcurementOrderQueryDTO queryDTO);

    /**
     * 根据ID查询采购订单及明细
     */
    Map<String, Object> getWithItemsById(Long id);
    /**
     * 条码模糊查询采购明细（参考用）
     */
    List<ProcurementOrderItem> queryItemByBarcodeLike(String barcode);
    
}