package com.kingso.ecommerce.module.goodsFront.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.Data;

@Data
public class GoodsFront {

    private Long id;
    private String goodsId;

    private String goodsName;

    private BigDecimal goodsPrice;

    private Integer stock;

    private Long categoryId;

    private String goodsImg;

    private Integer status;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;

    private String barCode;
    private Integer stockNum;
    private Long warehouseId;
    private String warehouseName;
    private String warehouseArea;
}