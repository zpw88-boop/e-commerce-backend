package com.kingso.ecommerce.module.procurement.dto;

import lombok.Data;
@Data
public class ProcurementOrderItemQueryDTO {
    /** 条码（模糊查询） */
    private String barcode;

    /** 页码/每页条数 */
    private Integer pageNum = 1;
    private Integer pageSize = 10;
    
}
