package com.kingso.ecommerce.module.goods.controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.kingso.ecommerce.common.result.Result;
import com.kingso.ecommerce.module.goods.dto.GoodsAddDTO;
import com.kingso.ecommerce.module.goods.dto.GoodsQueryDTO;
import com.kingso.ecommerce.module.goods.service.IGoodsService;

import jakarta.validation.Valid;

/**
 * 商品后台管理API（RESTful）
 */
@RestController
@RequestMapping("/api/admin/goods")
public class AdminGoodsController {
    
    // 构造器注入（Spring最佳实践）
    private final IGoodsService goodsService;

    public AdminGoodsController(IGoodsService goodsService) {
        this.goodsService = goodsService;
    }
    
    /**
     * 商品图片上传接口（对接前端 /api/admin/goods/upload）
     * @param file 上传的图片文件（参数名与前端formData的key一致）
     * @return 图片访问URL
     */
    @PostMapping("/upload")
    public Result<String> uploadGoodsImg(@RequestParam("file") MultipartFile file) {
        try {
            String imgUrl = goodsService.uploadGoodsImg(file);
            return Result.success(imgUrl, "图片上传成功");
        } catch (RuntimeException e) { // 仅保留父类异常，已涵盖所有子类异常
            return Result.error(e.getMessage()); // 现在能找到对应的error方法
        }
    }

    // 新增商品（POST）：修改返回值为Result<String>
    @PostMapping
    public Result<String> addGoods(@Valid @RequestBody GoodsAddDTO goodsAddDTO) {
        goodsService.addGoods(goodsAddDTO);
        return Result.success("新增商品成功"); // 此时泛型匹配，无报错
    }

    

    // 修改商品（PUT）：修改返回值为Result<String>
    @PutMapping("/{id}")
    public Result<String> updateGoods(@PathVariable Long id, @Valid @RequestBody GoodsAddDTO goodsAddDTO) {
        // 校验商品ID
        if (id == null || id <= 0) {
            return Result.fail("商品ID必须为正整数");
        }
        goodsService.updateGoods(id, goodsAddDTO);
        return Result.success("修改商品成功");
    }

    // 上下架商品（PUT）：修改返回值为Result<String>
    @PutMapping("/status/{id}")
    public Result<String> updateGoodsStatus(@PathVariable Long id, @RequestParam Integer status) {
        // 校验参数
        if (id == null || id <= 0) {
            return Result.fail("商品ID必须为正整数");
        }
        if (status == null || (status != 0 && status != 1)) {
            return Result.fail("商品状态只能是0（下架）或1（上架）");
        }
        goodsService.updateGoodsStatus(id, status);
        return Result.success("商品状态更新成功");
    }

    // 删除商品（DELETE）：修改返回值为Result<String>
    @DeleteMapping("/{id}")
    public Result<String> deleteGoods(@PathVariable Long id) {
        // 校验商品ID
        if (id == null || id <= 0) {
            return Result.fail("商品ID必须为正整数");
        }
        goodsService.deleteGoods(id);
        return Result.success("删除商品成功");
    }

    // 分页查询商品（GET）
    @GetMapping("/page")
    public Result<?> pageGoods(GoodsQueryDTO goodsQueryDTO) {
        return Result.success(goodsService.pageGoods(goodsQueryDTO), "商品分页查询成功");
    }

    // 查询商品详情（GET）
    @GetMapping("/{id}")
    public Result<?> getGoodsDetail(@PathVariable Long id) {
        // 校验商品ID
        if (id == null || id <= 0) {
            return Result.fail("商品ID必须为正整数");
        }
        return Result.success(goodsService.getGoodsById(id), "商品详情查询成功");
    }
    
}