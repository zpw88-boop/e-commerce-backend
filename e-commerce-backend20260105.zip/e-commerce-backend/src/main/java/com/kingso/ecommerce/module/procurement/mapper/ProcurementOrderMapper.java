package com.kingso.ecommerce.module.procurement.mapper;

import com.kingso.ecommerce.module.procurement.dto.ProcurementOrderQueryDTO;
import com.kingso.ecommerce.module.procurement.entity.ProcurementOrder;
import org.apache.ibatis.annotations.Mapper;
import java.util.List;

/**
 * 采购订单Mapper接口
 */
@Mapper
public interface ProcurementOrderMapper {
    /**
     * 新增采购订单
     */
    void insert(ProcurementOrder procurementOrder);

    /**
     * 根据ID查询采购订单
     */
    ProcurementOrder selectById(Long id);

    /**
     * 根据采购单号查询采购订单
     */
    ProcurementOrder selectByProcurementNo(String procurementNo);

    /**
     * 分页查询采购订单列表
     */
    List<ProcurementOrder> selectPage(ProcurementOrderQueryDTO queryDTO);

    /**
     * 查询采购订单总数
     */
    Integer selectTotal(ProcurementOrderQueryDTO queryDTO);
}