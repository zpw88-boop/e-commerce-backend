// com/kingso/ecommerce/module/order/dto/OrderAddDTO.java
package com.kingso.ecommerce.module.order.dto;

import java.math.BigDecimal;
import java.util.List;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

/**
 * 新增订单参数DTO（与tb_order表字段对应，含明细列表）
 */
@Data
public class OrderAddDTO {
    /**
     * 用户ID（必传）
     */
    @NotNull(message = "用户ID不能为空")
    @Positive(message = "用户ID必须为正整数")
    private Long userId;

    /**
     * 订单总金额（必传，大于0）
     */
    @NotNull(message = "订单总金额不能为空")
    @Positive(message = "订单总金额必须大于0")
    private BigDecimal totalAmount;

    /**
     * 收货人姓名（必传）
     */
    @NotBlank(message = "收货人姓名不能为空")
    private String receiverName;

    /**
     * 收货人手机号（必传）
     */
    @NotBlank(message = "收货人手机号不能为空")
    private String receiverPhone;

    /**
     * 收货人地址（必传）
     */
    @NotBlank(message = "收货人地址不能为空")
    private String receiverAddress;

    /**
     * 订单状态（默认0：待支付）
     */
    private Integer status = 0;

    /**
     * 备注信息（可选）
     */
    private String remark;

    /**
     * 支付方式（可选，如：微信支付、支付宝等）
     */
    private String payWay;

    /**
     * 订单明细列表（必传，至少包含1条明细）
     */
    @NotNull(message = "订单明细不能为空")
    private List<OrderItemAddDTO> orderItemList;
}