package com.kingso.ecommerce.module.procurement.service.impl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.kingso.ecommerce.module.goods.entity.Goods;
import com.kingso.ecommerce.module.goods.mapper.GoodsMapper;
import com.kingso.ecommerce.module.procurement.controller.ProcurementController;
import com.kingso.ecommerce.module.procurement.dto.ProcurementOrderAddDTO;
import com.kingso.ecommerce.module.procurement.dto.ProcurementOrderItemAddDTO;
import com.kingso.ecommerce.module.procurement.dto.ProcurementOrderQueryDTO;
import com.kingso.ecommerce.module.procurement.entity.ProcurementOrder;
import com.kingso.ecommerce.module.procurement.entity.ProcurementOrderItem;
import com.kingso.ecommerce.module.procurement.mapper.ProcurementOrderItemMapper;
import com.kingso.ecommerce.module.procurement.mapper.ProcurementOrderMapper;
import com.kingso.ecommerce.module.procurement.service.ProcurementOrderService;
import com.kingso.ecommerce.module.stock.entity.Stock;
import com.kingso.ecommerce.module.stock.mapper.StockMapper;

/**
 * 采购订单服务实现类
 */
@Service
public class ProcurementOrderServiceImpl implements ProcurementOrderService {
    private static final Logger log = LoggerFactory.getLogger(ProcurementController.class);
   
    private final ProcurementOrderMapper procurementOrderMapper;
    private final ProcurementOrderItemMapper procurementOrderItemMapper;
    private final GoodsMapper goodsMapper;
    private final StockMapper stockMapper;

    // ========== 新增：时间格式化器（与前后端格式一致，不影响其他代码） ==========
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public ProcurementOrderServiceImpl(ProcurementOrderMapper procurementOrderMapper,
                                       ProcurementOrderItemMapper procurementOrderItemMapper,
                                       GoodsMapper goodsMapper,
                                       StockMapper stockMapper) {
        this.procurementOrderMapper = procurementOrderMapper;
        this.procurementOrderItemMapper = procurementOrderItemMapper;
        this.goodsMapper = goodsMapper;
        this.stockMapper = stockMapper;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void createProcurementOrder(ProcurementOrderAddDTO addDTO) {
        // 基础参数校验
        Assert.notNull(addDTO, "采购订单参数不能为空");
        Assert.notNull(addDTO.getOperatorId(), "操作员ID不能为空");
        Assert.notNull(addDTO.getWarehouseId(), "仓库ID不能为空");
        Assert.notNull(addDTO.getItemList(), "采购明细不能为空");
        Assert.isTrue(!CollectionUtils.isEmpty(addDTO.getItemList()), "采购明细至少包含一条记录");

        // 校验仓库是否存在且启用
        Long warehouseId = addDTO.getWarehouseId();
        Integer warehouseEnableCount = stockMapper.checkWarehouseEnable(warehouseId);
        Assert.isTrue(warehouseEnableCount > 0, "仓库不存在或未启用，无法入库");

        // 校验商品（核心修改：按商品ID校验，条码仅参考）
        for (ProcurementOrderItemAddDTO item : addDTO.getItemList()) {
            // 按商品ID精准查询（核心）
            Goods goods = goodsMapper.selectById(item.getGoodsId());
            Assert.notNull(goods, "商品不存在：ID=" + item.getGoodsId() + "，请先添加商品信息");
            
            // 校验商品是否上架
            Integer goodsExistCount = stockMapper.checkGoodsExist(goods.getId());
            Assert.isTrue(goodsExistCount > 0, "商品已下架，无法采购入库：" + item.getGoodsName());
        }

        
        // 生成采购单号
        String procurementNo = "PROC" + System.currentTimeMillis() +
                UUID.randomUUID().toString().substring(0, 3).toUpperCase();

        // 保存采购订单主表
        ProcurementOrder order = new ProcurementOrder();
        order.setProcurementNo(procurementNo);
        order.setOperatorId(addDTO.getOperatorId());
        order.setWarehouseId(addDTO.getWarehouseId());
        order.setCustomsFileUrl(addDTO.getCustomsFileUrl());
        order.setRemark(addDTO.getRemark());
        order.setCreateTime(LocalDateTime.now());
        order.setUpdateTime(LocalDateTime.now());
        
        procurementOrderMapper.insert(order);
        Long orderId = order.getId();

        // 保存采购订单明细
        List<ProcurementOrderItem> itemList = addDTO.getItemList().stream().map(itemDTO -> {
            ProcurementOrderItem item = new ProcurementOrderItem();
            item.setProcurementOrderId(orderId);
            item.setGoodsName(itemDTO.getGoodsName());
            item.setGoodsBarcode(itemDTO.getGoodsBarcode()); // 条码可选，允许null
            item.setGoodsId(itemDTO.getGoodsId()); // 新增：商品ID
            item.setWarehouseArea(itemDTO.getWarehouseArea()); // 新增：仓库区域
            item.setQuantity(itemDTO.getQuantity());
            item.setProcurementAmount(itemDTO.getProcurementAmount());
            return item;
        }).collect(Collectors.toList());
        
        procurementOrderItemMapper.batchInsert(itemList);

        // 更新库存表
        for (ProcurementOrderItemAddDTO itemDTO : addDTO.getItemList()) {
            Long goodsId = itemDTO.getGoodsId();
            // 根据商品ID+仓库ID查询库存
   
            Stock stock = stockMapper.selectByGoodsIdAndWarehouseId(goodsId, warehouseId);
            
            if (stock == null) {
                // 库存不存在，（记录warehouse_area）
                stock = new Stock();
                stock.setGoodsId(goodsId);
                stock.setWarehouseId(warehouseId); // Long类型
                stock.setWarehouseArea(itemDTO.getWarehouseArea()); // 仓库区域
                stock.setStockNum(itemDTO.getQuantity());
                stock.setLockNum(0);
                stock.setUpdateTime(LocalDateTime.now());
                stockMapper.insert(stock);
            } else {
                // 库存存在，增量更新（调用新增的批量更新方法）
                stockMapper.updateStockNumByGoodsIdAndWarehouseId(goodsId, warehouseId, itemDTO.getQuantity());
            }
        }
    }

    // 条码模糊查询采购明细
    @Override
    public List<ProcurementOrderItem> queryItemByBarcodeLike(String barcode) {
        return procurementOrderItemMapper.selectByBarcodeLike(barcode);
    }

    @Override
    public ProcurementOrder getById(Long id) {
        Assert.notNull(id, "采购订单ID不能为空");
        Assert.isTrue(id > 0, "采购订单ID必须为正整数");
        return procurementOrderMapper.selectById(id);
    }

    @Override
    public ProcurementOrder getByProcurementNo(String procurementNo) {
        Assert.isTrue(StringUtils.hasText(procurementNo), "采购单号不能为空");
        return procurementOrderMapper.selectByProcurementNo(procurementNo);
    }

    @Override
    public Map<String, Object> getPage(ProcurementOrderQueryDTO queryDTO) {
        // 先校验 queryDTO 不为 null，避免空指针
        if (queryDTO == null) {
            queryDTO = new ProcurementOrderQueryDTO();
        }

        // LocalDateTime startTime = null;
        // LocalDateTime endTime = null;
        
        int offset = (queryDTO.getPageNum() - 1) * queryDTO.getPageSize();
        queryDTO.setPageNum(offset);

        List<ProcurementOrder> orderList = procurementOrderMapper.selectPage(queryDTO);
        Integer total = procurementOrderMapper.selectTotal(queryDTO);

        Map<String, Object> result = new HashMap<>();
        result.put("list", orderList == null ? new ArrayList<>() : orderList);
        result.put("total", total == null ? 0 : total);
        result.put("pageNum", queryDTO.getPageNum() + 1);
        result.put("pageSize", queryDTO.getPageSize());
        
        return result;
    }

    @Override
    public Map<String, Object> getWithItemsById(Long id) {
        Assert.notNull(id, "采购订单ID不能为空");
        Assert.isTrue(id > 0, "采购订单ID必须为正整数");

        // 查询订单主信息
        ProcurementOrder order = procurementOrderMapper.selectById(id);
        Assert.notNull(order, "采购订单不存在");

        // 查询订单明细
        List<ProcurementOrderItem> itemList = procurementOrderItemMapper.selectByProcurementOrderId(id);

        // 封装结果
        Map<String, Object> result = new HashMap<>();
        result.put("order", order);
        result.put("itemList", itemList);
        
        return result;
    }
}