package com.kingso.ecommerce.module.stock.entity;

import java.time.LocalDateTime;

import lombok.Data;

/**
 * 商品盘点表实体（inventory_count）
 * 对齐userAdmin的User实体风格
 */
@Data
public class InventoryCount {
    /** 盘点记录ID（主键，自增） */
    private Long id;
    /** 商品ID（关联商品表主键） */
    private Long goodsId;
     /** 仓库ID（关联仓库主键） */
    private Long warehouseId;
    private long changeQuantity;
    
    /** 用户ID（关联用户表主键） */
    private Long userId;
    /** 盘点时间 */
    private LocalDateTime createTime;
    /** 盘点备注（可选，存储说明信息） */
    private String remark;
}