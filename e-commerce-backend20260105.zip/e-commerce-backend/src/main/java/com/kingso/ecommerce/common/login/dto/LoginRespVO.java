package com.kingso.ecommerce.common.login.dto;

import java.io.Serializable;

import lombok.Data;

/**
 * 登录通用响应VO（前后台所有登录场景复用，字段参考User.java，隐藏敏感信息）
 */
@Data
public class LoginRespVO implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * JWT令牌（核心返回值，用于接口认证）
     */
    private String token;

    /**
     * 用户ID（对应User.java的id字段）
     */
    private Long userId;

    /**
     * 用户名（对应User.java的username字段）
     */
    private String username;

    /**
     * 用户昵称（对应User.java的nickname字段，前台展示用）
     */
    private String nickname;

    /**
     * 头像URL（对应User.java的avatar字段，前台展示用）
     */
    private String avatar;

    /**
     * 用户类型（对应User.java的userType字段：0-普通用户，1-VIP用户）
     */
    private Integer userType;

    /**
     * 角色（对应User.java的role字段，权限控制用）
     */
    private String role;

    /**
     * 用户状态（对应User.java的status字段：0-禁用，1-正常）
     */
    private Integer status;

    /**
     * Token过期时间（单位：秒，前端用于自动刷新Token）
     */
    private Long expiresIn;
}