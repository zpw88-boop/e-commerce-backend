package com.kingso.ecommerce.module.cart.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.kingso.ecommerce.module.cart.dto.CartAddDTO;
import com.kingso.ecommerce.module.cart.dto.CartDeleteDTO;
import com.kingso.ecommerce.module.cart.dto.CartUpdateDTO;
import com.kingso.ecommerce.module.cart.entity.Cart;

/**
 * 购物车Mapper接口
 */
@Mapper
public interface CartMapper {
    /**
     * 新增购物车（存在则更新数量）
     */
    int addCart(CartAddDTO cartAddDTO);

    /**
     * 根据用户ID查询购物车列表
     */
    List<Cart> getCartListByUserId(Long userId);

    /**
     * 更新购物车数量
     */
    int updateCartNum(CartUpdateDTO cartUpdateDTO);

    /**
     * 删除购物车商品
     */
    int deleteCart(CartDeleteDTO cartDeleteDTO);
}