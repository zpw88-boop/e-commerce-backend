package com.kingso.ecommerce.module.cart.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.Data;

@Data
public class Cart {
    private Long id;
    private Long userId;
    private Long goodsId;
    private String goodsName;
    private String goodsImg;
    private Integer num;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
    private BigDecimal goodsPrice;
    /**
     * 仓库ID
     */
    private Integer warehouseId;
    /**
     * 库存数量（从tb_stock表关联获取）
     */
    private Integer stockNum;
}