// com/kingso/ecommerce/module/user/controller/UserController.java
package com.kingso.ecommerce.module.userAdmin.controller;

import java.util.Map;

import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kingso.ecommerce.common.result.Result;
import com.kingso.ecommerce.module.userAdmin.dto.UserAddDTO;
import com.kingso.ecommerce.module.userAdmin.dto.UserQueryDTO;
import com.kingso.ecommerce.module.userAdmin.dto.UserUpdateDTO;
import com.kingso.ecommerce.module.userAdmin.entity.User;
import com.kingso.ecommerce.module.userAdmin.service.UserService;


@RestController
@RequestMapping("/api/admin/users")
public class UserController {

    private final UserService userService;

    // 构造器注入
    public UserController(UserService userService) {
        this.userService = userService;
    }

    /**
     * 新增用户
     */
    @PostMapping("/add")
    public Result<Boolean> addUser(
            @RequestBody @Validated UserAddDTO addDTO,
            BindingResult bindingResult
    ) {
        // 参数校验错误处理
        if (bindingResult.hasErrors()) {
            return Result.fail(buildErrorMsg(bindingResult));
        }
        userService.addUser(addDTO);
        return Result.success(true, "用户新增成功");
    }

    /**
     * 更新用户
     */
    @PutMapping("/update")
    public Result<Boolean> updateUser(
            @RequestBody @Validated UserUpdateDTO updateDTO,
            BindingResult bindingResult
    ) {
        if (bindingResult.hasErrors()) {
            return Result.fail(buildErrorMsg(bindingResult));
        }
        userService.updateUser(updateDTO);
        return Result.success(true, "用户更新成功");
    }

    /**
     * 删除用户
     */
    @DeleteMapping("/delete/{id}")
    public Result<Boolean> deleteUser(@PathVariable Long id) {
        if (id == null || id <= 0) {
            return Result.fail("用户ID必须为正整数");
        }
        userService.deleteUser(id);
        return Result.success(true, "用户删除成功");
    }

    /**
     * 根据ID查询用户
     */
    @GetMapping("/{id}")
    public Result<User> getUserById(@PathVariable Long id) {
        if (id == null || id <= 0) {
            return Result.fail("用户ID必须为正整数");
        }
        User user = userService.getUserById(id);
        return Result.success(user, "用户查询成功");
    }

    /**
     * 分页查询用户列表
     */
    @GetMapping("/page")
    public Result<Map<String, Object>> getUserPage(UserQueryDTO queryDTO) {
        Map<String, Object> pageResult = userService.getUserPage(queryDTO);
        return Result.success(pageResult, "用户列表查询成功");
    }

    // 构建参数校验错误信息
    private String buildErrorMsg(BindingResult bindingResult) {
        return bindingResult.getFieldErrors().stream()
                .map(FieldError::getDefaultMessage)
                .reduce((msg1, msg2) -> msg1 + "；" + msg2)
                .orElse("参数校验失败");
    }
}