package com.kingso.ecommerce.common.jwt;

import java.io.Serializable;

import lombok.Data;

/**
 * JWT通用用户模型（支撑Token生成与解析，字段参考User.java，轻量化设计）
 * 仅包含认证和权限控制所需的核心字段，不包含展示类字段（如nickname、avatar）
 */
@Data
public class JwtUser implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 用户ID（对应User.java的id字段，唯一标识）
     */
    private Long userId;

    /**
     * 用户名（对应User.java的username字段）
     */
    private String username;

    /**
     * 用户类型（对应User.java的userType字段：0-普通用户，1-VIP用户）
     */
    private Integer userType;

    /**
     * 角色（对应User.java的role字段，权限校验用）
     */
    private String role;

    /**
     * 用户状态（对应User.java的status字段：0-禁用，1-正常，用于账号有效性校验）
     */
    private Integer status;
}