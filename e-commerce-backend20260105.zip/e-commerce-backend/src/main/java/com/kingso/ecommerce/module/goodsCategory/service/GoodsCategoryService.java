package com.kingso.ecommerce.module.goodsCategory.service;

import com.kingso.ecommerce.module.goodsCategory.dto.GoodsCategoryAddDTO;
import com.kingso.ecommerce.module.goodsCategory.dto.GoodsCategoryDeleteDTO;
import com.kingso.ecommerce.module.goodsCategory.dto.GoodsCategoryPageDTO;
import com.kingso.ecommerce.module.goodsCategory.dto.GoodsCategoryUpdateDTO;
import com.kingso.ecommerce.module.goodsCategory.entity.GoodsCategory;

/**
 * 商品分类 Service 接口
 */
public interface GoodsCategoryService {

    /**
     * 分页查询商品分类
     * @param pageNum 页码
     * @param pageSize 每页条数
     * @param categoryName 分类名称（模糊查询，可为null）
     * @return 分页结果
     */
    GoodsCategoryPageDTO getCategoryPage(Integer pageNum, Integer pageSize, String categoryName);

    /**
     * 新增商品分类
     * @param categoryAddDTO 新增参数
     */
    void addCategory(GoodsCategoryAddDTO categoryAddDTO);

    /**
     * 编辑商品分类
     * @param categoryUpdateDTO 编辑参数
     */
    void updateCategory(GoodsCategoryUpdateDTO categoryUpdateDTO);

    /**
     * 删除商品分类（存在子分类则抛出异常）
     * @param categoryDeleteDTO 删除参数
     */
    void deleteCategory(GoodsCategoryDeleteDTO categoryDeleteDTO);

    /**
     * 根据ID查询分类详情
     * @param id 分类ID
     * @return 分类详情
     */
    GoodsCategory getCategoryById(Long id);
}