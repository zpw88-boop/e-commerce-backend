package com.kingso.ecommerce.common.login.exception;

/**
 * 登录通用失败异常（前后台所有登录场景复用，统一异常类型）
 * 可用于用户名不存在、密码错误、账号禁用、验证码错误等登录失败场景
 */
public class LoginFailedException extends RuntimeException {

    public LoginFailedException() {
        super("登录失败，请检查登录信息");
    }

    public LoginFailedException(String message) {
        super(message);
    }

    /**
     * 带异常原因的构造方法（便于问题排查）
     */
    public LoginFailedException(String message, Throwable cause) {
        super(message, cause);
    }
}