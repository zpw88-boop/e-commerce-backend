// com/kingso/ecommerce/module/order/service/OrderItemService.java
package com.kingso.ecommerce.module.order.service;

import java.util.List;

import com.kingso.ecommerce.module.order.dto.OrderItemAddDTO;
import com.kingso.ecommerce.module.order.entity.OrderItem;

/**
 * 订单明细服务接口
 */
public interface OrderItemService {
    /**
     * 批量新增订单明细
     * @param orderId 订单ID（关联主表）
     * @param itemAddDTOList 明细新增列表
     */
    void batchAddOrderItem(Long orderId, List<OrderItemAddDTO> itemAddDTOList);

    /**
     * 根据订单ID查询明细列表
     */
    List<OrderItem> getOrderItemListByOrderId(Long orderId);

    /**
     * 根据订单ID批量删除明细
     */
    void batchDeleteOrderItemByOrderId(Long orderId);
}