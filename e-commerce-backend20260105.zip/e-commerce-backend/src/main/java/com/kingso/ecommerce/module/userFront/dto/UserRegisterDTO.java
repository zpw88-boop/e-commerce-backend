package com.kingso.ecommerce.module.userFront.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * 前台用户注册DTO
 * 用于接收前台普通用户注册时提交的参数，并做参数合法性校验
 */
@Data
public class UserRegisterDTO {
    /**
     * 用户名（3-20位，仅支持字母、数字、下划线）
     */
    @NotBlank(message = "用户名不能为空")
    @Pattern(regexp = "^[a-zA-Z0-9_]{3,20}$", message = "用户名需为3-20位字母、数字或下划线")
    private String username;

    /**
     * 登录密码（6-18位，必须是字母+数字组合）
     */
    @NotBlank(message = "密码不能为空")
    @Pattern(regexp = "^(?=.*[a-zA-Z])(?=.*\\d)[a-zA-Z\\d]{6,18}$", message = "密码需为6-18位字母+数字组合")
    private String password;

    /**
     * 手机号（11位纯数字，符合国内手机号格式）
     */
    @NotBlank(message = "手机号不能为空")
    @Pattern(regexp = "^1[3-9]\\d{9}$", message = "请输入正确的11位手机号")
    private String phone;

    /**
     * 用户昵称（2-10位，支持中文、字母、数字，不可包含特殊字符）
     */
    @NotBlank(message = "昵称不能为空")
    @Size(min = 2, max = 10, message = "昵称需为2-10位字符")
    @Pattern(regexp = "^[\\u4e00-\\u9fa5a-zA-Z0-9]{2,10}$", message = "昵称支持中文、字母、数字，2-10位")
    private String nickname;

    /**
     * 头像地址（非必填项，若未传递则使用系统默认头像）
     */
    private String avatar;
}