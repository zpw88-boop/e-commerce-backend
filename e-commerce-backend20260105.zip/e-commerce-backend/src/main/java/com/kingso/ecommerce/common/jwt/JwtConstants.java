package com.kingso.ecommerce.common.jwt;

/**
 * JWT相关常量
 */
public class JwtConstants {
    /**
     * Token请求头名称
     */
    public static final String TOKEN_HEADER = "Authorization";

    /**
     * Token前缀（配合Bearer规范）
     */
    public static final String TOKEN_PREFIX = "Bearer ";

    /**
     * 管理员角色标识
     */
    public static final String ROLE_ADMIN = "ADMIN";

    /**
     * 普通用户角色标识
     */
    public static final String ROLE_USER = "USER";

    /**
     * JWT默认过期时间（2小时，单位：毫秒）
     */
    public static final long DEFAULT_EXPIRE_MS = 7200000;
}