// com/kingso/ecommerce/module/userAdmin/mapper/UserMapper.java
package com.kingso.ecommerce.module.userAdmin.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.kingso.ecommerce.module.userAdmin.dto.UserQueryDTO;
import com.kingso.ecommerce.module.userAdmin.entity.User;

/**
 * 用户Mapper接口（前后台共用）
 */
@Mapper
public interface UserMapper {
    /**
     * 新增用户
     */
    void insert(User user);

    /**
     * 根据ID更新用户
     */
    void updateById(User user);

    /**
     * 根据ID删除用户（逻辑删除可在此处扩展）
     */
    void deleteById(Long id);

    /**
     * 根据ID查询用户
     */
    User selectById(Long id);

    /**
     * 根据用户名查询用户（用于唯一性校验）
     */
    User selectByUsername(String username);

    /**
     * 分页查询用户列表
     */
    List<User> selectPage(UserQueryDTO queryDTO);

    /**
     * 查询用户总数（用于分页）
     */
    Integer selectTotal(UserQueryDTO queryDTO);
    /**
     * 根据用户名查询用户（登录核心方法）
     * @param username 用户名（对应User.java的username字段）
     * @return User 实体对象
     */
    User selectUserByUsername(@Param("username") String username, @Param("userType") Integer userType);
    User selectByPhone(@Param("phone") String phone);
}