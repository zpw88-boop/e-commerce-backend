package com.kingso.ecommerce.module.userFront.service;

import java.util.Map;

import com.kingso.ecommerce.module.userAdmin.entity.User;
import com.kingso.ecommerce.module.userFront.dto.UserFrontQueryDTO;
import com.kingso.ecommerce.module.userFront.dto.UserRegisterDTO;
import com.kingso.ecommerce.module.userFront.dto.UserUpdateSelfDTO;

/**
 * 前台用户业务接口
 */
public interface UserFrontService {
    /**
     * 前台用户注册
     */
    void register(UserRegisterDTO registerDTO);

    /**
     * 普通用户修改自身信息（仅昵称/手机号/头像）
     */
    void updateSelf(UserUpdateSelfDTO updateSelfDTO);

    /**
     * 获取当前登录用户信息（隐藏密码）
     */
    User getCurrentUserInfo();
    
    /**
     * 根据用户ID获取用户信息
     */
    User getUserById(Long userId);
        
    Map<String, Object> getUserPage(UserFrontQueryDTO queryDTO);
}