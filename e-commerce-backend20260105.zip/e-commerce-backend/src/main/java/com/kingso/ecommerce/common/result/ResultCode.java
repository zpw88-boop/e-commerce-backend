package com.kingso.ecommerce.common.result;

import lombok.Getter;

/**
 * 全局统一状态码枚举
 * 规范所有接口的响应状态码
 */
@Getter
public enum ResultCode {
    // 成功状态
    SUCCESS(200, "操作成功"),
    // 通用失败状态
    FAIL(500, "操作失败"),
    // 业务异常状态
    PARAM_ERROR(400, "参数校验失败"),
    NOT_FOUND(404, "资源不存在"),
    UNAUTHORIZED(401, "未授权访问"),
    FORBIDDEN(403, "禁止访问"),
    UPLOAD_ERROR(501, "文件上传失败"),
    // ========== 补充系统异常枚举（核心修复） ==========
    SYSTEM_ERROR(500, "系统异常，请稍后重试"),
    DB_ERROR(502, "数据库异常，请稍后重试");

    /**
     * 状态码
     */
    private final Integer code;
    /**
     * 提示信息
     */
    private final String msg;

    // 构造器
    ResultCode(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }
}