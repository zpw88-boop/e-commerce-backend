package com.kingso.ecommerce.module.express.dto;

import java.util.List;

import com.kingso.ecommerce.module.express.entity.Express;

import lombok.Data;

/**
 * 快递公司分页结果DTO（替代PageHelper，封装总条数和列表）
 */
@Data
public class ExpressPageDTO {
    /**
     * 总记录数
     */
    private Long total;

    /**
     * 分页快递公司列表
     */
    private List<Express> expressList;
}

