package com.kingso.ecommerce.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {
    @Value("${goods.upload.base-path}")
    private final String goodsUploadBasePath;
    // 注入海关文件上传路径（原有配置，无修改）
    @Value("${customs.file.upload.path}")
    private final String customsUploadPath;

    /**
     * 构造函数：保留原有逻辑，初始化商品+海关路径
     */
    public WebMvcConfig(@Value("${goods.upload.base-path}") String goodsUploadBasePath,
                        @Value("${customs.file.upload.path}") String customsUploadPath) {
        this.goodsUploadBasePath = goodsUploadBasePath;
        this.customsUploadPath = customsUploadPath;
    }

    /**
     * 资源映射配置：保留原有逻辑 + 优化海关文件路径拼接
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 默认静态资源映射（项目自带static目录，原有配置）
        registry.addResourceHandler("/static/**")
                .addResourceLocations("classpath:/static/");
        
        // 商品上传图片映射（原有配置，无修改）
        registry.addResourceHandler("/static/images/goods/**")
                .addResourceLocations("file:" + goodsUploadBasePath);
        
        // 广告图片映射指向项目根目录的 static/images/advertisement/
        // 注意：advertisement 是静态资源，通常不需要动态上传，所以直接使用项目根目录路径
        String projectRootPath = System.getProperty("user.dir");
        String advertisementPath = projectRootPath + "/static/images/advertisement/";
        registry.addResourceHandler("/static/images/advertisement/**")
                .addResourceLocations("file:" + advertisementPath);
        
        // 海关文件映射：优化路径拼接，确保本地路径末尾带斜杠
        registry.addResourceHandler("/static/upload/customs/**")
                // 拼接时手动添加/，避免customsUploadPath无末尾斜杠导致路径错误
                .addResourceLocations("file:" + customsUploadPath + (customsUploadPath.endsWith("/") ? "" : "/"));
    }

    // 注释掉的 MVC 拦截器注册代码：保留
    // @Override
    // public void addInterceptors(InterceptorRegistry registry) {
    //     registry.addInterceptor(jwtAuthenticationFilter)
    //             .addPathPatterns("/**")
    //             .excludePathPatterns(jwtAuthenticationFilter.getJwtProperties().getIgnoreUrls());
    // }


    @Bean
    public FilterRegistrationBean<CorsFilter> corsFilterRegistration() {
        CorsConfiguration config = new CorsConfiguration();
        // 放行 localhost:3000
        config.addAllowedOrigin("http://localhost:3000");
        // 放行 localhost:3080
        config.addAllowedOrigin("http://localhost:3080");
        config.setAllowCredentials(true);
        config.addAllowedMethod(CorsConfiguration.ALL);
        config.addAllowedHeader(CorsConfiguration.ALL);
        config.setMaxAge(3600L);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        CorsFilter corsFilter = new CorsFilter(source);

        FilterRegistrationBean<CorsFilter> registrationBean = new FilterRegistrationBean<>(corsFilter);
        registrationBean.setOrder(-1);
        registrationBean.setName("corsFilter");
        return registrationBean;
    }
}