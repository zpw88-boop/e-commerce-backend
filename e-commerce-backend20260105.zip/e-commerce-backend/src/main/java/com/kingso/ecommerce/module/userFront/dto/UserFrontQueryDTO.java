package com.kingso.ecommerce.module.userFront.dto;

import lombok.Data;

/**
 * 用户查询参数DTO
 */
@Data
public class UserFrontQueryDTO {
    /**
     * 用户名（模糊查询）
     */
    private String username;
    private String phone;
    private String nickname;
    /**
     * 状态（0-禁用，1-正常，null-查询全部）
     */
    private Integer status;

    /**
     * 用户类型（1-普通用户，0-管理）
     */
    private Integer userType;

    /**
     * 页码（默认1）
     */
    private Integer pageNum = 1;

    /**
     * 每页条数（默认10）
     */
    private Integer pageSize = 10;
}