// com/kingso/ecommerce/module/warehouse/mapper/WarehouseMapper.java
package com.kingso.ecommerce.module.warehouse.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.kingso.ecommerce.module.warehouse.dto.WarehouseQueryDTO;
import com.kingso.ecommerce.module.warehouse.entity.Warehouse;

/**
 * 仓库Mapper接口
 */
@Mapper
public interface WarehouseMapper {
    /**
     * 新增仓库
     */
    void insert(Warehouse warehouse);

    /**
     * 根据ID更新仓库
     */
    void updateById(Warehouse warehouse);

    /**
     * 根据ID删除仓库
     */
    void deleteById(Long id);

    /**
     * 根据ID查询仓库
     */
    Warehouse selectById(Long id);

    /**
     * 根据仓库名称查询仓库（用于唯一性校验）
     */
    Warehouse selectByWarehouseName(String warehouseName);

    /**
     * 分页查询仓库列表
     */
    List<Warehouse> selectPage(WarehouseQueryDTO queryDTO);

    /**
     * 查询仓库总数（用于分页）
     */
    Integer selectTotal(WarehouseQueryDTO queryDTO);
}