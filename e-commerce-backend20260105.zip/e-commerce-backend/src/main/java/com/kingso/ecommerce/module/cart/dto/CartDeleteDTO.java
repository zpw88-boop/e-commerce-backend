package com.kingso.ecommerce.module.cart.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

/**
 * 删除购物车DTO
 */
@Data
public class CartDeleteDTO {
    /**
     * 购物车ID
     */
    @NotNull(message = "购物车ID不能为空")
    @Positive(message = "购物车ID必须为正整数")
    private Long id;

    /**
     * 用户ID（权限校验）
     */
    @NotNull(message = "用户ID不能为空")
    @Positive(message = "用户ID必须为正整数")
    private Long userId;
}