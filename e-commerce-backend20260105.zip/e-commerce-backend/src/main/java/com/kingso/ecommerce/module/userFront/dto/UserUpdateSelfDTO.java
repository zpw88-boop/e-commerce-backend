package com.kingso.ecommerce.module.userFront.dto;

import com.kingso.ecommerce.module.userAdmin.dto.UserUpdateDTO.UpdateGroup;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * 前台用户修改自身信息DTO
 */
@Data
public class UserUpdateSelfDTO {
    /**
     * 当前登录用户ID（后续从Token解析，暂时先传入）
     */
    private Long Id;
    /**
     * 用户名（可选，2-20位）
     */
    @Pattern(regexp = "^.{2,20}$", message = "用户名长度必须为2-20位", groups = UpdateGroup.class)
    private String username;
    private String password;
    /**
     * 邮箱（可选，格式校验）
     */
    @Email(message = "邮箱格式不正确")
    private String email;
    /**
     * 昵称（可选修改，2-10位）
     */
    @Size(min = 2, max = 10, message = "昵称需为2-10位字符")
    @Pattern(regexp = "^[\\u4e00-\\u9fa5a-zA-Z0-9]{2,10}$", message = "昵称支持中文、字母、数字，2-10位")
    private String nickname;

    /**
     * 手机号（可选修改，11位纯数字）
     */
    @Pattern(regexp = "^1[3-9]\\d{9}$", message = "请输入正确的11位手机号")
    private String phone;
    private String status;
    /**
     * 头像地址（可选修改）
     */
    private String avatar;
}