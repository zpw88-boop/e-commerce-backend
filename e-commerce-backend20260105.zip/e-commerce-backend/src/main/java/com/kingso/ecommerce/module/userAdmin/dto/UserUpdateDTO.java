// com/kingso/ecommerce/module/user/dto/UserUpdateDTO.java
package com.kingso.ecommerce.module.userAdmin.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import lombok.Data;

/**
 * 更新用户参数DTO
 */
@Data
public class UserUpdateDTO {
    /**
     * 用户ID（必传，正整数）
     */
    @NotNull(message = "用户ID不能为空")
    @Positive(message = "用户ID必须为正整数")
    private Long id;

    /**
     * 用户名（可选，2-20位）
     */
    @Pattern(regexp = "^.{2,20}$", message = "用户名长度必须为2-20位", groups = UpdateGroup.class)
    private String username;
    private String password;

    /**
     * 手机号（可选，11位数字）
     */
    @Pattern(regexp = "^1[3-9]\\d{9}$", message = "手机号格式不正确")
    private String phone;

    /**
     * 邮箱（可选，格式校验）
     */
    @Email(message = "邮箱格式不正确")
    private String email;

    /**
     * 状态（可选，0-禁用，1-正常）
     */
    private Integer status;

    // 分组校验：用于区分新增/更新场景（更新时用户名可选项）
    public interface UpdateGroup {}
}