// com/kingso/ecommerce/module/warehouse/dto/WarehouseQueryDTO.java
package com.kingso.ecommerce.module.warehouse.dto;

import lombok.Data;

/**
 * 仓库查询参数DTO
 */
@Data
public class WarehouseQueryDTO {
    /**
     * 仓库名称（模糊查询）
     */
    private String warehouseName;

    /**
     * 仓库类别：国内/国际
     */
    private String warehouseType;

    /**
     * 启用状态：1-启用，0-停用，null-查询全部
     */
    private Integer enableStatus;

    /**
     * 页码（默认1）
     */
    private Integer pageNum = 1;

    /**
     * 每页条数（默认10）
     */
    private Integer pageSize = 10;
}