package com.kingso.ecommerce.module.cart.dto;

import java.math.BigDecimal;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

/**
 * 新增购物车DTO
 */
@Data
public class CartAddDTO {
    /**
     * 用户ID
     */
    @NotNull(message = "用户ID不能为空")
    @Positive(message = "用户ID必须为正整数")
    private Long userId;

    /**
     * 商品ID
     */
    @NotNull(message = "商品ID不能为空")
    @Positive(message = "商品ID必须为正整数")
    private Long goodsId;

    /**
     * 商品数量
     */
    @NotNull(message = "商品数量不能为空")
    @Positive(message = "商品数量必须为正整数")
    private Integer num;

    /**
     * 商品价格（可选，如果为空则从商品表获取）
     */
    private BigDecimal goodsPrice;

    /**
     * 商品名称（可选，如果为空则从商品表获取）
     */
    private String goodsName;

    /**
     * 商品图片（可选，如果为空则从商品表获取）
     */
    private String goodsImg;

    /**
     * 仓库ID
     */
    private Integer warehouseId;
}