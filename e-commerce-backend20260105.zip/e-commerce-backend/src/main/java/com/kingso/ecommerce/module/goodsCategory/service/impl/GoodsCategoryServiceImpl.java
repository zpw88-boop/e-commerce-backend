package com.kingso.ecommerce.module.goodsCategory.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.kingso.ecommerce.module.goodsCategory.dto.GoodsCategoryAddDTO;
import com.kingso.ecommerce.module.goodsCategory.dto.GoodsCategoryDeleteDTO;
import com.kingso.ecommerce.module.goodsCategory.dto.GoodsCategoryPageDTO;
import com.kingso.ecommerce.module.goodsCategory.dto.GoodsCategoryUpdateDTO;
import com.kingso.ecommerce.module.goodsCategory.entity.GoodsCategory;
import com.kingso.ecommerce.module.goodsCategory.mapper.GoodsCategoryMapper;
import com.kingso.ecommerce.module.goodsCategory.service.GoodsCategoryService;

/**
 * 商品分类 Service 实现类
 */
@Service
@Transactional
public class GoodsCategoryServiceImpl implements GoodsCategoryService {

    @Autowired
    private GoodsCategoryMapper goodsCategoryMapper;

    /**
     * 分页查询商品分类（原生分页）
     */
    @Override
    public GoodsCategoryPageDTO getCategoryPage(Integer pageNum, Integer pageSize, String categoryName) {
        // 参数合法性校验
        Assert.notNull(pageNum, "页码不能为空");
        Assert.notNull(pageSize, "每页条数不能为空");
        Assert.isTrue(pageNum > 0, "页码必须为正整数");
        Assert.isTrue(pageSize > 0, "每页条数必须为正整数");

        // 计算偏移量
        Integer offset = (pageNum - 1) * pageSize;
        // 查询分页列表
        List<GoodsCategory> categoryList = goodsCategoryMapper.selectCategoryPage(categoryName, offset, pageSize);
        // 查询总条数
        Long total = goodsCategoryMapper.selectCategoryTotal(categoryName);

        // 封装分页结果
        GoodsCategoryPageDTO pageDTO = new GoodsCategoryPageDTO();
        pageDTO.setTotal(total);
        pageDTO.setCategoryList(categoryList);
        return pageDTO;
    }

    /**
     * 新增商品分类
     */
    @Override
    public void addCategory(GoodsCategoryAddDTO categoryAddDTO) {
        Assert.notNull(categoryAddDTO, "分类新增参数不能为空");
        goodsCategoryMapper.insertCategory(categoryAddDTO);
    }

    /**
     * 编辑商品分类（存在子分类则抛出异常）
     */
    @Override
    public void updateCategory(GoodsCategoryUpdateDTO categoryUpdateDTO) {
        Assert.notNull(categoryUpdateDTO, "分类编辑参数不能为空");
        // 校验分类是否存在
        GoodsCategory existCategory = goodsCategoryMapper.selectCategoryById(categoryUpdateDTO.getId());
        Assert.notNull(existCategory, "待编辑的分类不存在");
        // 执行编辑
        goodsCategoryMapper.updateCategory(categoryUpdateDTO);
    }

    /**
     * 删除商品分类（存在子分类则抛出异常）
     */
    @Override
    public void deleteCategory(GoodsCategoryDeleteDTO categoryDeleteDTO) {
        Assert.notNull(categoryDeleteDTO, "分类删除参数不能为空");
        // 校验分类是否存在
        GoodsCategory existCategory = goodsCategoryMapper.selectCategoryById(categoryDeleteDTO.getId());
        Assert.notNull(existCategory, "待删除的分类不存在");
        //  校验是否存在子分类
        Integer childCount = goodsCategoryMapper.countChildCategory(categoryDeleteDTO.getId());
        Assert.isTrue(childCount == 0, "该分类下存在子分类，无法删除");
        //  执行删除
        goodsCategoryMapper.deleteCategory(categoryDeleteDTO);
    }

    /**
     * 根据ID查询分类详情
     */
    @Override
    public GoodsCategory getCategoryById(Long id) {
        Assert.notNull(id, "分类ID不能为空");
        return goodsCategoryMapper.selectCategoryById(id);
    }
}