package com.kingso.ecommerce.module.goodsFront.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.kingso.ecommerce.module.goodsFront.dto.GoodsFrontQueryDTO;
import com.kingso.ecommerce.module.goodsFront.entity.GoodsFront;

@Mapper
public interface GoodsFrontMapper {

    List<GoodsFront> getGoodsList(GoodsFrontQueryDTO goodsQueryDTO);

    Long getGoodsTotal(GoodsFrontQueryDTO goodsQueryDTO);
}