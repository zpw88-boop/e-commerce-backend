package com.kingso.ecommerce.common.exception;

import org.mybatis.spring.MyBatisSystemException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.kingso.ecommerce.common.result.Result;

import lombok.extern.slf4j.Slf4j;

/**
 * 全局异常处理器：强制打印完整异常栈，返回具体错误信息
 */
@Slf4j
@RestControllerAdvice // 作用于所有@RestController
public class GlobalExceptionHandler {

    // 专门捕获MyBatis系统异常（核心）
    @ExceptionHandler(MyBatisSystemException.class)
    public Result<?> handleMyBatisException(MyBatisSystemException e) {
        // 打印完整异常栈（包含根原因，比如SQL语法错、参数绑定失败）
        //log.error("===== MyBatis执行异常 START =====", e);
        // 获取根异常信息（真正的错误原因）
        Throwable rootCause = e.getRootCause();
        String rootMsg = rootCause != null ? rootCause.getMessage() : e.getMessage();
        // 返回具体错误，而非"系统异常：null"
        return Result.fail("数据库操作失败：" + rootMsg);
    }

    // 捕获参数绑定/转换异常（比如GET参数String转BigDecimal失败）
    @ExceptionHandler(org.springframework.validation.BindException.class)
    public Result<?> handleBindException(org.springframework.validation.BindException e) {
        log.error("参数绑定异常：", e);
        String fieldMsg = e.getFieldError() != null ? e.getFieldError().getDefaultMessage() : "参数格式错误";
        return Result.fail("参数错误：" + fieldMsg);
    }

    // 专门处理 IllegalArgumentException（业务校验异常，如用户名重复、手机号重复等）
    @ExceptionHandler(IllegalArgumentException.class)
    public Result<?> handleIllegalArgumentException(IllegalArgumentException e) {
        log.warn("业务校验异常：{}", e.getMessage());
        // 直接返回异常消息，不加前缀，保持消息的原始语义
        return Result.fail(e.getMessage());
    }

    // 捕获所有运行时异常
    @ExceptionHandler(RuntimeException.class)
    public Result<?> handleRuntimeException(RuntimeException e) {
        log.error("系统运行时异常：", e);
        // 如果异常消息为空，返回默认提示
        String errorMsg = e.getMessage();
        if (errorMsg == null || errorMsg.trim().isEmpty()) {
            errorMsg = "系统异常，请稍后重试";
        }
        return Result.fail(errorMsg);
    }
}