package com.kingso.ecommerce.module.express.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 快递公司编辑DTO
 */
@Data
public class ExpressUpdateDTO {
    /**
     * 快递公司ID（必填）
     */
    @NotNull(message = "快递公司ID不能为空")
    private Integer id;

    /**
     * 快递公司名称（必填）
     */
    @NotBlank(message = "快递公司名称不能为空")
    private String expressName;

    /**
     * 状态
     */
    private String status;
}

