package com.kingso.ecommerce.common.login.dto;

import org.hibernate.validator.constraints.Length;

import com.kingso.ecommerce.common.login.dto.group.AdminLoginGroup;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 登录通用请求DTO（前后台所有登录场景复用，字段参考User.java）
 */
@Data
public class LoginReqDTO {
    /**
     * 用户名（对应User.java的username字段，前后台通用）
     */
    @NotBlank(message = "用户名不能为空")
    @Length(min = 3, max = 20, message = "用户名长度需在3-20位之间")
    private String username;

    /**
     * 密码（对应User.java的password字段，前后台通用）
     */
    @NotBlank(message = "密码不能为空")
    @Length(min = 6, max = 32, message = "密码长度需在6-32位之间")
    private String password;

    /**
     * 用户类型（对应User.java的userType字段：0-后台用户，1-消费者用户）
     * 前后台通过该字段区分场景
     */
    @NotNull(message = "用户类型不能为空")
    private Integer userType;

    /**
     * 验证码（可选字段：后台管理员登录必填，前台用户登录可选，通过校验分组控制）
     */
    @NotBlank(message = "验证码不能为空", groups = AdminLoginGroup.class)
    private String captcha;
}