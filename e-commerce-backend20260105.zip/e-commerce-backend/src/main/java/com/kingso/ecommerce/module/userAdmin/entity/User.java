// com/kingso/ecommerce/module/userAdmin/entity/User.java
package com.kingso.ecommerce.module.userAdmin.entity;

import java.time.LocalDateTime;

import lombok.Data;

/**
 * 用户实体类（映射用户表tb_user）
 */
@Data
public class User {
    /**
     * 用户ID（主键）
     */
    private Long id;

    /**
     * 用户名（唯一）
     */
    private String username;

    /**
     * 密码（建议加密存储）
     */
    private String password;

    /**
     * 手机号
     */
    private String phone;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 用户昵称（前台展示用，可修改）
     */
    private String nickname;

    /**
     * 头像URL
     */
    private String avatar;

    /**
     * 用户类型（0-后台用户，1-前台用户，默认0）
     */
    private Integer userType;

    /**
     * 用户唯一编号（全局唯一）
     */
    private String orderNo;

    /**
     * 用户状态（0-禁用，1-正常）
     */
    private Integer status;
    private String role;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
}