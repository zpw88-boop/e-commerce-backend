// com/kingso/ecommerce/module/order/entity/Order.java
package com.kingso.ecommerce.module.order.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.Data;

/**
 * 订单实体类（映射tb_order表）
 */
@Data
public class Order {
    /**
     * 订单ID（主键，自增）
     */
    private Long id;

    /**
     * 订单编号（唯一）
     */
    private String orderNo;

    /**
     * 用户ID
     */
    private Long userId;

    private String payWay;
    /**
     * 订单总金额
     */
    private BigDecimal totalAmount;

    /**
     * 收货人姓名
     */
    private String receiverName;

    /**
     * 收货人手机号
     */
    private String receiverPhone;

    /**
     * 收货人地址
     */
    private String receiverAddress;

    /**
     * 订单状态（0：待支付，1：待发货，2：待收货，3：已完成，8：已删除，9：已取消）
     */
    private Integer status;

    /**
     * 支付时间
     */
    private LocalDateTime payTime;

    /**
     * 收货时间
     */
    private LocalDateTime receiveTime;

    /**
     * 取消时间
     */
    private LocalDateTime cancelTime;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;

    /**
     * 备注信息
     */
    private String remark;

    /**
     * 快递公司名称
     */
    private String expressName;

    /**
     * 快递公司ID
     */
    private Integer expressId;

    /**
     * 快递运营商
     */
    private Integer expressOperator;

    /**
     * 快递单号
     */
    private String expressNo;

    /**
     * 快递备注
     */
    private String expressRemark;
    private Long goodsId;
    /**
     * 商品名称（下单时快照，不随商品信息变更）
     */
    private String goodsName;

    /**
     * 商品单价（下单时快照）
     */
    private BigDecimal goodsPrice;

    /**
     * 商品数量
     */
    private Integer num;

    /**
     * 该商品总金额（goods_price * num）
     */
    private BigDecimal totalPrice;
}