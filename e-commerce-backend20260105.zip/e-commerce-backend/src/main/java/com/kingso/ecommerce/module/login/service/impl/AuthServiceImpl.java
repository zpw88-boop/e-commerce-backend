package com.kingso.ecommerce.module.login.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.kingso.ecommerce.common.jwt.JwtUser;
import com.kingso.ecommerce.common.jwt.JwtUtils;
import com.kingso.ecommerce.common.login.constant.LoginConstants;
import com.kingso.ecommerce.common.login.dto.LoginReqDTO;
import com.kingso.ecommerce.common.login.dto.LoginRespVO;
import com.kingso.ecommerce.common.login.exception.LoginFailedException;
import com.kingso.ecommerce.module.login.service.AuthService;
import com.kingso.ecommerce.module.userAdmin.entity.User;
import com.kingso.ecommerce.module.userAdmin.mapper.UserMapper;

/**
 * 登录业务实现类（核心逻辑：查用户、验密码、生成Token、封装响应）
 */
@Service
public class AuthServiceImpl implements AuthService {

    // 注入用户Mapper（查询用户数据）
    @Autowired
    private UserMapper userMapper;

    // 注入JWT工具类（生成Token，你已具备）
    @Autowired
    private JwtUtils jwtUtils;

    // 注入密码加密器（验证加密后的密码）
    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Override
    public LoginRespVO login(LoginReqDTO loginReqDTO) {
        // 提取登录参数
        String username = loginReqDTO.getUsername();
        String password = loginReqDTO.getPassword();
        Integer usertype = loginReqDTO.getUserType();
        // userType参数可根据需求扩展

        // 查询用户（根据用户名）
        User user = userMapper.selectUserByUsername(username,usertype);
        if (user == null) {
            throw new LoginFailedException("用户名不存在，请检查登录信息");
        }

        // 校验用户状态（是否禁用）
        if (LoginConstants.USER_STATUS_DISABLE.equals(user.getStatus())) {
            throw new LoginFailedException("账号已被禁用，请联系管理员");
        }

        // 校验密码（临时改为明文比对，注释BCrypt比对逻辑）
        // 原BCrypt比对逻辑（注释掉）
        // if (!passwordEncoder.matches(password, user.getPassword())) {
        //     throw new LoginFailedException("密码错误，请重新输入");
        // }

        // 临时明文比对逻辑
        if (!password.equals(user.getPassword())) {
            throw new LoginFailedException("密码错误，请重新输入");
        }


        // 构建JwtUser（复用common/login的模型，用于生成Token）
        JwtUser jwtUser = new JwtUser();
        jwtUser.setUserId(user.getId());
        jwtUser.setUsername(user.getUsername());
        jwtUser.setUserType(user.getUserType());
        jwtUser.setRole(user.getRole());
        jwtUser.setStatus(user.getStatus());

        // 生成JWT Token
        String token = jwtUtils.generateToken(jwtUser);
        // 获取Token过期时间（从JwtUtils中获取，单位：秒）
        Long expiresIn = jwtUtils.getJwtProperties().getExpireMs() / 1000; 

        // 封装登录响应VO（复用common/login的VO，隐藏敏感信息）
        LoginRespVO loginRespVO = new LoginRespVO();
        loginRespVO.setToken(token);
        loginRespVO.setUserId(user.getId());
        loginRespVO.setUsername(user.getUsername());
        loginRespVO.setNickname(user.getNickname());
        loginRespVO.setAvatar(user.getAvatar());
        loginRespVO.setUserType(user.getUserType());
        loginRespVO.setRole(user.getRole());
        loginRespVO.setStatus(user.getStatus());
        loginRespVO.setExpiresIn(expiresIn);

        return loginRespVO;
    }
}