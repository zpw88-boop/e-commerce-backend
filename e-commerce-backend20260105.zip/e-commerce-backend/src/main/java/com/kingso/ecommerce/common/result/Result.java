package com.kingso.ecommerce.common.result;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 全局统一返回结果类
 * 适配所有接口的返回格式，支持链式调用（可选）
 * @param <T> 响应数据泛型
 */
@Data
@Accessors(chain = true) // 可选：开启链式调用（如result.setCode(200).setMsg("成功")）
public class Result<T> {
    /**
     * 响应码：参考ResultCode枚举
     */
    private Integer code;

    /**
     * 响应消息
     */
    private String msg;

    /**
     * 响应数据
     */
    private T data;

    /**
     * 响应时间戳（新增：便于前端排查请求时间）
     */
    private Long timestamp;

    // 私有构造器（禁止外部直接new，统一通过静态方法创建）
    private Result() {
        this.timestamp = System.currentTimeMillis(); // 自动填充当前时间戳
    }

    private Result(Integer code, String msg, T data) {
        this(); // 调用无参构造，填充时间戳
        this.code = code;
        this.msg = msg;
        this.data = data;
    }

    //成功响应重载方法（丰富场景，更灵活）
    /**
     * 成功响应（无数据，默认提示语+默认时间戳）
     */
    public static <T> Result<T> success() {
        return new Result<>(ResultCode.SUCCESS.getCode(), ResultCode.SUCCESS.getMsg(), null);
    }

    /**
     * 成功响应（带数据，默认提示语+默认时间戳）
     */
    public static <T> Result<T> success(T data) {
        return new Result<>(ResultCode.SUCCESS.getCode(), ResultCode.SUCCESS.getMsg(), data);
    }

    /**
     * 成功响应（带数据+自定义提示语+默认时间戳）
     */
    public static <T> Result<T> success(T data, String msg) {
        return new Result<>(ResultCode.SUCCESS.getCode(), msg, data);
    }

    /**
     * 成功响应（无数据+自定义提示语+默认时间戳）【新增：补充场景】
     */
    public static <T> Result<T> success(String msg) {
        return new Result<>(ResultCode.SUCCESS.getCode(), msg, null);
    }

    //失败响应重载方法（规范+兼容+扩展）
    /**
     * 失败响应（默认状态码+默认提示语+默认时间戳）
     */
    public static <T> Result<T> fail() {
        return new Result<>(ResultCode.FAIL.getCode(), ResultCode.FAIL.getMsg(), null);
    }

    /**
     * 失败响应（自定义提示语，默认失败状态码+默认时间戳）
     */
    public static <T> Result<T> fail(String msg) {
        return new Result<>(ResultCode.FAIL.getCode(), msg, null);
    }

    /**
     * 失败响应（自定义状态码+自定义提示语+默认时间戳）
     */
    public static <T> Result<T> fail(Integer code, String msg) {
        return new Result<>(code, msg, null);
    }

    /**
     * 失败响应（基于ResultCode枚举，规范状态码+默认时间戳）
     */
    public static <T> Result<T> fail(ResultCode resultCode) {
        return new Result<>(resultCode.getCode(), resultCode.getMsg(), null);
    }

    /**
     * 失败响应（基于ResultCode枚举+自定义提示语+默认时间戳）
     */
    public static <T> Result<T> fail(ResultCode resultCode, String msg) {
        return new Result<>(resultCode.getCode(), msg, null);
    }

    public static <T> Result<T> error(String msg) {
        return fail(msg);
    }

    public static <T> Result<T> error(Integer code, String msg) {
        return fail(code, msg);
    }

    // 快速返回业务异常（如参数错误、上传失败）
    /**
     * 参数错误响应（快速返回400状态码）
     */
    public static <T> Result<T> paramError(String msg) {
        return fail(ResultCode.PARAM_ERROR, msg);
    }

    /**
     * 文件上传失败响应（快速返回501状态码）
     */
    public static <T> Result<T> uploadError(String msg) {
        return fail(ResultCode.UPLOAD_ERROR, msg);
    }
}