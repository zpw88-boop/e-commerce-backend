package com.kingso.ecommerce.module.stock.dto;

import java.time.LocalDateTime;

import com.kingso.ecommerce.module.stock.entity.Stock;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 库存展示DTO（关联商品/仓库名称）
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class StockDTO  extends Stock{
    /** 库存ID */
    private Long id;
    /** 商品ID */
    private Long goodsId;
    /** 商品名称（关联tb_goods.goods_name） */
    private String goodsName;
    /** 库存数量 */
    private Integer stockNum;
    /** 锁定库存 */
    private Integer lockNum;
    /** 更新时间 */
    private LocalDateTime updateTime;
    /** 仓库ID */
    private Long warehouseId;
    /** 仓库名称（关联warehouse_dict.warehouse_name，仅启用状态） */
    private String warehouseName;
    /** 仓库区域 */
    private String warehouseArea;
}