// com/kingso/ecommerce/module/order/service/impl/OrderItemServiceImpl.java
package com.kingso.ecommerce.module.order.service.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import com.kingso.ecommerce.module.order.dto.OrderItemAddDTO;
import com.kingso.ecommerce.module.order.entity.OrderItem;
import com.kingso.ecommerce.module.order.mapper.OrderItemMapper;
import com.kingso.ecommerce.module.order.service.OrderItemService;
import com.kingso.ecommerce.module.stock.mapper.StockMapper;

/**
 * 订单明细服务实现类
 */
@Service
public class OrderItemServiceImpl implements OrderItemService {

    private final OrderItemMapper orderItemMapper;
    private final StockMapper stockMapper;

    // 构造器注入
    public OrderItemServiceImpl(OrderItemMapper orderItemMapper, StockMapper stockMapper) {
        this.orderItemMapper = orderItemMapper;
        this.stockMapper = stockMapper;
    }

    @Override
    public void batchAddOrderItem(Long orderId, List<OrderItemAddDTO> itemAddDTOList) {
        // 参数校验
        Assert.notNull(orderId, "订单ID不能为空");
        Assert.isTrue(orderId > 0, "订单ID必须为正整数");
        Assert.notNull(itemAddDTOList, "订单明细列表不能为空");
        Assert.isTrue(!CollectionUtils.isEmpty(itemAddDTOList), "订单明细列表至少包含1条数据");

        // 先扣减库存：遍历订单明细，根据商品ID和仓库ID扣减对应库存
        // 先扣减库存，再插入订单明细，确保库存不足时提前失败
        for (OrderItemAddDTO dto : itemAddDTOList) {
            // 封装库存调整参数（扣减库存，changeQuantity为负数）
            Map<String, Object> stockParamMap = new HashMap<>();
            stockParamMap.put("goodsId", dto.getGoodsId());
            stockParamMap.put("warehouseId", dto.getWarehouseId());
            stockParamMap.put("changeQuantity", -dto.getNum()); // 负数表示扣减

            // 执行库存扣减（复用 updateInventorybyId 方法）
            int stockUpdateRows = stockMapper.updateInventorybyId(stockParamMap);
            // 校验库存更新是否成功
            if (stockUpdateRows <= 0) {
                throw new RuntimeException(
                    String.format("库存扣减失败：商品ID=%d，仓库ID=%d，未找到对应库存记录或库存不足", 
                        dto.getGoodsId(), dto.getWarehouseId()));
            }
        }

        // DTO列表转实体列表（自动计算商品总金额）
        List<OrderItem> orderItemList = itemAddDTOList.stream().map(dto -> {
            OrderItem item = new OrderItem();
            item.setOrderId(orderId);
            item.setGoodsId(dto.getGoodsId());
            item.setGoodsName(dto.getGoodsName());
            item.setGoodsPrice(dto.getGoodsPrice());
            item.setNum(dto.getNum());
            // 自动计算：商品单价 * 数量
            BigDecimal totalPrice = dto.getGoodsPrice().multiply(new BigDecimal(dto.getNum()));
            item.setTotalPrice(totalPrice);
            // 设置仓库ID
            item.setWarehouseId(dto.getWarehouseId() != null ? dto.getWarehouseId().intValue() : null);
            return item;
        }).collect(Collectors.toList());

        // 批量新增明细
        orderItemMapper.batchInsert(orderItemList);
    }

    @Override
    public List<OrderItem> getOrderItemListByOrderId(Long orderId) {
        Assert.notNull(orderId, "订单ID不能为空");
        Assert.isTrue(orderId > 0, "订单ID必须为正整数");
        return orderItemMapper.selectByOrderId(orderId);
    }

    @Override
    public void batchDeleteOrderItemByOrderId(Long orderId) {
        Assert.notNull(orderId, "订单ID不能为空");
        Assert.isTrue(orderId > 0, "订单ID必须为正整数");
        orderItemMapper.batchDeleteByOrderId(orderId);
    }
}