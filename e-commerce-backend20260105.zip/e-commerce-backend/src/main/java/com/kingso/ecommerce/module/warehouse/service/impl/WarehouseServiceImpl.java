// com/kingso/ecommerce/module/warehouse/service/impl/WarehouseServiceImpl.java
package com.kingso.ecommerce.module.warehouse.service.impl;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.kingso.ecommerce.module.warehouse.dto.WarehouseAddDTO;
import com.kingso.ecommerce.module.warehouse.dto.WarehouseQueryDTO;
import com.kingso.ecommerce.module.warehouse.dto.WarehouseUpdateDTO;
import com.kingso.ecommerce.module.warehouse.entity.Warehouse;
import com.kingso.ecommerce.module.warehouse.mapper.WarehouseMapper;
import com.kingso.ecommerce.module.warehouse.service.WarehouseService;

/**
 * 仓库服务实现类
 */
@Service
public class WarehouseServiceImpl implements WarehouseService {

    private final WarehouseMapper warehouseMapper;

    // 构造器注入
    public WarehouseServiceImpl(WarehouseMapper warehouseMapper) {
        this.warehouseMapper = warehouseMapper;
    }

    @Override
    public void addWarehouse(WarehouseAddDTO addDTO) {
        // 参数校验
        Assert.notNull(addDTO, "新增仓库参数不能为空");
        // 校验仓库名称唯一性
        Warehouse existWarehouse = warehouseMapper.selectByWarehouseName(addDTO.getWarehouseName());
        Assert.isNull(existWarehouse, "仓库名称已存在");

        // DTO转实体
        Warehouse warehouse = new Warehouse();
        warehouse.setWarehouseName(addDTO.getWarehouseName());
        warehouse.setWarehouseType(addDTO.getWarehouseType());
        warehouse.setWarehouseAddress(addDTO.getWarehouseAddress());
        warehouse.setWarehouseArea(addDTO.getWarehouseArea());
        warehouse.setCooperationCompany(addDTO.getCooperationCompany());
        warehouse.setCustomsId(addDTO.getCustomsId());
        warehouse.setCustomsAreaName(addDTO.getCustomsAreaName());
        warehouse.setEnableStatus(addDTO.getEnableStatus());

        // 调用Mapper新增
        warehouseMapper.insert(warehouse);
    }

    @Override
    public void updateWarehouse(WarehouseUpdateDTO updateDTO) {
        // 参数校验
        Assert.notNull(updateDTO, "更新仓库参数不能为空");
        Long warehouseId = updateDTO.getId();
        Warehouse existWarehouse = warehouseMapper.selectById(warehouseId);
        Assert.notNull(existWarehouse, "仓库不存在");

        // 若更新仓库名称，需校验唯一性（排除当前仓库）
        String newWarehouseName = updateDTO.getWarehouseName();
        if (newWarehouseName != null && !newWarehouseName.equals(existWarehouse.getWarehouseName())) {
            Warehouse warehouse = warehouseMapper.selectByWarehouseName(newWarehouseName);
            Assert.isNull(warehouse, "仓库名称已存在");
        }

        // DTO转实体
        Warehouse warehouse = new Warehouse();
        warehouse.setId(warehouseId);
        warehouse.setWarehouseName(newWarehouseName);
        warehouse.setWarehouseType(updateDTO.getWarehouseType());
        warehouse.setWarehouseAddress(updateDTO.getWarehouseAddress());
        warehouse.setWarehouseArea(updateDTO.getWarehouseArea());
        warehouse.setCooperationCompany(updateDTO.getCooperationCompany());
        warehouse.setCustomsId(updateDTO.getCustomsId());
        warehouse.setCustomsAreaName(updateDTO.getCustomsAreaName());
        
        // 如果状态变为停用，设置停用时间
        if (updateDTO.getEnableStatus() == 0 && existWarehouse.getEnableStatus() != 0) {
            warehouse.setStopTime(LocalDateTime.now());
        }
        warehouse.setEnableStatus(updateDTO.getEnableStatus());

        // 调用Mapper更新
        warehouseMapper.updateById(warehouse);
    }

    @Override
    public void deleteWarehouse(Long id) {
        Assert.notNull(id, "仓库ID不能为空");
        Assert.isTrue(id > 0, "仓库ID必须为正整数");
        // 校验仓库存在
        Warehouse existWarehouse = warehouseMapper.selectById(id);
        Assert.notNull(existWarehouse, "仓库不存在");
        // 调用Mapper删除
        warehouseMapper.deleteById(id);
    }

    @Override
    public Warehouse getWarehouseById(Long id) {
        Assert.notNull(id, "仓库ID不能为空");
        Assert.isTrue(id > 0, "仓库ID必须为正整数");
        return warehouseMapper.selectById(id);
    }

    @Override
    public Map<String, Object> getWarehousePage(WarehouseQueryDTO queryDTO) {
        // 计算分页起始位置（pageNum从1开始）
        int offset = (queryDTO.getPageNum() - 1) * queryDTO.getPageSize();
        queryDTO.setPageNum(offset);

        // 查询列表和总数
        List<Warehouse> warehouseList = warehouseMapper.selectPage(queryDTO);
        Integer total = warehouseMapper.selectTotal(queryDTO);

        // 封装分页结果
        Map<String, Object> result = new HashMap<>();
        result.put("list", warehouseList);
        result.put("total", total);
        result.put("pageNum", queryDTO.getPageNum() + 1); // 恢复原页码
        result.put("pageSize", queryDTO.getPageSize());
        return result;
    }
}