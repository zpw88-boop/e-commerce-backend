package com.kingso.ecommerce.common.jwt;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

/**
 * JWT配置属性（从application.yml读取）
 */
@Data
@Component
@ConfigurationProperties(prefix = "jwt") //从配置文件读取
public class JwtProperties {
    /**
     * 签名密钥（必须配置，建议32位以上）
     */
    private String secret;

    /**
     * 过期时间（毫秒，默认2小时）
     */
    private long expireMs = JwtConstants.DEFAULT_EXPIRE_MS;

    /**
     * 无需认证的接口路径（如登录、注册）
     */
    private String[] ignoreUrls = {"/admin/user/login", "/user/login", "/static/**", "/swagger-ui/**", "/api/auth/login"};
}