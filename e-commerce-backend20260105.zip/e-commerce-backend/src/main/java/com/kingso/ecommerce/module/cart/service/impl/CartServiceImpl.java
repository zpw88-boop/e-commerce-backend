package com.kingso.ecommerce.module.cart.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.kingso.ecommerce.module.cart.dto.CartAddDTO;
import com.kingso.ecommerce.module.cart.dto.CartDeleteDTO;
import com.kingso.ecommerce.module.cart.dto.CartUpdateDTO;
import com.kingso.ecommerce.module.cart.entity.Cart;
import com.kingso.ecommerce.module.cart.mapper.CartMapper;
import com.kingso.ecommerce.module.cart.service.CartService;
import com.kingso.ecommerce.module.goods.entity.Goods;
import com.kingso.ecommerce.module.goods.mapper.GoodsMapper;

/**
 * 购物车服务实现类
 */
@Service
@Transactional
public class CartServiceImpl implements CartService {

    @Autowired
    private CartMapper cartMapper;

    @Autowired
    private GoodsMapper goodsMapper;

    @Override
    public void addCart(CartAddDTO cartAddDTO) {
        Assert.notNull(cartAddDTO, "购物车参数不能为空");
        // 根据用户ID和商品ID判断：如果购物车中已存在该商品，则累加数量；如果不存在，则插入新记录
        // 此逻辑在 CartMapper.xml 中通过 ON DUPLICATE KEY UPDATE 实现（基于唯一索引 uk_user_goods）
        cartMapper.addCart(cartAddDTO);
    }

    @Override
    public List<Cart> getCartList(Long userId) {
        Assert.notNull(userId, "用户ID不能为空");
        return cartMapper.getCartListByUserId(userId);
    }

    @Override
    public void updateCartNum(CartUpdateDTO cartUpdateDTO) {
        Assert.notNull(cartUpdateDTO, "购物车更新参数不能为空");
        // 根据购物车ID和用户ID更新数量（用户ID用于权限校验，防止修改他人购物车）
        cartMapper.updateCartNum(cartUpdateDTO);
    }

    @Override
    public void deleteCart(CartDeleteDTO cartDeleteDTO) {
        Assert.notNull(cartDeleteDTO, "购物车删除参数不能为空");
        cartMapper.deleteCart(cartDeleteDTO);
    }
}