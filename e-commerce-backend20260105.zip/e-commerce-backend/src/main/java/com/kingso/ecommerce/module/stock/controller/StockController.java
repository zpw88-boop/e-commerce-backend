package com.kingso.ecommerce.module.stock.controller;

import java.util.HashMap;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kingso.ecommerce.module.stock.dto.StockAdjustDTO;
import com.kingso.ecommerce.module.stock.dto.StockQueryDTO;
import com.kingso.ecommerce.module.stock.entity.Stock;
import com.kingso.ecommerce.module.stock.service.StockService;

import lombok.RequiredArgsConstructor;

/**
 * 库存管理Controller
 * 接口路径：/admin/stock
 */
@RestController
@RequestMapping("/admin/stock")
@RequiredArgsConstructor
public class StockController {

    private final StockService stockService;
    /**
     * 库存调整接口
     * @param stockAdjustDTO 调整参数
     * @return 统一格式响应（code/msg）
     */
    @PostMapping("/adjust")
    public HashMap<String, Object> adjustStock(@RequestBody StockAdjustDTO stockAdjustDTO) {
        // 初始化统一返回结果，对齐其他接口格式
        HashMap<String, Object> result = new HashMap<>(3);
        try {
            // 调用Service层方法（返回void，无报错即成功）
            stockService.adjustStockAndInsertRecord(stockAdjustDTO);
            // 业务执行成功：返回code=200，前端识别成功
            result.put("code", 200);
            result.put("msg", "库存盘点调整成功");
        } catch (RuntimeException e) {
            // 捕获Service层抛出的异常，返回code=400
            result.put("code", 400);
            result.put("msg", e.getMessage());
        } catch (Exception e) {
            // 捕获其他异常，返回code=500
            result.put("code", 500);
            result.put("msg", "库存调整异常：" + e.getMessage());
        }
        return result;
    }
    /**
     * 新增库存
     */
    @PostMapping
    public HashMap<String, Object> add(@RequestBody Stock stock) {
        return stockService.addStock(stock);
    }

    /**
     * 修改库存
     */
    @PutMapping
    public HashMap<String, Object> edit(@RequestBody Stock stock) {
        return stockService.editStock(stock);
    }

    /**
     * 删除库存
     */
    @DeleteMapping("/{id}")
    public HashMap<String, Object> delete(@PathVariable Long id) {
        return stockService.deleteStock(id);
    }

    /**
     * 根据ID查询库存详情
     */
    @GetMapping("/{id}")
    public HashMap<String, Object> detail(@PathVariable Long id) {
        return stockService.getStockDetail(id);
    }

    /**
     * 分页查询库存列表
     */
    @GetMapping("/page")
    public HashMap<String, Object> page(
            @RequestParam(required = false, defaultValue = "1") Integer pageNum,
            @RequestParam(required = false, defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) String goodsName,
            @RequestParam(required = false) String warehouseName) {

        StockQueryDTO queryDTO = new StockQueryDTO();
        queryDTO.setPageNum(pageNum);
        queryDTO.setPageSize(pageSize);
        queryDTO.setGoodsName(goodsName);
        queryDTO.setWarehouseName(warehouseName);
        return stockService.getStockPage(queryDTO);
    }
}