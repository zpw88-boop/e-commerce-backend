package com.kingso.ecommerce.module.cart.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

/**
 * 更新购物车数量DTO
 */
@Data
public class CartUpdateDTO {
    /**
     * 购物车ID
     */
    @NotNull(message = "购物车ID不能为空")
    @Positive(message = "购物车ID必须为正整数")
    private Long id;

    /**
     * 用户ID（权限校验）
     */
    @NotNull(message = "用户ID不能为空")
    @Positive(message = "用户ID必须为正整数")
    private Long userId;

    /**
     * 新数量
     */
    @NotNull(message = "商品数量不能为空")
    @Positive(message = "商品数量必须为正整数")
    private Integer num;
}