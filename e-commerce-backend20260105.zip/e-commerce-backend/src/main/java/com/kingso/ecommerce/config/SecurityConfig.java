package com.kingso.ecommerce.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.kingso.ecommerce.common.jwt.JwtAuthenticationFilter;

import jakarta.annotation.Resource;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Resource
    private JwtAuthenticationFilter jwtAuthenticationFilter;

    @Bean
    public BCryptPasswordEncoder bCryptPasswordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable()) //JWT是无状态认证，Token在请求头中，不受CSRF攻击影响。CSRF主要针对基于Cookie的Session认证
                .httpBasic(httpBasic -> httpBasic.disable())//禁用HTTP Basic认证
                //无状态Session（不创建Session）
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                // 显式开启 CORS
                .cors(cors -> cors.configurationSource(request -> {
                    org.springframework.web.cors.CorsConfiguration config = new org.springframework.web.cors.CorsConfiguration();
                    // 放行 localhost:3000
                    config.addAllowedOrigin("http://localhost:3000");
                    // 放行 localhost:3080（核心修改点）
                    config.addAllowedOrigin("http://localhost:3080");
                    config.setAllowCredentials(true);
                    config.addAllowedMethod(org.springframework.web.cors.CorsConfiguration.ALL);
                    config.addAllowedHeader(org.springframework.web.cors.CorsConfiguration.ALL);
                    config.setMaxAge(3600L);
                    return config;
                }))
                .authorizeHttpRequests(auth -> auth
                        // 静态资源放行
                        .requestMatchers("/static/**", "/images/**", "/img/**", "/css/**", "/js/**").permitAll()
                        // 海关文件路径放行
                        .requestMatchers("/static/upload/customs/**").permitAll()
                        .requestMatchers("/static/images/advertisement/**").permitAll()
                        // OPTIONS 预检请求放行（跨域必需）
                        .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                        // 登录接口放行
                        .requestMatchers("/api/auth/login").permitAll()
                        // 前台用户注册接口放行
                        .requestMatchers("/api/userfront/register").permitAll()
                        // 其他请求需要认证
                        .anyRequest().authenticated()
                )
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}