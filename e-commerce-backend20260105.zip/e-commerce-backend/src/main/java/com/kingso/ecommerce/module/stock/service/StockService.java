package com.kingso.ecommerce.module.stock.service;

import java.util.HashMap;

import com.kingso.ecommerce.module.stock.dto.StockAdjustDTO;
import com.kingso.ecommerce.module.stock.dto.StockQueryDTO;
import com.kingso.ecommerce.module.stock.entity.Stock;

/**
 * 库存Service（对齐userAdmin的UserService）
 */
public interface StockService {

    /**
     * 新增库存
     */
    HashMap<String, Object> addStock(Stock stock);

    /**
     * 修改库存
     */
    HashMap<String, Object> editStock(Stock stock);

    /**
     * 删除库存
     */
    HashMap<String, Object> deleteStock(Long id);

    /**
     * 根据ID查询库存详情
     */
    HashMap<String, Object> getStockDetail(Long id);

    /**
     * 分页查询库存列表
     */
    HashMap<String, Object> getStockPage(StockQueryDTO queryDTO);
    /**
     * 调整库存并插入调整记录（原子操作）
     * @param stockAdjustDTO 库存调整请求参数
     */
    void adjustStockAndInsertRecord(StockAdjustDTO stockAdjustDTO);

}