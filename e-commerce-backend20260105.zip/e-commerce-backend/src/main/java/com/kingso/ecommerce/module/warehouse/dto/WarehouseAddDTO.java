// com/kingso/ecommerce/module/warehouse/dto/WarehouseAddDTO.java
package com.kingso.ecommerce.module.warehouse.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;


@Data
public class WarehouseAddDTO {
    /**
     * 仓库名称（非空）
     */
    @NotBlank(message = "仓库名称不能为空")
    private String warehouseName;

    /**
     * 仓库类别：国内/国际（非空）
     */
    @NotBlank(message = "仓库类别不能为空")
    private String warehouseType;

    /**
     * 仓库详细地址（非空）
     */
    @NotBlank(message = "仓库详细地址不能为空")
    private String warehouseAddress;

    /**
     * 仓库面积（单位：平方米，整数，非空，正数）
     */
    @NotNull(message = "仓库面积不能为空")
    @Positive(message = "仓库面积必须为正数")
    private Integer warehouseArea;

    /**
     * 仓库合作公司名称
     */
    private String cooperationCompany;

    /**
     * 对应海关ID（海关备案编号）
     */
    private String customsId;

    /**
     * 对应海关关区名称（如：上海浦东海关）
     */
    private String customsAreaName;

    /**
     * 启用状态：1-启用，0-停用，默认1
     */
    private Integer enableStatus = 1;
}