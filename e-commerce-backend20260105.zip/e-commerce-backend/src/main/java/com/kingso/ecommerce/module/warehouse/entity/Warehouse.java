// com/kingso/ecommerce/module/warehouse/entity/Warehouse.java
package com.kingso.ecommerce.module.warehouse.entity;

import java.time.LocalDateTime;

import lombok.Data;

/**
 * 仓库实体类（映射仓库表warehouse_dict）
 */
@Data
public class Warehouse {
    /**
     * 主键ID，自增生成
     */
    private Long id;

    /**
     * 仓库名称（如：上海浦东保税仓）
     */
    private String warehouseName;

    /**
     * 仓库类别：国内/国际
     */
    private String warehouseType;

    /**
     * 仓库详细地址
     */
    private String warehouseAddress;

    /**
     * 仓库面积（单位：平方米，整数）
     */
    private Integer warehouseArea;

    /**
     * 仓库合作公司名称
     */
    private String cooperationCompany;

    /**
     * 对应海关ID（海关备案编号）
     */
    private String customsId;

    /**
     * 对应海关关区名称（如：上海浦东海关）
     */
    private String customsAreaName;

    /**
     * 启用状态：1-启用，0-停用
     */
    private Integer enableStatus;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 停用时间（仅停用状态时填充）
     */
    private LocalDateTime stopTime;

    /**
     * 最后更新时间
     */
    private LocalDateTime updateTime;
}