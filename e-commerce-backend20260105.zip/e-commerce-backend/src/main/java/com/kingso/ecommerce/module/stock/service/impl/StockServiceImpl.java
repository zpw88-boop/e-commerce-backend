package com.kingso.ecommerce.module.stock.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kingso.ecommerce.module.procurement.controller.ProcurementController;
import com.kingso.ecommerce.module.stock.dto.StockAdjustDTO;
import com.kingso.ecommerce.module.stock.dto.StockDTO;
import com.kingso.ecommerce.module.stock.dto.StockQueryDTO;
import com.kingso.ecommerce.module.stock.entity.InventoryCount;
import com.kingso.ecommerce.module.stock.entity.Stock;
import com.kingso.ecommerce.module.stock.mapper.InventoryCountMapper;
import com.kingso.ecommerce.module.stock.mapper.StockMapper;
import com.kingso.ecommerce.module.stock.service.StockService;

import lombok.RequiredArgsConstructor;

/**
 * 库存Service实现
 */
@Service
@RequiredArgsConstructor
public class StockServiceImpl implements StockService {
    private static final Logger log = LoggerFactory.getLogger(ProcurementController.class);
    // 注入库存Mapper
    // 注入盘点记录Mapper
    @Autowired
    private InventoryCountMapper inventoryCountMapper;
    private final StockMapper stockMapper;
    
    /**
     * 调整库存并插入调整记录（事务保证：两个操作要么都成功，要么都失败）
     * @param stockAdjustDTO 库存调整请求参数
     * 说明：保持返回值void，与接口一致，不修改其他逻辑，确保无语法报错
     */
    @Override
    @Transactional(rollbackFor = Exception.class) // 异常时回滚所有操作
    public void adjustStockAndInsertRecord(StockAdjustDTO stockAdjustDTO) {
        // 封装库存调整参数，调用StockMapper更新库存
        Map<String, Object> stockParamMap = new HashMap<>();
        stockParamMap.put("goodsId", stockAdjustDTO.getGoodsId());
        stockParamMap.put("warehouseId", stockAdjustDTO.getWarehouseId());
        stockParamMap.put("changeQuantity", stockAdjustDTO.getChangeQuantity());

        // 执行库存更新
        int stockUpdateRows = stockMapper.updateInventorybyId(stockParamMap);
        // 校验库存更新是否成功（失败抛出运行时异常，控制器层捕获）
        if (stockUpdateRows <= 0) {
            throw new RuntimeException("库存调整失败：未找到对应商品或仓库的库存记录");
        }

        // 封装盘点记录实体，调用InventoryCountMapper插入记录
        InventoryCount inventoryCount = new InventoryCount();
        // 拷贝DTO属性到实体（BeanUtils自动映射驼峰命名字段）
        BeanUtils.copyProperties(stockAdjustDTO, inventoryCount);

        // 执行记录插入
        int recordInsertRows = inventoryCountMapper.insertInventoryCount(inventoryCount);
        // 校验记录插入是否成功（失败抛出运行时异常，事务回滚）
        if (recordInsertRows <= 0) {
            throw new RuntimeException("库存调整记录插入失败");
        }
    }
    
    @Override
    public HashMap<String, Object> addStock(Stock stock) {
        HashMap<String, Object> result = new HashMap<>(3);
        try {
            // 校验商品是否存在（上架）
            Long goodsId = stock.getGoodsId();
            if (goodsId == null) {
                result.put("code", 400);
                result.put("msg", "商品ID不能为空");
                return result;
            }
            int goodsCount = stockMapper.checkGoodsExist(goodsId);
            if (goodsCount == 0) {
                result.put("code", 400);
                result.put("msg", "商品不存在或已下架");
                return result;
            }

            // 校验仓库ID是否传入（库存按商品+仓库维度唯一，仓库ID必填）
            Long warehouseId = stock.getWarehouseId();
            if (warehouseId == null) {
                result.put("code", 400);
                result.put("msg", "仓库ID不能为空");
                return result;
            }

            // 校验商品+仓库维度的库存是否已存在（双参数校验）
            int stockCount = stockMapper.checkGoodsStockExist(goodsId, warehouseId);
            if (stockCount > 0) {
                result.put("code", 400);
                result.put("msg", "该商品在当前仓库下已存在库存记录，不可重复新增");
                return result;
            }

            // 校验仓库是否启用（warehouseId为Long类型，判断非空后校验）
            int warehouseCount = stockMapper.checkWarehouseEnable(warehouseId);
            if (warehouseCount == 0) {
                result.put("code", 400);
                result.put("msg", "仓库不存在或已停用");
                return result;
            }

            // 默认锁定库存为0
            if (stock.getLockNum() == null) {
                stock.setLockNum(0);
            }

            // 新增库存
            int rows = stockMapper.insert(stock);
            if (rows > 0) {
                result.put("code", 200);
                result.put("msg", "新增库存成功");
            } else {
                result.put("code", 500);
                result.put("msg", "新增库存失败");
            }
        } catch (Exception e) {
            result.put("code", 500);
            result.put("msg", "新增库存异常：" + e.getMessage());
        }
        return result;
    }

    @Override
    public HashMap<String, Object> editStock(Stock stock) {
        HashMap<String, Object> result = new HashMap<>(3);
        try {
            // 校验库存是否存在
            Long stockId = stock.getId();
            if (stockId == null) {
                result.put("code", 400);
                result.put("msg", "库存ID不能为空");
                return result;
            }
            Stock existStock = stockMapper.selectById(stockId);
            if (existStock == null) {
                result.put("code", 400);
                result.put("msg", "库存记录不存在");
                return result;
            }

            // 校验商品是否存在（上架）
            Long goodsId = stock.getGoodsId();
            if (goodsId == null) {
                result.put("code", 400);
                result.put("msg", "商品ID不能为空");
                return result;
            }
            int goodsCount = stockMapper.checkGoodsExist(goodsId);
            if (goodsCount == 0) {
                result.put("code", 400);
                result.put("msg", "商品不存在或已下架");
                return result;
            }

            // 校验仓库（若传）是否启用
            Long warehouseId = stock.getWarehouseId();
            if (warehouseId != null) {
                int warehouseCount = stockMapper.checkWarehouseEnable(warehouseId);
                if (warehouseCount == 0) {
                    result.put("code", 400);
                    result.put("msg", "仓库不存在或已停用");
                    return result;
                }
            }

            // 修改库存
            int rows = stockMapper.updateById(stock);
            if (rows > 0) {
                result.put("code", 200);
                result.put("msg", "修改库存成功");
            } else {
                result.put("code", 500);
                result.put("msg", "修改库存失败");
            }
        } catch (Exception e) {
            result.put("code", 500);
            result.put("msg", "修改库存异常：" + e.getMessage());
        }
        return result;
    }

    @Override
    public HashMap<String, Object> deleteStock(Long id) {
        HashMap<String, Object> result = new HashMap<>(3);
        try {
            // 校验库存是否存在
            if (id == null || id <= 0) {
                result.put("code", 400);
                result.put("msg", "库存ID必须为正整数");
                return result;
            }
            Stock existStock = stockMapper.selectById(id);
            if (existStock == null) {
                result.put("code", 400);
                result.put("msg", "库存记录不存在");
                return result;
            }

            // 删除库存
            int rows = stockMapper.deleteById(id);
            if (rows > 0) {
                result.put("code", 200);
                result.put("msg", "删除库存成功");
            } else {
                result.put("code", 500);
                result.put("msg", "删除库存失败");
            }
        } catch (Exception e) {
            result.put("code", 500);
            result.put("msg", "删除库存异常：" + e.getMessage());
        }
        return result;
    }

    @Override
    public HashMap<String, Object> getStockDetail(Long id) {
        HashMap<String, Object> result = new HashMap<>(3);
        try {
            if (id == null || id <= 0) {
                result.put("code", 400);
                result.put("msg", "库存ID必须为正整数");
                return result;
            }
            StockDTO stockDTO = stockMapper.selectDTOById(id);
            if (stockDTO != null) {
                result.put("code", 200);
                result.put("msg", "查询成功");
                result.put("data", stockDTO);
            } else {
                result.put("code", 400);
                result.put("msg", "库存记录不存在");
            }
        } catch (Exception e) {
            result.put("code", 500);
            result.put("msg", "查询库存异常：" + e.getMessage());
        }
        return result;
    }

    @Override
    public HashMap<String, Object> getStockPage(StockQueryDTO queryDTO) {
        HashMap<String, Object> result = new HashMap<>(4);
        try {
            log.info("📋 开始处理库存分页查询...");
            
            // 参数校验
            if (queryDTO == null) {
                log.warn("查询参数为null，创建默认参数");
                queryDTO = new StockQueryDTO();
            }
            
            // 设置默认值
            if (queryDTO.getPageNum() == null || queryDTO.getPageNum() <= 0) {
                queryDTO.setPageNum(1);
            }
            if (queryDTO.getPageSize() == null || queryDTO.getPageSize() <= 0 || queryDTO.getPageSize() > 100) {
                queryDTO.setPageSize(10);
            }
            
            // 计算偏移量
            int originalPageNum = queryDTO.getPageNum();
            int pageSize = queryDTO.getPageSize();
            int offset = (originalPageNum - 1) * pageSize;
            
            // 构建Map参数
            Map<String, Object> params = new HashMap<>();
            params.put("goodsName", queryDTO.getGoodsName());
            params.put("warehouseName", queryDTO.getWarehouseName());
            params.put("offset", offset);
            params.put("limit", pageSize);
            
            log.info("📊 查询参数: {}", params);
            
            // 查询列表
            List<StockDTO> stockList = stockMapper.selectPage(params);
            
            // 查询总数（只用查询条件，不需要分页参数）
            Map<String, Object> countParams = new HashMap<>();
            countParams.put("goodsName", queryDTO.getGoodsName());
            countParams.put("warehouseName", queryDTO.getWarehouseName());
            Integer total = stockMapper.selectTotal(countParams);
            
            log.info("✅ 查询成功: 获取{}条数据，总数{}", 
                    stockList != null ? stockList.size() : 0, total);
            
            // 组装返回结果
            result.put("code", 200);
            result.put("msg", "查询成功");
            result.put("data", stockList != null ? stockList : new ArrayList<>());
            result.put("total", total != null ? total : 0);
            result.put("pageNum", originalPageNum);
            result.put("pageSize", pageSize);
            
        } catch (Exception e) {
            log.error("💥 分页查询异常", e);
            result.put("code", 500);
            result.put("msg", "分页查询异常：" + (e.getMessage() != null ? e.getMessage() : "未知错误"));
            result.put("data", new ArrayList<>());
            result.put("total", 0);
        }
        return result;
    }

}