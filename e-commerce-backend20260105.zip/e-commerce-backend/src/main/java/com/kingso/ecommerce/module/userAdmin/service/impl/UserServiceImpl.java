// com/kingso/ecommerce/module/user/service/impl/UserServiceImpl.java
package com.kingso.ecommerce.module.userAdmin.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.kingso.ecommerce.module.userAdmin.dto.UserAddDTO;
import com.kingso.ecommerce.module.userAdmin.dto.UserQueryDTO;
import com.kingso.ecommerce.module.userAdmin.dto.UserUpdateDTO;
import com.kingso.ecommerce.module.userAdmin.entity.User;
import com.kingso.ecommerce.module.userAdmin.mapper.UserMapper;
import com.kingso.ecommerce.module.userAdmin.service.UserService;

/**
 * 用户服务实现类
 */
@Service
public class UserServiceImpl implements UserService {

    private final UserMapper userMapper;

    // 构造器注入
    public UserServiceImpl(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    @Override
    public void addUser(UserAddDTO addDTO) {
        // 参数校验
        Assert.notNull(addDTO, "新增用户参数不能为空");
        // 校验用户名唯一性
        User existUser = userMapper.selectByUsername(addDTO.getUsername());
        Assert.isNull(existUser, "用户名已存在，请修改！");
        //校验手机号唯一性
        User existPhone = userMapper.selectByPhone(addDTO.getPhone());
        Assert.isNull(existPhone, "手机号已存在，请修改！");
        // DTO转实体
        User user = new User();
        user.setUsername(addDTO.getUsername());
        user.setPassword(addDTO.getPassword()); // 实际开发需加密（如BCrypt）
        user.setPhone(addDTO.getPhone());
        user.setEmail(addDTO.getEmail());
        user.setStatus(addDTO.getStatus());

        // 调用Mapper新增
        userMapper.insert(user);
    }

    @Override
    public void updateUser(UserUpdateDTO updateDTO) {
        // 参数校验
        Assert.notNull(updateDTO, "更新用户参数不能为空");
        Long userId = updateDTO.getId();
        User existUser = userMapper.selectById(userId);
        Assert.notNull(existUser, "用户不存在");

        // 若更新用户名，需校验唯一性（排除当前用户）
        String newUsername = updateDTO.getUsername();
        if (newUsername != null && !newUsername.equals(existUser.getUsername())) {
            User usernameUser = userMapper.selectByUsername(newUsername);
            Assert.isNull(usernameUser, "用户名已存在");
        }

        // DTO转实体
        User user = new User();
        user.setId(userId);
        user.setUsername(newUsername);
        user.setPhone(updateDTO.getPhone());
        user.setEmail(updateDTO.getEmail());
        user.setStatus(updateDTO.getStatus());

        // 调用Mapper更新
        userMapper.updateById(user);
    }

    @Override
    public void deleteUser(Long id) {
        Assert.notNull(id, "用户ID不能为空");
        Assert.isTrue(id > 0, "用户ID必须为正整数");
        // 校验用户存在
        User existUser = userMapper.selectById(id);
        Assert.notNull(existUser, "用户不存在");
        // 调用Mapper删除
        userMapper.deleteById(id);
    }

    @Override
    public User getUserById(Long id) {
        Assert.notNull(id, "用户ID不能为空");
        Assert.isTrue(id > 0, "用户ID必须为正整数");
        return userMapper.selectById(id);
    }

    @Override
    public Map<String, Object> getUserPage(UserQueryDTO queryDTO) {
        // 计算分页起始位置（pageNum从1开始）
        int offset = (queryDTO.getPageNum() - 1) * queryDTO.getPageSize();
        queryDTO.setPageNum(offset);

        // 查询列表和总数
        List<User> userList = userMapper.selectPage(queryDTO);
        Integer total = userMapper.selectTotal(queryDTO);

        // 封装分页结果
        Map<String, Object> result = new HashMap<>();
        result.put("list", userList);
        result.put("total", total);
        result.put("pageNum", queryDTO.getPageNum() + 1); // 恢复原页码
        result.put("pageSize", queryDTO.getPageSize());
        return result;
    }
}