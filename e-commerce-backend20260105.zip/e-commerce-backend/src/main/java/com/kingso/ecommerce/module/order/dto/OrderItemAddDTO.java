// com/kingso/ecommerce/module/order/dto/OrderItemAddDTO.java
package com.kingso.ecommerce.module.order.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;
import java.math.BigDecimal;

/**
 * 订单明细新增DTO
 */
@Data
public class OrderItemAddDTO {
    /**
     * 商品ID（必传）
     */
    @NotNull(message = "商品ID不能为空")
    @Positive(message = "商品ID必须为正整数")
    private Long goodsId;

    /**
     * 商品名称（必传，下单快照）
     */
    @NotNull(message = "商品名称不能为空")
    private String goodsName;

    /**
     * 商品单价（必传，下单快照）
     */
    @NotNull(message = "商品单价不能为空")
    @Positive(message = "商品单价必须大于0")
    private BigDecimal goodsPrice;

    /**
     * 商品数量（必传，大于0）
     */
    @NotNull(message = "商品数量不能为空")
    @Positive(message = "商品数量必须大于0")
    private Integer num;

    /**
     * 仓库ID（必传，用于库存扣减）
     */
    @NotNull(message = "仓库ID不能为空")
    @Positive(message = "仓库ID必须为正整数")
    private Long warehouseId;

    /**
     * 该商品总金额（自动计算：goodsPrice * num，也可前端传入）
     */
    private BigDecimal totalPrice;
}