// com/kingso/ecommerce/module/procurement/mapper/ProcurementOrderItemMapper.java
package com.kingso.ecommerce.module.procurement.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.kingso.ecommerce.module.procurement.entity.ProcurementOrderItem;

/**
 * 采购订单明细Mapper接口
 */
@Mapper
public interface ProcurementOrderItemMapper {
    /**
     * 批量新增采购订单明细
     */
    void batchInsert(List<ProcurementOrderItem> itemList);

    /**
     * 根据采购订单ID查询明细列表
     */
    List<ProcurementOrderItem> selectByProcurementOrderId(Long procurementOrderId);
    /**
     * 条码模糊查询采购明细
     */
    List<ProcurementOrderItem> selectByBarcodeLike(@Param("barcode") String barcode);
    List<ProcurementOrderItem> selectOrderItemById(Long id);
}