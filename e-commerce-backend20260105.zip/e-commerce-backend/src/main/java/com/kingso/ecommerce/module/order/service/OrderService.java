// com/kingso/ecommerce/module/order/service/OrderService.java
package com.kingso.ecommerce.module.order.service;

import java.util.Map;

import com.kingso.ecommerce.module.order.dto.OrderAddDTO;
import com.kingso.ecommerce.module.order.dto.OrderQueryDTO;
import com.kingso.ecommerce.module.order.dto.OrderUpdateDTO;
import com.kingso.ecommerce.module.order.entity.Order;

/**
 * 订单服务接口（整合主表+明细）
 */
public interface OrderService {
    /**
     * 新增订单（含明细，事务保证一致性）
     */
    void addOrder(OrderAddDTO addDTO);

    /**
     * 更新订单
     */
    void updateOrder(OrderUpdateDTO updateDTO);

    /**
     * 根据ID删除订单（同步删除明细，事务保证一致性）
     */
    void deleteOrder(Long id);

    /**
     * 根据ID查询订单（不含明细）
     */
    Order getOrderById(Long id);

    /**
     * 根据ID查询订单及明细（关联查询）
     * @return Map：key=order（订单主信息），key=orderItemList（明细列表）
     */
    Map<String, Object> getOrderWithItemById(Long id);

    /**
     * 根据订单编号查询订单
     */
    Order getOrderByOrderNo(String orderNo);

    /**
     * 分页查询订单列表（多条件筛选）
     */
    Map<String, Object> getOrderPage(OrderQueryDTO queryDTO);

    /**
     * 取消订单（状态改为9：已取消）
     */
    void cancelOrder(Long id);

    /**
     * 确认收货（状态改为2：待收货）
     */
    void confirmOrder(Long id);

    /**
     * 删除订单（状态改为8：已删除）
     */
    void deleteOrderStatus(Long id);

    /**
     * 已完成订单（状态改为3：已完成）
     */
    void completeOrder(Long id);
}