// com/kingso/ecommerce/module/order/service/impl/OrderServiceImpl.java
package com.kingso.ecommerce.module.order.service.impl;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.kingso.ecommerce.module.order.dto.OrderAddDTO;
import com.kingso.ecommerce.module.order.dto.OrderQueryDTO;
import com.kingso.ecommerce.module.order.dto.OrderUpdateDTO;
import com.kingso.ecommerce.module.order.entity.Order;
import com.kingso.ecommerce.module.order.entity.OrderItem;
import com.kingso.ecommerce.module.order.mapper.OrderMapper;
import com.kingso.ecommerce.module.order.service.OrderItemService;
import com.kingso.ecommerce.module.order.service.OrderService;

/**
 * 订单服务实现类（整合主表+明细，事务保证数据一致性）
 */
@Service
public class OrderServiceImpl implements OrderService {

    private final OrderMapper orderMapper;
    private final OrderItemService orderItemService;

    // 构造器注入
    public OrderServiceImpl(OrderMapper orderMapper, OrderItemService orderItemService) {
        this.orderMapper = orderMapper;
        this.orderItemService = orderItemService;
    }

    /**
     * 新增订单（含明细）：事务保证“主表+明细”同时成功/失败
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void addOrder(OrderAddDTO addDTO) {
        // 参数校验
        Assert.notNull(addDTO, "新增订单参数不能为空");
        Assert.notNull(addDTO.getUserId(), "用户ID不能为空");
        Assert.isTrue(addDTO.getUserId() > 0, "用户ID必须为正整数");
        Assert.notNull(addDTO.getTotalAmount(), "订单总金额不能为空");
        Assert.isTrue(addDTO.getTotalAmount().compareTo(BigDecimal.ZERO) > 0, "订单总金额必须大于0");
        Assert.isTrue(StringUtils.hasText(addDTO.getReceiverName()), "收货人姓名不能为空");
        Assert.isTrue(StringUtils.hasText(addDTO.getReceiverPhone()), "收货人手机号不能为空");
        Assert.isTrue(StringUtils.hasText(addDTO.getReceiverAddress()), "收货人地址不能为空");
        Assert.notNull(addDTO.getOrderItemList(), "订单明细不能为空");
        Assert.isTrue(!CollectionUtils.isEmpty(addDTO.getOrderItemList()), "订单明细至少包含1条商品");

        // 校验订单总金额与明细总金额一致
        BigDecimal itemTotalAmount = addDTO.getOrderItemList().stream()
                .map(dto -> dto.getGoodsPrice().multiply(new BigDecimal(dto.getNum())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        Assert.isTrue(addDTO.getTotalAmount().compareTo(itemTotalAmount) == 0,
                "订单总金额与商品明细总金额不一致");

        // 生成唯一订单编号（时间戳+UUID，保证唯一性）
        String orderNo = "ORD" + System.currentTimeMillis() + UUID.randomUUID().toString().substring(0, 6).toUpperCase();

        // DTO转订单主表实体
        Order order = new Order();
        order.setOrderNo(orderNo);
        order.setUserId(addDTO.getUserId());
        order.setTotalAmount(addDTO.getTotalAmount());
        order.setReceiverName(addDTO.getReceiverName());
        order.setReceiverPhone(addDTO.getReceiverPhone());
        order.setReceiverAddress(addDTO.getReceiverAddress());
        order.setStatus(addDTO.getStatus());
        order.setRemark(addDTO.getRemark());
        order.setPayWay(addDTO.getPayWay());
        // 新增订单主表（获取自增ID）
        orderMapper.insert(order);
        Long orderId = order.getId(); // 自增ID赋值给order.id

        // 批量新增订单明细（关联订单ID）
        orderItemService.batchAddOrderItem(orderId, addDTO.getOrderItemList());
    }

    @Override
    public void updateOrder(OrderUpdateDTO updateDTO) {
        // 参数校验
        Assert.notNull(updateDTO, "更新订单参数不能为空");
        Long orderId = updateDTO.getId();
        Assert.notNull(orderId, "订单ID不能为空");
        Assert.isTrue(orderId > 0, "订单ID必须为正整数");

        // 校验订单是否存在
        Order existOrder = orderMapper.selectById(orderId);
        Assert.notNull(existOrder, "订单不存在");

        // DTO转订单实体（仅更新非空字段）
        Order order = new Order();
        order.setId(orderId);
        order.setReceiverName(updateDTO.getReceiverName());
        order.setReceiverPhone(updateDTO.getReceiverPhone());
        order.setReceiverAddress(updateDTO.getReceiverAddress());
        order.setStatus(updateDTO.getStatus());
        order.setPayTime(updateDTO.getPayTime());
        order.setReceiveTime(updateDTO.getReceiveTime());
        order.setCancelTime(updateDTO.getCancelTime());
        order.setTotalAmount(updateDTO.getTotalAmount());
        order.setRemark(updateDTO.getRemark());
        order.setExpressName(updateDTO.getExpressName());
        order.setExpressId(updateDTO.getExpressId());
        order.setExpressOperator(updateDTO.getExpressOperator());
        order.setExpressNo(updateDTO.getExpressNo());
        order.setExpressRemark(updateDTO.getExpressRemark());

        // 更新订单主表
        orderMapper.updateById(order);
    }

    /**
     * 删除订单：先删明细，再删主表，事务保证一致性
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteOrder(Long id) {
        // 参数校验
        Assert.notNull(id, "订单ID不能为空");
        Assert.isTrue(id > 0, "订单ID必须为正整数");

        // 校验订单是否存在
        Order existOrder = orderMapper.selectById(id);
        Assert.notNull(existOrder, "订单不存在");

        // 先批量删除订单明细
        orderItemService.batchDeleteOrderItemByOrderId(id);

        // 再删除订单主表
        orderMapper.deleteById(id);
    }

    @Override
    public Order getOrderById(Long id) {
        Assert.notNull(id, "订单ID不能为空");
        Assert.isTrue(id > 0, "订单ID必须为正整数");
        return orderMapper.selectById(id);
    }

    @Override
    public Map<String, Object> getOrderWithItemById(Long id) {
        // 参数校验
        Assert.notNull(id, "订单ID不能为空");
        Assert.isTrue(id > 0, "订单ID必须为正整数");

        // 查询订单主信息
        Order order = orderMapper.selectById(id);
        Assert.notNull(order, "订单不存在");

        // 查询订单明细列表
        List<OrderItem> orderItemList = orderItemService.getOrderItemListByOrderId(id);

        // 封装结果
        Map<String, Object> result = new HashMap<>();
        result.put("order", order);
        result.put("orderItemList", orderItemList);
        return result;
    }

    @Override
    public Order getOrderByOrderNo(String orderNo) {
        Assert.notNull(orderNo, "订单编号不能为空");
        Assert.isTrue(StringUtils.hasText(orderNo.trim()), "订单编号不能为空字符串");
        return orderMapper.selectByOrderNo(orderNo);
    }

    @Override
    public Map<String, Object> getOrderPage(OrderQueryDTO queryDTO) {
        // 保存原始页码
        int originalPageNum = queryDTO.getPageNum();
        
        // 计算分页偏移量（pageNum从1开始，转成数据库LIMIT的偏移量）
        int offset = (originalPageNum - 1) * queryDTO.getPageSize();
        queryDTO.setPageNum(offset);

        // 查询订单列表和总数
        List<Order> orderList = orderMapper.selectPage(queryDTO);
        Integer total = orderMapper.selectTotal(queryDTO);

        // 封装分页结果（恢复原始页码）
        Map<String, Object> result = new HashMap<>();
        result.put("list", orderList);
        result.put("total", total);
        result.put("pageNum", originalPageNum);
        result.put("pageSize", queryDTO.getPageSize());
        return result;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void cancelOrder(Long id) {
        // 参数校验
        Assert.notNull(id, "订单ID不能为空");
        Assert.isTrue(id > 0, "订单ID必须为正整数");

        // 校验订单是否存在
        Order existOrder = orderMapper.selectById(id);
        Assert.notNull(existOrder, "订单不存在");

        // 更新订单状态为9（已取消），并设置取消时间
        Order order = new Order();
        order.setId(id);
        order.setStatus(9);
        order.setCancelTime(LocalDateTime.now());
        orderMapper.updateById(order);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void confirmOrder(Long id) {
        // 参数校验
        Assert.notNull(id, "订单ID不能为空");
        Assert.isTrue(id > 0, "订单ID必须为正整数");

        // 校验订单是否存在
        Order existOrder = orderMapper.selectById(id);
        Assert.notNull(existOrder, "订单不存在");

        // 更新订单状态为2（待收货），并设置收货时间
        Order order = new Order();
        order.setId(id);
        order.setStatus(2);
        order.setReceiveTime(LocalDateTime.now());
        orderMapper.updateById(order);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteOrderStatus(Long id) {
        // 参数校验
        Assert.notNull(id, "订单ID不能为空");
        Assert.isTrue(id > 0, "订单ID必须为正整数");

        // 校验订单是否存在
        Order existOrder = orderMapper.selectById(id);
        Assert.notNull(existOrder, "订单不存在");

        // 更新订单状态为8（已删除），逻辑删除
        Order order = new Order();
        order.setId(id);
        order.setStatus(8);
        orderMapper.updateById(order);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void completeOrder(Long id) {
        // 参数校验
        Assert.notNull(id, "订单ID不能为空");
        Assert.isTrue(id > 0, "订单ID必须为正整数");

        // 校验订单是否存在
        Order existOrder = orderMapper.selectById(id);
        Assert.notNull(existOrder, "订单不存在");

        // 更新订单状态为3（已完成）
        Order order = new Order();
        order.setId(id);
        order.setStatus(3);
        orderMapper.updateById(order);
    }
}