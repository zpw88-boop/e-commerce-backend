package com.kingso.ecommerce.module.express.controller;

import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kingso.ecommerce.common.result.Result;
import com.kingso.ecommerce.module.express.dto.ExpressAddDTO;
import com.kingso.ecommerce.module.express.dto.ExpressDeleteDTO;
import com.kingso.ecommerce.module.express.dto.ExpressPageDTO;
import com.kingso.ecommerce.module.express.dto.ExpressUpdateDTO;
import com.kingso.ecommerce.module.express.entity.Express;
import com.kingso.ecommerce.module.express.service.ExpressService;

/**
 * 快递公司接口控制器
 * 接口前缀：/api/admin/express
 * 支持快递公司的新增、分页查询、编辑、删除、详情查询操作
 */
@RestController
@RequestMapping("/api/admin/express")
public class ExpressController {

    // 构造器注入ExpressService
    private final ExpressService expressService;

    public ExpressController(ExpressService expressService) {
        this.expressService = expressService;
    }

    /**
     * 分页查询快递公司
     * @param pageNum 页码（默认1）
     * @param pageSize 每页条数（默认10）
     * @param expressName 快递公司名称（模糊查询，可选）
     * @return 分页结果
     */
    @GetMapping("/page")
    public Result<ExpressPageDTO> getExpressPage(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) String expressName
    ) {
        // 校验分页参数合法性
        if (pageNum <= 0) {
            return Result.fail("页码必须为正整数");
        }
        if (pageSize <= 0) {
            return Result.fail("每页条数必须为正整数");
        }

        // 调用Service查询分页数据
        ExpressPageDTO expressPage = expressService.getExpressPage(pageNum, pageSize, expressName);
        return Result.success(expressPage, "查询到" + expressPage.getTotal() + "条快递公司数据");
    }

    /**
     * 新增快递公司
     * @param expressAddDTO 新增参数
     * @param bindingResult 参数校验结果
     * @return 统一响应结果
     */
    @PostMapping("/add")
    public Result<Boolean> addExpress(@RequestBody @Validated ExpressAddDTO expressAddDTO, BindingResult bindingResult) {
        // 处理参数校验错误
        if (bindingResult.hasErrors()) {
            String errorMsg = buildValidationErrorMessage(bindingResult);
            return Result.fail(errorMsg);
        }

        // 调用Service新增快递公司
        expressService.addExpress(expressAddDTO);
        return Result.success(true, "新增快递公司成功");
    }

    /**
     * 编辑快递公司
     * @param expressUpdateDTO 编辑参数
     * @param bindingResult 参数校验结果
     * @return 统一响应结果
     */
    @PutMapping("/update")
    public Result<Boolean> updateExpress(@RequestBody @Validated ExpressUpdateDTO expressUpdateDTO, BindingResult bindingResult) {
        // 处理参数校验错误
        if (bindingResult.hasErrors()) {
            String errorMsg = buildValidationErrorMessage(bindingResult);
            return Result.fail(errorMsg);
        }

        try {
            // 调用Service编辑快递公司
            expressService.updateExpress(expressUpdateDTO);
            return Result.success(true, "编辑快递公司成功");
        } catch (IllegalArgumentException e) {
            return Result.fail(e.getMessage());
        }
    }

    /**
     * 删除快递公司
     * @param expressDeleteDTO 删除参数
     * @param bindingResult 参数校验结果
     * @return 统一响应结果
     */
    @DeleteMapping("/delete")
    public Result<Boolean> deleteExpress(@RequestBody @Validated ExpressDeleteDTO expressDeleteDTO, BindingResult bindingResult) {
        // 处理参数校验错误
        if (bindingResult.hasErrors()) {
            String errorMsg = buildValidationErrorMessage(bindingResult);
            return Result.fail(errorMsg);
        }

        try {
            // 调用Service删除快递公司
            expressService.deleteExpress(expressDeleteDTO);
            return Result.success(true, "删除快递公司成功");
        } catch (IllegalArgumentException e) {
            return Result.fail(e.getMessage());
        }
    }

    /**
     * 根据ID查询快递公司详情
     * @param id 快递公司ID
     * @return 快递公司详情
     */
    @GetMapping("/{id}")
    public Result<Express> getExpressById(@PathVariable Integer id) {
        // 校验快递公司ID合法性
        if (id == null || id <= 0) {
            return Result.fail("快递公司ID必须为正整数");
        }

        // 调用Service查询详情
        Express express = expressService.getExpressById(id);
        if (express == null) {
            return Result.fail("该快递公司不存在");
        }
        return Result.success(express, "查询快递公司详情成功");
    }

    /**
     * 抽取公共方法：构建参数校验错误信息
     * @param bindingResult 校验结果
     * @return 拼接后的错误提示
     */
    private String buildValidationErrorMessage(BindingResult bindingResult) {
        return bindingResult.getFieldErrors().stream()
                .map(FieldError::getDefaultMessage)
                .reduce((msg1, msg2) -> msg1 + "；" + msg2)
                .orElse("参数校验失败");
    }
}

