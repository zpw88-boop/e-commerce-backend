// com/kingso/ecommerce/module/user/dto/UserQueryDTO.java
package com.kingso.ecommerce.module.userAdmin.dto;

import lombok.Data;

/**
 * 用户查询参数DTO
 */
@Data
public class UserQueryDTO {
    /**
     * 用户名（模糊查询）
     */
    private String username;

    /**
     * 状态（0-禁用，1-正常，null-查询全部）
     */
    private Integer status;

    /**
     * 用户类型（0-普通用户，1-管理员，null-查询全部）
     */
    private Integer userType;

    /**
     * 页码（默认1）
     */
    private Integer pageNum = 1;

    /**
     * 每页条数（默认10）
     */
    private Integer pageSize = 10;
}