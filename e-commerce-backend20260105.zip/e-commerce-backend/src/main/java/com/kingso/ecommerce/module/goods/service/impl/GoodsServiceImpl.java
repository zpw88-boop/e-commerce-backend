package com.kingso.ecommerce.module.goods.service.impl;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.kingso.ecommerce.module.goods.dto.GoodsAddDTO;
import com.kingso.ecommerce.module.goods.dto.GoodsQueryDTO;
import com.kingso.ecommerce.module.goods.entity.Goods;
import com.kingso.ecommerce.module.goods.mapper.GoodsMapper;
import com.kingso.ecommerce.module.goods.service.IGoodsService;

@Service
@Transactional
public class GoodsServiceImpl implements IGoodsService {

    @Value("${goods.upload.base-path}")
    private String relativePath; // 相对路径（static/images/goods/）

    @Value("${goods.upload.base-url}")
    private String baseUrl;

    private final GoodsMapper goodsMapper;

    public GoodsServiceImpl(GoodsMapper goodsMapper) {
        this.goodsMapper = goodsMapper;
    }

    // 图片上传逻辑
    @Override
    public String uploadGoodsImg(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("请选择非空的图片文件");
        }
        String originalFilename = file.getOriginalFilename();
        if (originalFilename == null || originalFilename.trim().isEmpty()) {
            throw new IllegalArgumentException("文件名称不能为空或空白");
        }
        originalFilename = originalFilename.trim();
        int dotIndex = originalFilename.lastIndexOf('.');
        String suffix = "";
        if (dotIndex > 0 && dotIndex < originalFilename.length() - 1) {
            suffix = originalFilename.substring(dotIndex).toLowerCase();
        } else {
            throw new IllegalArgumentException("上传的文件无有效后缀，仅支持jpg、jpeg、png、gif格式");
        }
        List<String> allowedSuffixes = List.of(".jpg", ".jpeg", ".png", ".gif");
        if (!allowedSuffixes.contains(suffix)) {
            throw new IllegalArgumentException("仅支持jpg、jpeg、png、gif格式图片，当前后缀：" + suffix);
        }
        long maxSize = 5 * 1024 * 1024;
        if (file.getSize() > maxSize) {
            throw new IllegalArgumentException("图片大小不能超过5MB，当前大小：" + (file.getSize() / 1024 / 1024) + "MB");
        }

        String projectRootPath = System.getProperty("user.dir");
        String fullBasePath = projectRootPath + File.separator + relativePath;
        File baseDir = new File(fullBasePath);

        if (!baseDir.exists()) {
            boolean mkdirsSuccess = baseDir.mkdirs();
            if (!mkdirsSuccess) {
                throw new RuntimeException("商品图片存储文件夹创建失败");
            }
        }

        String uniqueFileName = System.currentTimeMillis() + suffix;
        String fullFilePath = fullBasePath + uniqueFileName;
        try {
            file.transferTo(new File(fullFilePath));
            return baseUrl + uniqueFileName;
        } catch (IOException e) {
            throw new RuntimeException("图片保存到服务器失败：" + e.getMessage());
        }
    }

    // 新增商品
    @Override
    public void addGoods(GoodsAddDTO goodsAddDTO) {
        // 将DTO转换为实体类
        Goods goods = new Goods();
        BeanUtils.copyProperties(goodsAddDTO, goods);
        // 调用Mapper新增
        goodsMapper.addGoods(goods);
    }

    // 根据ID查询商品
    @Override
    public Goods getGoodsById(Long id) {
        if (id == null || id <= 0) {
            throw new IllegalArgumentException("商品ID必须为正整数");
        }
        return goodsMapper.getGoodsById(id);
    }

    // 条件查询商品列表
    @Override
    public List<Goods> getGoodsList(GoodsQueryDTO goodsQueryDTO) {
        return goodsMapper.getGoodsList(goodsQueryDTO);
    }

    // 分页查询商品
    @Override
    public Map<String, Object> pageGoods(GoodsQueryDTO goodsQueryDTO) {
        // 参数兜底
        if (goodsQueryDTO.getPageNum() == null || goodsQueryDTO.getPageNum() < 1) {
            goodsQueryDTO.setPageNum(1);
        }
        if (goodsQueryDTO.getPageSize() == null || goodsQueryDTO.getPageSize() < 1) {
            goodsQueryDTO.setPageSize(10);
        }
        // 计算偏移量（与XML的LIMIT offset, pageSize匹配）
        goodsQueryDTO.setOffset((goodsQueryDTO.getPageNum() - 1) * goodsQueryDTO.getPageSize());

        // 调用Mapper
        List<Goods> goodsList = goodsMapper.getGoodsList(goodsQueryDTO);
        Long total = goodsMapper.getGoodsTotal(goodsQueryDTO); // 注意返回值是Long

        // 组装返回数据
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("list", goodsList);
        resultMap.put("total", total);
        resultMap.put("pageNum", goodsQueryDTO.getPageNum());
        resultMap.put("pageSize", goodsQueryDTO.getPageSize());
        resultMap.put("totalPages", (total + goodsQueryDTO.getPageSize() - 1) / goodsQueryDTO.getPageSize());

        return resultMap;
    }

    // 修改商品
    @Override
    public void updateGoods(Long id, GoodsAddDTO goodsAddDTO) {
        if (id == null || id <= 0) {
            throw new IllegalArgumentException("商品ID必须为正整数");
        }
        // DTO转实体
        Goods goods = new Goods();
        BeanUtils.copyProperties(goodsAddDTO, goods);
        // 调用Mapper更新
        goodsMapper.updateGoods(id, goods);
    }

    // 修改商品
    @Override
    public void updateGoods(GoodsAddDTO goodsAddDTO) {
        if (goodsAddDTO.getId() == null || goodsAddDTO.getId() <= 0) {
            throw new IllegalArgumentException("商品ID必须为正整数");
        }
        Goods goods = new Goods();
        BeanUtils.copyProperties(goodsAddDTO, goods);
        goodsMapper.updateGoods(goodsAddDTO.getId(), goods);
    }

    // 上下架商品
    @Override
    public void updateGoodsStatus(Long id, Integer status) {
        if (id == null || id <= 0) {
            throw new IllegalArgumentException("商品ID必须为正整数");
        }
        if (status == null || (status != 0 && status != 1)) {
            throw new IllegalArgumentException("商品状态只能是0（下架）或1（上架）");
        }
        goodsMapper.updateGoodsStatus(id, status);
    }

    // 删除商品
    @Override
    public void deleteGoods(Long id) {
        if (id == null || id <= 0) {
            throw new IllegalArgumentException("商品ID必须为正整数");
        }
        goodsMapper.deleteGoods(id);
    }
}