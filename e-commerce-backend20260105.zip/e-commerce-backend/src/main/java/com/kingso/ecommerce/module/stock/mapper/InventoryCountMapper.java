package com.kingso.ecommerce.module.stock.mapper;


import com.kingso.ecommerce.module.stock.entity.InventoryCount;

public interface InventoryCountMapper {

    /**
     * 插入库存调整记录
     * @param inventoryCount 盘点记录实体
     * @return 受影响的行数
     */
    int insertInventoryCount(InventoryCount inventoryCount);
}