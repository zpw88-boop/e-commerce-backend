package com.kingso.ecommerce.module.goodsCategory.entity;

import java.io.Serializable;

import lombok.Data;

/**
 * 商品分类实体类
 * 对应数据库表 tb_goods_category
 */
@Data
public class GoodsCategory implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 分类ID
     */
    private Long id;

    /**
     * 分类名称
     */
    private String categoryName;

    /**
     * 父分类ID（0：一级分类）
     */
    private Long parentId = 0L;

    /**
     * 排序号
     */
    private Integer sort = 0;

    /**
     * 状态（0：禁用，1：正常）
     */
    private Integer status = 1;
}