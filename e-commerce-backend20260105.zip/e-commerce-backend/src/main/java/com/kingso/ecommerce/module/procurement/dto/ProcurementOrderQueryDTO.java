package com.kingso.ecommerce.module.procurement.dto;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * 采购订单查询参数DTO（支持多条件筛选+分页）
 */
@Data
public class ProcurementOrderQueryDTO {
    /**
     * 采购单号（模糊查询）
     */
    private String procurementNo;

    /**
     * 操作员ID（精确查询）
     */
    private Long operatorId;

    /**
     * 仓库ID（精确查询）
     */
    @JsonProperty("warehouse_id")
    private Long warehouseId;

    /**
     * 页码（默认1）
     */
    private Integer pageNum = 1;

    /**
     * 每页条数（默认10）
     */
    private Integer pageSize = 10;
    // 创建时间区间字段
    private String startTime; 
    private String endTime;
}