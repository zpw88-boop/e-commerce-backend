package com.kingso.ecommerce.module.express.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.kingso.ecommerce.module.express.dto.ExpressAddDTO;
import com.kingso.ecommerce.module.express.dto.ExpressDeleteDTO;
import com.kingso.ecommerce.module.express.dto.ExpressPageDTO;
import com.kingso.ecommerce.module.express.dto.ExpressUpdateDTO;
import com.kingso.ecommerce.module.express.entity.Express;
import com.kingso.ecommerce.module.express.mapper.ExpressMapper;
import com.kingso.ecommerce.module.express.service.ExpressService;

/**
 * 快递公司 Service 实现类
 */
@Service
@Transactional
public class ExpressServiceImpl implements ExpressService {

    @Autowired
    private ExpressMapper expressMapper;

    /**
     * 分页查询快递公司（原生分页）
     */
    @Override
    public ExpressPageDTO getExpressPage(Integer pageNum, Integer pageSize, String expressName) {
        // 参数合法性校验
        Assert.notNull(pageNum, "页码不能为空");
        Assert.notNull(pageSize, "每页条数不能为空");
        Assert.isTrue(pageNum > 0, "页码必须为正整数");
        Assert.isTrue(pageSize > 0, "每页条数必须为正整数");

        // 计算偏移量
        Integer offset = (pageNum - 1) * pageSize;
        // 查询分页列表
        List<Express> expressList = expressMapper.selectExpressPage(expressName, offset, pageSize);
        // 查询总条数
        Long total = expressMapper.selectExpressTotal(expressName);

        // 封装分页结果
        ExpressPageDTO pageDTO = new ExpressPageDTO();
        pageDTO.setTotal(total);
        pageDTO.setExpressList(expressList);
        return pageDTO;
    }

    /**
     * 新增快递公司
     */
    @Override
    public void addExpress(ExpressAddDTO expressAddDTO) {
        Assert.notNull(expressAddDTO, "快递公司新增参数不能为空");
        expressMapper.insertExpress(expressAddDTO);
    }

    /**
     * 编辑快递公司
     */
    @Override
    public void updateExpress(ExpressUpdateDTO expressUpdateDTO) {
        Assert.notNull(expressUpdateDTO, "快递公司编辑参数不能为空");
        // 校验快递公司是否存在
        Express existExpress = expressMapper.selectExpressById(expressUpdateDTO.getId());
        Assert.notNull(existExpress, "待编辑的快递公司不存在");
        // 执行编辑
        expressMapper.updateExpress(expressUpdateDTO);
    }

    /**
     * 删除快递公司
     */
    @Override
    public void deleteExpress(ExpressDeleteDTO expressDeleteDTO) {
        Assert.notNull(expressDeleteDTO, "快递公司删除参数不能为空");
        // 校验快递公司是否存在
        Express existExpress = expressMapper.selectExpressById(expressDeleteDTO.getId());
        Assert.notNull(existExpress, "待删除的快递公司不存在");
        // 执行删除
        expressMapper.deleteExpress(expressDeleteDTO);
    }

    /**
     * 根据ID查询快递公司详情
     */
    @Override
    public Express getExpressById(Integer id) {
        Assert.notNull(id, "快递公司ID不能为空");
        return expressMapper.selectExpressById(id);
    }
}

