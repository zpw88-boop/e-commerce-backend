// com/kingso/ecommerce/module/procurement/dto/ProcurementOrderItemAddDTO.java
package com.kingso.ecommerce.module.procurement.dto;

import java.math.BigDecimal;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

/**
 * 采购订单明细新增DTO
 */
@Data
public class ProcurementOrderItemAddDTO {

    @NotBlank(message = "商品名称不能为空")
    private String goodsName;
    private String goodsBarcode;

    @NotNull(message = "商品ID不能为空")
    @Positive(message = "商品ID必须为正整数")
    private Long goodsId;

    private String warehouseArea;

    @NotNull(message = "商品数量不能为空")
    @Positive(message = "商品数量必须大于0")
    private Integer quantity;

    @NotNull(message = "采购金额不能为空")
    @Positive(message = "采购金额必须大于0")
    private BigDecimal procurementAmount;
}