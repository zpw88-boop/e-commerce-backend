package com.kingso.ecommerce.module.goods.mapper;
import java.util.List; 

import org.apache.ibatis.annotations.Param;

import com.kingso.ecommerce.module.goods.dto.GoodsQueryDTO;
import com.kingso.ecommerce.module.goods.entity.Goods;

public interface GoodsMapper {
    // 新增商品
    int addGoods(Goods goods);
    // 编辑商品：必须加@Param注解，声明dto和id两个参数（和XML中的dto、id对应）

    // 根据ID查询商品
    Goods getGoodsById(Long id);

    // 分页查询商品列表：单个DTO参数，无需@Param注解
    List<Goods> getGoodsList(GoodsQueryDTO goodsQueryDTO);

    // 分页查询总数：单个DTO参数，无需@Param注解
    Long getGoodsTotal(GoodsQueryDTO goodsQueryDTO);

    // 更新商品：多个参数，需加@Param区分
    int updateGoods(@Param("id") Long id, @Param("dto") Goods goods);

    // 更新商品状态：多个参数，需加@Param区分
    int updateGoodsStatus(@Param("id") Long id, @Param("status") Integer status);

    // 删除商品
    int deleteGoods(Long id);
    /**
     * 根据商品条形码查询商品信息
     * @param barcode 商品条形码
     * @return 商品实体（不存在则返回null）
     */
    Goods selectByBarcode(@Param("barcode") String barcode);
    // 根据商品ID精准查询（核心解决报错的方法）
    Goods selectById(@Param("id") Long id);
}