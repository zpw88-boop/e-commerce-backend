package com.kingso.ecommerce.module.goodsCategory.controller;

import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kingso.ecommerce.common.result.Result;
import com.kingso.ecommerce.module.goodsCategory.dto.GoodsCategoryAddDTO;
import com.kingso.ecommerce.module.goodsCategory.dto.GoodsCategoryDeleteDTO;
import com.kingso.ecommerce.module.goodsCategory.dto.GoodsCategoryPageDTO;
import com.kingso.ecommerce.module.goodsCategory.dto.GoodsCategoryUpdateDTO;
import com.kingso.ecommerce.module.goodsCategory.entity.GoodsCategory;
import com.kingso.ecommerce.module.goodsCategory.service.GoodsCategoryService;

/**
 * 商品分类接口控制器
 * 接口前缀：/api/admin/category
 * 支持商品分类的新增、分页查询、编辑、删除、详情查询操作
 */
@RestController
@RequestMapping("/api/admin/category")
public class GoodsCategoryController {

    // 构造器注入GoodsCategoryService
    private final GoodsCategoryService goodsCategoryService;

    public GoodsCategoryController(GoodsCategoryService goodsCategoryService) {
        this.goodsCategoryService = goodsCategoryService;
    }

    /**
     * 分页查询商品分类
     * @param pageNum 页码（默认1）
     * @param pageSize 每页条数（默认10）
     * @param categoryName 分类名称（模糊查询，可选）
     * @return 分页结果
     */
    @GetMapping("/page")
    public Result<GoodsCategoryPageDTO> getCategoryPage(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) String categoryName
    ) {
        // 校验分页参数合法性
        if (pageNum <= 0) {
            return Result.fail("页码必须为正整数");
        }
        if (pageSize <= 0) {
            return Result.fail("每页条数必须为正整数");
        }

        // 调用Service查询分页数据
        GoodsCategoryPageDTO categoryPage = goodsCategoryService.getCategoryPage(pageNum, pageSize, categoryName);
        return Result.success(categoryPage, "查询到" + categoryPage.getTotal() + "条分类数据");
    }

    /**
     * 新增商品分类
     * @param categoryAddDTO 新增参数
     * @param bindingResult 参数校验结果
     * @return 统一响应结果
     */
    @PostMapping("/add")
    public Result<Boolean> addCategory(@RequestBody @Validated GoodsCategoryAddDTO categoryAddDTO, BindingResult bindingResult) {
        // 处理参数校验错误
        if (bindingResult.hasErrors()) {
            String errorMsg = buildValidationErrorMessage(bindingResult);
            return Result.fail(errorMsg);
        }

        // 调用Service新增分类
        goodsCategoryService.addCategory(categoryAddDTO);
        return Result.success(true, "新增分类成功");
    }

    /**
     * 编辑商品分类
     * @param categoryUpdateDTO 编辑参数
     * @param bindingResult 参数校验结果
     * @return 统一响应结果
     */
    @PutMapping("/update")
    public Result<Boolean> updateCategory(@RequestBody @Validated GoodsCategoryUpdateDTO categoryUpdateDTO, BindingResult bindingResult) {
        // 处理参数校验错误
        if (bindingResult.hasErrors()) {
            String errorMsg = buildValidationErrorMessage(bindingResult);
            return Result.fail(errorMsg);
        }

        try {
            // 调用Service编辑分类
            goodsCategoryService.updateCategory(categoryUpdateDTO);
            return Result.success(true, "编辑分类成功");
        } catch (IllegalArgumentException e) {
            return Result.fail(e.getMessage());
        }
    }

    /**
     * 删除商品分类
     * @param categoryDeleteDTO 删除参数
     * @param bindingResult 参数校验结果
     * @return 统一响应结果
     */
    @DeleteMapping("/delete")
    public Result<Boolean> deleteCategory(@RequestBody @Validated GoodsCategoryDeleteDTO categoryDeleteDTO, BindingResult bindingResult) {
        // 处理参数校验错误
        if (bindingResult.hasErrors()) {
            String errorMsg = buildValidationErrorMessage(bindingResult);
            return Result.fail(errorMsg);
        }

        try {
            // 调用Service删除分类
            goodsCategoryService.deleteCategory(categoryDeleteDTO);
            return Result.success(true, "删除分类成功");
        } catch (IllegalArgumentException e) {
            return Result.fail(e.getMessage());
        }
    }

    /**
     * 根据ID查询分类详情
     * @param id 分类ID
     * @return 分类详情
     */
    @GetMapping("/{id}")
    public Result<GoodsCategory> getCategoryById(@PathVariable Long id) {
        // 校验分类ID合法性
        if (id == null || id <= 0) {
            return Result.fail("分类ID必须为正整数");
        }

        // 调用Service查询详情
        GoodsCategory category = goodsCategoryService.getCategoryById(id);
        if (category == null) {
            return Result.fail("该分类不存在");
        }
        return Result.success(category, "查询分类详情成功");
    }

    /**
     * 抽取公共方法：构建参数校验错误信息
     * @param bindingResult 校验结果
     * @return 拼接后的错误提示
     */
    private String buildValidationErrorMessage(BindingResult bindingResult) {
        return bindingResult.getFieldErrors().stream()
                .map(FieldError::getDefaultMessage)
                .reduce((msg1, msg2) -> msg1 + "；" + msg2)
                .orElse("参数校验失败");
    }
}