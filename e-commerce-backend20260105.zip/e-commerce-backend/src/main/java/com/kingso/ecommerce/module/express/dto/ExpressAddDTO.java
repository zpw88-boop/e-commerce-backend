package com.kingso.ecommerce.module.express.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * 快递公司新增DTO
 */
@Data
public class ExpressAddDTO {
    /**
     * 快递公司名称（必填）
     */
    @NotBlank(message = "快递公司名称不能为空")
    private String expressName;

    /**
     * 状态
     */
    private String status;
}

