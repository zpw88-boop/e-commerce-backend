package com.kingso.ecommerce.module.stock.dto;

import java.io.Serializable;

import lombok.Data;

/**
 * 库存调整请求DTO
 * 接收前端传递的库存调整参数
 */
@Data
public class StockAdjustDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    /** 商品ID（必填） */
    private Long goodsId;

    /** 仓库ID（必填） */
    private Long warehouseId;

    /** 操作人用户ID（必填） */
    private Long userId;

    /** 库存调整数量（正数增加，负数减少，必填） */
    private Long changeQuantity;

    /** 备注（可选） */
    private String remark;
}