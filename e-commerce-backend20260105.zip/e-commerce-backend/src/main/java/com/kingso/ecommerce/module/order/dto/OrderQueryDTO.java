// com/kingso/ecommerce/module/order/dto/OrderQueryDTO.java
package com.kingso.ecommerce.module.order.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.Data;

/**
 * 订单查询参数DTO（支持多条件筛选+分页）
 */
@Data
public class OrderQueryDTO {
    /**
     * 订单编号（模糊查询）
     */
    private String orderNo;

    /**
     * 用户ID（精确查询）
     */
    private Long userId;

    /**
     * 收货人姓名（模糊查询）
     */
    private String receiverName;

    /**
     * 订单状态（精确查询，null-查询全部）
     * 0：待支付，1：待发货，2：待收货，3：已完成，9：已取消
     */
    private Integer status;

    /**
     * 最小总金额（筛选条件）
     */
    private BigDecimal minTotalAmount;

    /**
     * 最大总金额（筛选条件）
     */
    private BigDecimal maxTotalAmount;

    /**
     * 页码（默认1）
     */
    private Integer pageNum = 1;

    /**
     * 每页条数（默认10）
     */
    private Integer pageSize = 10;

    /**
     * 开始时间（用于时间范围查询，基于创建时间）
     */
    private LocalDateTime startTime;

    /**
     * 结束时间（用于时间范围查询，基于创建时间）
     */
    private LocalDateTime endTime;
}