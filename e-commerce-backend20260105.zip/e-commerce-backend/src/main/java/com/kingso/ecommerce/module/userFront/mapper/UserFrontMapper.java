package com.kingso.ecommerce.module.userFront.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.kingso.ecommerce.module.userAdmin.entity.User;
import com.kingso.ecommerce.module.userFront.dto.UserFrontQueryDTO;
import com.kingso.ecommerce.module.userFront.dto.UserRegisterDTO;
import com.kingso.ecommerce.module.userFront.dto.UserUpdateSelfDTO;

/**
 * 前台用户Mapper接口（修正后：方法完整 + 名对应XML + 参数一致）
 * 对应 mapper.xml 文件：UserFrontMapper.xml
 */
@Mapper // 标注为MyBatis Mapper接口
public interface UserFrontMapper {

    /**
     * 插入新用户（注册功能）→ 对应XML id="insertUser"
     */
    int insertUser(UserRegisterDTO registerDTO);

    /**
     * 根据用户名查询用户（注册查重）→ 对应XML id="selectUserByUsername"
     */
    User selectUserByUsername(String username);

    /**
     * 根据手机号查询用户（注册查重） 对应XML id="selectUserByPhone"
     */
    User selectUserByPhone(String phone);

    /**
     * 根据用户ID更新个人信息 对应XML id="updateUserSelf"
     */
    int updateUserSelf(UserUpdateSelfDTO updateSelfDTO);

    /**
     * 根据用户ID查询用户信息  对应XML id="selectUserById"
     */
    User selectUserById(Long userId);

    /**
     * 分页查询前台用户列表 对应XML id="selectPage"
     */
    List<User> selectPage(UserFrontQueryDTO queryDTO);

    /**
     * 查询前台用户总数 对应XML id="selectTotal"
     */
    Integer selectTotal(UserFrontQueryDTO queryDTO);
}