package com.kingso.ecommerce.module.goods.dto;

import java.math.BigDecimal;
import java.math.RoundingMode;

import lombok.Data;

@Data
public class GoodsQueryDTO {
    private Integer pageNum = 1;
    private Integer pageSize = 10;
    private Integer offset;
    private String goodsName;
    private Integer categoryId;
    private Integer status;

    // 价格参数：手动处理类型转换，兼容 Integer/String→BigDecimal
    private BigDecimal minPrice;
    private BigDecimal maxPrice;
    private String barCode; // 条形码查询参数

    public void setMinPrice(Object minPrice) {
        if (minPrice == null) {
            this.minPrice = null;
        }
        // Integer类型直接绑定变量intVal
        else if (minPrice instanceof Integer intVal) {
            // Integer转BigDecimal，保留两位小数（四舍五入）
            this.minPrice = BigDecimal.valueOf(intVal)
                    .setScale(2, RoundingMode.HALF_UP);
        }
        // String类型直接绑定变量strVal
        else if (minPrice instanceof String strVal) {
            String trimStr = strVal.trim();
            if (!trimStr.isEmpty()) {
                try {
                    // String转BigDecimal，保留两位小数（四舍五入）
                    this.minPrice = new BigDecimal(trimStr)
                            .setScale(2, RoundingMode.HALF_UP);
                } catch (Exception e) {
                    this.minPrice = null;
                }
            } else {
                this.minPrice = null;
            }
        }
        // BigDecimal类型直接绑定变量bdVal
        else if (minPrice instanceof BigDecimal bdVal) {
            // 原生BigDecimal，保留两位小数（四舍五入）
            this.minPrice = bdVal.setScale(2, RoundingMode.HALF_UP);
        } else {
            this.minPrice = null;
        }
        // 价格≥0，否则置为null
        if (this.minPrice != null && this.minPrice.compareTo(BigDecimal.ZERO) < 0) {
            this.minPrice = null;
        }
    }

    // 使用模式匹配
    public void setMaxPrice(Object maxPrice) {
        if (maxPrice == null) {
            this.maxPrice = null;
        }
        // Integer类型绑定变量intVal
        else if (maxPrice instanceof Integer intVal) {
            this.maxPrice = BigDecimal.valueOf(intVal)
                    .setScale(2, RoundingMode.HALF_UP);
        }
        // String类型绑定变量strVal
        else if (maxPrice instanceof String strVal) {
            String trimStr = strVal.trim();
            if (!trimStr.isEmpty()) {
                try {
                    this.maxPrice = new BigDecimal(trimStr)
                            .setScale(2, RoundingMode.HALF_UP);
                } catch (Exception e) {
                    this.maxPrice = null;
                }
            } else {
                this.maxPrice = null;
            }
        }
        // BigDecimal类型绑定变量bdVal
        else if (maxPrice instanceof BigDecimal bdVal) {
            this.maxPrice = bdVal.setScale(2, RoundingMode.HALF_UP);
        } else {
            this.maxPrice = null;
        }
        // 价格≥0，否则置为null
        if (this.maxPrice != null && this.maxPrice.compareTo(BigDecimal.ZERO) < 0) {
            this.maxPrice = null;
        }
    }
}