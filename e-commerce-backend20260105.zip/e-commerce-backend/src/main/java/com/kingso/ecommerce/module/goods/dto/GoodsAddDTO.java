package com.kingso.ecommerce.module.goods.dto;

import java.math.BigDecimal;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Data;

@Data
public class GoodsAddDTO {
    private Long id;

    @NotBlank(message = "商品名称不能为空")
    private String goodsName;

    @NotNull(message = "商品价格不能为空")
    @Positive(message = "商品价格必须大于0")
    private BigDecimal goodsPrice;

    // 库存允许为0，修正校验规则
    @NotNull(message = "商品库存不能为空")
    @PositiveOrZero(message = "商品库存不能为负数")
    private Integer stock;

    @NotNull(message = "分类ID不能为空")
    @Positive(message = "分类ID必须大于0")
    private Long categoryId;

    private String goodsImg;

    @NotNull(message = "商品状态不能为空")
    private Integer status;
    //条形码
    private String barCode;
}