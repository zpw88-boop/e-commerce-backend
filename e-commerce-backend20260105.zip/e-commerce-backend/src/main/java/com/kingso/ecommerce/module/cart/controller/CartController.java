package com.kingso.ecommerce.module.cart.controller;

import java.util.List;

import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kingso.ecommerce.common.result.Result;
import com.kingso.ecommerce.module.cart.dto.CartAddDTO;
import com.kingso.ecommerce.module.cart.dto.CartDeleteDTO;
import com.kingso.ecommerce.module.cart.dto.CartUpdateDTO;
import com.kingso.ecommerce.module.cart.entity.Cart;
import com.kingso.ecommerce.module.cart.service.CartService;

/**
 * 购物车接口控制器
 * 接口前缀：/cart
 * 支持购物车的新增、查询、更新、删除操作
 */
@RestController
@RequestMapping("/cart")
public class CartController {

    // 构造器注入CartService（Spring最佳实践，避免空指针）
    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    /**
     * 新增商品到购物车（已存在则更新数量）
     * @param cartAddDTO 新增购物车参数（含userId、goodsId、num）
     * @param bindingResult 参数校验结果
     * @return 统一响应结果
     */
    @PostMapping("/add")
    public Result<Boolean> addCart(@RequestBody @Validated CartAddDTO cartAddDTO, BindingResult bindingResult) {
        // 处理参数校验错误
        if (bindingResult.hasErrors()) {
            String errorMsg = buildValidationErrorMessage(bindingResult);
            return Result.fail(errorMsg);
        }

        // 调用Service添加购物车
        cartService.addCart(cartAddDTO);
        return Result.success(true, "添加购物车成功");
    }

    /**
     * 根据用户ID查询购物车列表
     * @param userId 用户ID
     * @return 购物车列表
     */
    @GetMapping("/list/{userId}")
    public Result<List<Cart>> getCartList(@PathVariable Long userId) {
        // 校验用户ID合法性
        if (userId == null || userId <= 0) {
            return Result.fail("用户ID必须为正整数");
        }

        // 调用Service查询购物车
        List<Cart> cartList = cartService.getCartList(userId);
        return Result.success(cartList, "查询到" + cartList.size() + "件购物车商品");
    }

    /**
     * 更新购物车商品数量
     * @param cartUpdateDTO 更新参数（含id、userId、num）
     * @param bindingResult 参数校验结果
     * @return 统一响应结果
     */
    @PutMapping("/update/num")
    public Result<Boolean> updateCartNum(@RequestBody @Validated CartUpdateDTO cartUpdateDTO, BindingResult bindingResult) {
        // 处理参数校验错误
        if (bindingResult.hasErrors()) {
            String errorMsg = buildValidationErrorMessage(bindingResult);
            return Result.fail(errorMsg);
        }

        // 调用Service更新数量
        cartService.updateCartNum(cartUpdateDTO);
        return Result.success(true, "购物车商品数量更新成功");
    }

    /**
     * 删除购物车中的商品
     * @param cartDeleteDTO 删除参数（含id、userId）
     * @param bindingResult 参数校验结果
     * @return 统一响应结果
     */
    @DeleteMapping("/delete")
    public Result<Boolean> deleteCart(@RequestBody @Validated CartDeleteDTO cartDeleteDTO, BindingResult bindingResult) {
        // 处理参数校验错误
        if (bindingResult.hasErrors()) {
            String errorMsg = buildValidationErrorMessage(bindingResult);
            return Result.fail(errorMsg);
        }

        // 调用Service删除商品
        cartService.deleteCart(cartDeleteDTO);
        return Result.success(true, "购物车商品删除成功");
    }

    /**
     * 抽取公共方法：构建参数校验错误信息
     * @param bindingResult 校验结果
     * @return 拼接后的错误提示
     */
    private String buildValidationErrorMessage(BindingResult bindingResult) {
        return bindingResult.getFieldErrors().stream()
                .map(FieldError::getDefaultMessage)
                .reduce((msg1, msg2) -> msg1 + "；" + msg2)
                .orElse("参数校验失败");
    }
}