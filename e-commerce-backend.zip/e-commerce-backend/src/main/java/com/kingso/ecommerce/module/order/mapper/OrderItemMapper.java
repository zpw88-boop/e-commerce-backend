// com/kingso/ecommerce/module/order/mapper/OrderItemMapper.java
package com.kingso.ecommerce.module.order.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.kingso.ecommerce.module.order.entity.OrderItem;

/**
 * 订单明细Mapper接口（映射tb_order_item表）
 */
@Mapper
public interface OrderItemMapper {
    /**
     * 单个新增订单明细
     */
    void insert(OrderItem orderItem);

    /**
     * 批量新增订单明细（高效，推荐）
     */
    void batchInsert(List<OrderItem> orderItemList);

    /**
     * 根据订单ID查询明细列表
     */
    List<OrderItem> selectByOrderId(Long orderId);

    /**
     * 根据订单ID批量删除明细（删除订单时同步删除）
     */
    void batchDeleteByOrderId(Long orderId);

    /**
     * 根据明细ID删除
     */
    void deleteById(Long id);
}