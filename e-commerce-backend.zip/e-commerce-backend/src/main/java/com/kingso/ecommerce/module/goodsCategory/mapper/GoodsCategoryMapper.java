package com.kingso.ecommerce.module.goodsCategory.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.kingso.ecommerce.module.goodsCategory.dto.GoodsCategoryAddDTO;
import com.kingso.ecommerce.module.goodsCategory.dto.GoodsCategoryDeleteDTO;
import com.kingso.ecommerce.module.goodsCategory.dto.GoodsCategoryUpdateDTO;
import com.kingso.ecommerce.module.goodsCategory.entity.GoodsCategory;

/**
 * 商品分类 Mapper 接口
 */
@Mapper // 必须添加
public interface GoodsCategoryMapper {

    /**
     * 分页查询商品分类（原生SQL分页）
     * @param categoryName 分类名称（模糊查询，可为null）
     * @param offset 偏移量（(pageNum-1)*pageSize）
     * @param pageSize 每页条数
     * @return 分类列表
     */
    List<GoodsCategory> selectCategoryPage(@Param("categoryName") String categoryName,
                                           @Param("offset") Integer offset,
                                           @Param("pageSize") Integer pageSize);

    /**
     * 查询分类总条数
     * @param categoryName 分类名称（模糊查询，可为null）
     * @return 总记录数
     */
    Long selectCategoryTotal(@Param("categoryName") String categoryName);

    /**
     * 新增商品分类
     * @param categoryAddDTO 新增参数
     */
    void insertCategory(GoodsCategoryAddDTO categoryAddDTO);

    /**
     * 编辑商品分类
     * @param categoryUpdateDTO 编辑参数
     */
    void updateCategory(GoodsCategoryUpdateDTO categoryUpdateDTO);

    /**
     * 删除商品分类
     * @param categoryDeleteDTO 删除参数
     */
    void deleteCategory(GoodsCategoryDeleteDTO categoryDeleteDTO);

    /**
     * 根据ID查询分类详情
     * @param id 分类ID
     * @return 分类详情
     */
    GoodsCategory selectCategoryById(@Param("id") Long id);

    /**
     * 查询指定父分类下的子分类数量
     * @param parentId 父分类ID
     * @return 子分类数量
     */
    Integer countChildCategory(@Param("parentId") Long parentId);
}