package com.kingso.ecommerce.module.express.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.kingso.ecommerce.module.express.dto.ExpressAddDTO;
import com.kingso.ecommerce.module.express.dto.ExpressDeleteDTO;
import com.kingso.ecommerce.module.express.dto.ExpressUpdateDTO;
import com.kingso.ecommerce.module.express.entity.Express;

/**
 * 快递公司 Mapper 接口
 */
@Mapper // 必须添加
public interface ExpressMapper {

    /**
     * 分页查询快递公司（原生SQL分页）
     * @param expressName 快递公司名称（模糊查询，可为null）
     * @param offset 偏移量（(pageNum-1)*pageSize）
     * @param pageSize 每页条数
     * @return 快递公司列表
     */
    List<Express> selectExpressPage(@Param("expressName") String expressName,
                                     @Param("offset") Integer offset,
                                     @Param("pageSize") Integer pageSize);

    /**
     * 查询快递公司总条数
     * @param expressName 快递公司名称（模糊查询，可为null）
     * @return 总记录数
     */
    Long selectExpressTotal(@Param("expressName") String expressName);

    /**
     * 新增快递公司
     * @param expressAddDTO 新增参数
     */
    void insertExpress(ExpressAddDTO expressAddDTO);

    /**
     * 编辑快递公司
     * @param expressUpdateDTO 编辑参数
     */
    void updateExpress(ExpressUpdateDTO expressUpdateDTO);

    /**
     * 删除快递公司
     * @param expressDeleteDTO 删除参数
     */
    void deleteExpress(ExpressDeleteDTO expressDeleteDTO);

    /**
     * 根据ID查询快递公司详情
     * @param id 快递公司ID
     * @return 快递公司详情
     */
    Express selectExpressById(@Param("id") Integer id);
}

