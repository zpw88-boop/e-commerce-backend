// 主启动类包路径：com.kingso.ecommerce（覆盖所有子包）
package com.kingso.ecommerce;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;

@ServletComponentScan
@SpringBootApplication // 包含@ComponentScan，默认扫描当前包及其子包
@MapperScan("com.kingso.ecommerce.module.*.mapper") // 扫描所有模块下的mapper包
public class EcommerceApplication {
    public static void main(String[] args) {
        SpringApplication.run(EcommerceApplication.class, args);
    }
}