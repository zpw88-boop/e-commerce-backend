// com/kingso/ecommerce/module/order/mapper/OrderMapper.java
package com.kingso.ecommerce.module.order.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.kingso.ecommerce.module.order.dto.OrderQueryDTO;
import com.kingso.ecommerce.module.order.entity.Order;

/**
 * 订单Mapper接口（映射tb_order表）
 */
@Mapper
public interface OrderMapper {
    /**
     * 新增订单（获取自增ID）
     */
    void insert(Order order);

    /**
     * 根据ID更新订单
     */
    void updateById(Order order);

    /**
     * 根据ID删除订单
     */
    void deleteById(Long id);

    /**
     * 根据ID查询订单
     */
    Order selectById(Long id);

    /**
     * 根据订单编号查询订单
     */
    Order selectByOrderNo(String orderNo);

    /**
     * 分页查询订单列表（多条件筛选）
     */
    List<Order> selectPage(OrderQueryDTO queryDTO);

    /**
     * 查询订单总数（多条件筛选，用于分页）
     */
    Integer selectTotal(OrderQueryDTO queryDTO);
}