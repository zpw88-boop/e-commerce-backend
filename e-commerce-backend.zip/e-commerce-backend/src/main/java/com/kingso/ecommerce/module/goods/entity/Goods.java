package com.kingso.ecommerce.module.goods.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.Data;

/**
 * 商品实体类，对应数据库goods表
 * 原生MyBatis中，表名在XML映射文件中指定，主键自增配置在XML的insert标签中
 */
@Data // 保留Lombok注解，简化getter/setter等方法
public class Goods {
    /**
     * 商品主键ID
     * 原生MyBatis中，主键自增通过XML的useGeneratedKeys="true" keyProperty="id"配置
     */
    private Long id;

    /**
     * 商品名称
     * 驼峰命名goodsName，对应数据库goods_name（application.yml中已开启驼峰转下划线）
     */
    private String goodsName;

    /**
     * 商品价格
     * 使用BigDecimal类型，避免浮点型精度丢失问题
     */
    private BigDecimal goodsPrice;

    /**
     * 商品库存
     */
    private Integer stock;

    /**
     * 分类ID（关联cat表）
     */
    private Long categoryId;

    /**
     * 商品图片地址
     */
    private String goodsImg;

    /**
     * 商品状态：0=下架，1=上架
     */
    private Integer status;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
    private String barCode;
}