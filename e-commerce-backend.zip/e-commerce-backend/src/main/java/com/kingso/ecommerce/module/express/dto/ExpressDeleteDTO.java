package com.kingso.ecommerce.module.express.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 快递公司删除DTO
 */
@Data
public class ExpressDeleteDTO {
    /**
     * 快递公司ID（必填）
     */
    @NotNull(message = "快递公司ID不能为空")
    private Integer id;
}

