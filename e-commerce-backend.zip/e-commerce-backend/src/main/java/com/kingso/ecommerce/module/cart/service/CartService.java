package com.kingso.ecommerce.module.cart.service;

import java.util.List;

import com.kingso.ecommerce.module.cart.dto.CartAddDTO;
import com.kingso.ecommerce.module.cart.dto.CartDeleteDTO;
import com.kingso.ecommerce.module.cart.dto.CartUpdateDTO;
import com.kingso.ecommerce.module.cart.entity.Cart;

/**
 * 购物车服务接口
 */
public interface CartService {
    /**
     * 新增购物车
     */
    void addCart(CartAddDTO cartAddDTO);

    /**
     * 查询用户购物车列表
     */
    List<Cart> getCartList(Long userId);

    /**
     * 更新购物车数量
     */
    void updateCartNum(CartUpdateDTO cartUpdateDTO);

    /**
     * 删除购物车商品
     */
    void deleteCart(CartDeleteDTO cartDeleteDTO);
}