// com/kingso/ecommerce/module/warehouse/service/WarehouseService.java
package com.kingso.ecommerce.module.warehouse.service;

import java.util.Map;

import com.kingso.ecommerce.module.warehouse.dto.WarehouseAddDTO;
import com.kingso.ecommerce.module.warehouse.dto.WarehouseQueryDTO;
import com.kingso.ecommerce.module.warehouse.dto.WarehouseUpdateDTO;
import com.kingso.ecommerce.module.warehouse.entity.Warehouse;

/**
 * 仓库服务接口
 */
public interface WarehouseService {
    /**
     * 新增仓库
     */
    void addWarehouse(WarehouseAddDTO addDTO);

    /**
     * 更新仓库
     */
    void updateWarehouse(WarehouseUpdateDTO updateDTO);

    /**
     * 根据ID删除仓库
     */
    void deleteWarehouse(Long id);

    /**
     * 根据ID查询仓库
     */
    Warehouse getWarehouseById(Long id);

    /**
     * 分页查询仓库列表（返回列表+总数）
     */
    Map<String, Object> getWarehousePage(WarehouseQueryDTO queryDTO);
}