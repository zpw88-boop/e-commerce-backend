package com.kingso.ecommerce.module.goodsCategory.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 商品分类删除DTO
 */
@Data
public class GoodsCategoryDeleteDTO {
    /**
     * 分类ID（必填）
     */
    @NotNull(message = "分类ID不能为空")
    private Long id;
}