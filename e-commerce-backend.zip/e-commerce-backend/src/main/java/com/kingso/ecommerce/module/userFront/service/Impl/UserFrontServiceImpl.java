package com.kingso.ecommerce.module.userFront.service.Impl;

import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;

import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.kingso.ecommerce.module.userAdmin.entity.User;
import com.kingso.ecommerce.module.userFront.dto.UserFrontQueryDTO;
import com.kingso.ecommerce.module.userFront.dto.UserRegisterDTO;
import com.kingso.ecommerce.module.userFront.dto.UserUpdateSelfDTO;
import com.kingso.ecommerce.module.userFront.mapper.UserFrontMapper;
import com.kingso.ecommerce.module.userFront.service.UserFrontService;

/**
 * 前台用户业务实现类
 */
@Service
public class UserFrontServiceImpl implements UserFrontService {

    private final UserFrontMapper userFrontMapper; 

    // 构造器注入（注入UserFrontMapper，与变量名一致）
    public UserFrontServiceImpl(UserFrontMapper userFrontMapper) {
        this.userFrontMapper = userFrontMapper;
    }

    /**
     * 前台用户注册
     */
    @Override
    public void register(UserRegisterDTO registerDTO) {
        // 用户名唯一性校验 调用Mapper的selectUserByUsername
        User existUserByUsername = userFrontMapper.selectUserByUsername(registerDTO.getUsername());
        Assert.isNull(existUserByUsername, "用户名已被占用");

        // 手机号唯一性校验  调用Mapper的selectUserByPhone
        User existUserByPhone = userFrontMapper.selectUserByPhone(registerDTO.getPhone());
        Assert.isNull(existUserByPhone, "手机号已被注册");

        // 构建UserRegisterDTO（直接传递给Mapper，无需构建User实体，避免参数不匹配）
        // 补充密码加密（与原有逻辑一致）
        String encryptPwd = nativeMd5Encrypt(registerDTO.getPassword() + "e-commerce-salt");
        registerDTO.setPassword(encryptPwd);

        if (Objects.isNull(registerDTO.getAvatar()) || registerDTO.getAvatar().trim().isEmpty()) {
            registerDTO.setAvatar("https://static.xxx.com/default-avatar.png");
        }

        // 插入数据库 调用Mapper的insertUser
        userFrontMapper.insertUser(registerDTO);
    }

    /**
     * 修改自身信息
     */
    @Override
    public void updateSelf(UserUpdateSelfDTO updateSelfDTO) {
        // 1. 校验用户是否存在 调用Mapper的selectUserById
        User existUser = userFrontMapper.selectUserById(updateSelfDTO.getId());
        Assert.notNull(existUser, "用户不存在");

        // 2. 手机号唯一性校验（排除自身）调用Mapper的selectUserByPhone
        if (Objects.nonNull(updateSelfDTO.getPhone()) && !updateSelfDTO.getPhone().trim().isEmpty()) {
            User existUserByPhone = userFrontMapper.selectUserByPhone(updateSelfDTO.getPhone());
            if (Objects.nonNull(existUserByPhone) && !existUserByPhone.getId().equals(updateSelfDTO.getId())) {
                throw new IllegalArgumentException("手机号已被其他用户注册");
            }
        }
        userFrontMapper.updateUserSelf(updateSelfDTO);
    }

    /**
     * 获取当前登录用户信息
     */
    @Override
    public User getCurrentUserInfo() {
        Long mockLoginUserId = 1L;
        User user = userFrontMapper.selectUserById(mockLoginUserId);
        Assert.notNull(user, "用户未登录或账号不存在");
        user.setPassword(null); // 隐藏密码
        return user;
    }

    /**
     * 根据用户ID获取用户信息
     */
    @Override
    public User getUserById(Long userId) {
        Assert.notNull(userId, "用户ID不能为空");
        User user = userFrontMapper.selectUserById(userId);
        Assert.notNull(user, "用户不存在");
        user.setPassword(null); // 隐藏密码
        return user;
    }

    /**
     * 分页查询用户列表
     */
    @Override
    public Map<String, Object> getUserPage(UserFrontQueryDTO queryDTO) {
        // 计算分页偏移量（pageNum从1开始 偏移量= (pageNum-1)*pageSize）
        int offset = (queryDTO.getPageNum() - 1) * queryDTO.getPageSize();

        //  新建查询对象，复制所有查询参数
        UserFrontQueryDTO query = new UserFrontQueryDTO();
        query.setUsername(queryDTO.getUsername());
        query.setPhone(queryDTO.getPhone()); 
        query.setNickname(queryDTO.getNickname()); 
        query.setStatus(queryDTO.getStatus());
        query.setPageNum(offset); // 偏移量（用于LIMIT）
        query.setPageSize(queryDTO.getPageSize());

        // 查询列表和总数
        List<User> userList = userFrontMapper.selectPage(query); 
        Integer total = userFrontMapper.selectTotal(query); 

        // 封装分页结果
        Map<String, Object> result = new HashMap<>();
        result.put("list", userList);
        result.put("total", total);
        result.put("pageNum", queryDTO.getPageNum()); // 原始页码
        result.put("pageSize", queryDTO.getPageSize());
        return result;
    }

    private String nativeMd5Encrypt(String content) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
            byte[] encryptBytes = md.digest(content.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : encryptBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("密码MD5加密失败（找不到MD5算法）", e);
        }
    }

    private String nativeGenerate6DigitRandomNum() {
        Random random = new Random();
        return String.format("%06d", random.nextInt(1000000));
    }
}