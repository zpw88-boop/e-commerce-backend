package com.kingso.ecommerce.module.procurement.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.kingso.ecommerce.common.result.Result;
import com.kingso.ecommerce.module.procurement.dto.ProcurementOrderAddDTO;
import com.kingso.ecommerce.module.procurement.dto.ProcurementOrderQueryDTO;
import com.kingso.ecommerce.module.procurement.entity.ProcurementOrder;
import com.kingso.ecommerce.module.procurement.entity.ProcurementOrderItem;
import com.kingso.ecommerce.module.procurement.service.ProcurementOrderService;

/**
 * 采购入库控制器
 * 接口前缀：/api/admin/procurement
 */
@RestController
@RequestMapping("/api/admin/procurement")
public class ProcurementController {
    private static final Logger log = LoggerFactory.getLogger(ProcurementController.class);

    private final ProcurementOrderService procurementOrderService;
    @Value("${customs.file.upload.path}")
    private String customsFileUploadPath;

    public ProcurementController(ProcurementOrderService procurementOrderService) {
        this.procurementOrderService = procurementOrderService;
    }
    /**
     * 海关文件上传
     */

    @PostMapping("/uploadCustomsFile")
    public Result<String> uploadCustomsFile(@RequestParam("file") MultipartFile file) {
        // 基础校验
        if (file.isEmpty()) {
            log.warn("上传文件为空 - 文件大小: {} bytes", file.getSize());
            return Result.fail("上传文件不能为空");
        }
        
        // 获取文件信息
        String originalFilename = file.getOriginalFilename();
        long fileSize = file.getSize();
        String contentType = file.getContentType();
        String paramName = file.getName();
        
        // // 记录诊断信息
        // log.info("========== 文件上传诊断信息 ==========");
        // log.info("原始文件名: {}", originalFilename);
        // log.info("文件大小: {} bytes ({} MB)", fileSize, fileSize / (1024.0 * 1024.0));
        // log.info("内容类型: {}", contentType);
        // log.info("参数名: {}", paramName);
        // log.info("是否为空: {}", file.isEmpty());
        // log.info("==================================");
        
        // 检查文件名是否为空
        if (originalFilename == null || originalFilename.trim().isEmpty()) {
            log.warn("原始文件名为空，但文件大小: {} bytes", fileSize);
            log.warn("这可能是因为：");
            log.warn("- 1. 客户端没有正确设置文件名");
            log.warn("- 2. 使用了某些不传递文件名的工具");
            log.warn("- 3. 文件被Spring拦截");
            
            // 如果文件名为空，使用默认文件名
            originalFilename = "unknown_file_" + System.currentTimeMillis();
        }
        
        try {
            // 确保上传目录存在且有权限
            File uploadDir = new File(customsFileUploadPath);
            log.info("上传目录路径: {}", uploadDir.getAbsolutePath());
            
            if (!uploadDir.exists()) {
                log.info("创建上传目录: {}", customsFileUploadPath);
                boolean created = uploadDir.mkdirs();
                if (!created) {
                    log.error("创建上传目录失败: {}", customsFileUploadPath);
                    return Result.fail("创建上传目录失败");
                }
                log.info("目录创建成功");
            }
            
            // 检查目录权限
            if (!uploadDir.canWrite()) {
                log.error("上传目录不可写: {}", customsFileUploadPath);
                return Result.fail("服务器存储目录不可写");
            }
            
            // 生成唯一文件名
            String fileExt = "";
            if (StringUtils.hasText(originalFilename)) {
                int lastDotIndex = originalFilename.lastIndexOf(".");
                if (lastDotIndex > 0 && lastDotIndex < originalFilename.length() - 1) {
                    fileExt = originalFilename.substring(lastDotIndex);
                    log.info("提取文件扩展名: {}", fileExt);
                }
            }
            
            String fileName = UUID.randomUUID().toString() + fileExt;
            log.info("生成唯一文件名: {}", fileName);
            
            // 保存文件
            File destFile = new File(customsFileUploadPath + File.separator + fileName);
            log.info("目标文件路径: {}", destFile.getAbsolutePath());
            
            // 检查目标文件是否已存在（理论上UUID不会重复，但以防万一）
            if (destFile.exists()) {
                log.warn("文件已存在，重新生成文件名");
                fileName = UUID.randomUUID().toString() + fileExt;
                destFile = new File(customsFileUploadPath + File.separator + fileName);
            }
            
            // 执行文件保存
            file.transferTo(destFile);
            
            // 验证文件是否保存成功
            if (!destFile.exists()) {
                log.error("文件保存后不存在: {}", destFile.getAbsolutePath());
                return Result.fail("文件保存失败");
            }
            
            long savedSize = destFile.length();
            log.info("文件保存成功，保存大小: {} bytes", savedSize);
            
            // 验证文件大小是否匹配
            if (savedSize != fileSize) {
                log.warn("文件大小不匹配：原始 {} bytes，保存后 {} bytes", fileSize, savedSize);
                if (savedSize == 0) {
                    log.error("保存的文件大小为0，可能是保存失败");
                    if (destFile.delete()) {
                        log.info("已删除大小为0的无效文件");
                    }
                    return Result.fail("文件保存失败，文件大小为0");
                }
            }
            
            // 返回成功结果
            log.info("文件上传成功: {} -> {}", originalFilename, destFile.getAbsolutePath());
            return Result.success(fileName, "文件上传成功");
            
        } catch (IOException e) {
            log.error("文件上传失败: {}", e.getMessage(), e);
            return Result.fail("文件上传失败：" + e.getMessage());
        } catch (Exception e) {
            log.error("文件上传过程中发生未知错误: {}", e.getMessage(), e);
            return Result.fail("文件上传失败：" + e.getMessage());
        }
    }
    /**
     * 创建采购订单（适配DTO修改：商品ID必传、条码可选）
     */
    @PostMapping("/create")
    public Result<Boolean> createProcurementOrder(
            @RequestBody @Validated ProcurementOrderAddDTO addDTO,
            BindingResult bindingResult
    ) {
        if (bindingResult.hasErrors()) {
            return Result.fail(buildErrorMsg(bindingResult));
        }
        procurementOrderService.createProcurementOrder(addDTO);
        return Result.success(true, "采购入库成功");
    }

    /**
     * 条码模糊查询采购明细
     */
    @GetMapping("/item/barcode")
    public Result<List<ProcurementOrderItem>> queryItemByBarcode(@RequestParam String barcode) {
        if (!StringUtils.hasText(barcode)) {
            return Result.fail("条码不能为空");
        }
        List<ProcurementOrderItem> itemList = procurementOrderService.queryItemByBarcodeLike(barcode);
        return Result.success(itemList, "条码模糊查询成功");
    }
    /**
     * 根据ID查询采购订单
     */
    @GetMapping("/{id}")
    public Result<ProcurementOrder> getById(@PathVariable Long id) {
        if (id == null || id <= 0) {
            return Result.fail("采购订单ID必须为正整数");
        }
        ProcurementOrder order = procurementOrderService.getById(id);
        return Result.success(order, "采购订单查询成功");
    }

    /**
     * 根据ID查询采购订单及明细
     */
    @GetMapping("/withItems/{id}")
    public Result<Map<String, Object>> getWithItemsById(@PathVariable Long id) {
        if (id == null || id <= 0) {
            return Result.fail("采购订单ID必须为正整数");
        }
        Map<String, Object> result = procurementOrderService.getWithItemsById(id);
        return Result.success(result, "采购订单及明细查询成功");
    }

    /**
     * 分页查询采购订单列表
     */
    @GetMapping("/page")
    public Result<Map<String, Object>> getPage(ProcurementOrderQueryDTO queryDTO) {
        Map<String, Object> pageResult = procurementOrderService.getPage(queryDTO);
        return Result.success(pageResult, "采购订单列表查询成功");
    }

    /**
     * 构建参数校验错误信息
     */
    private String buildErrorMsg(BindingResult bindingResult) {
        return bindingResult.getFieldErrors().stream()
                .map(FieldError::getDefaultMessage)
                .reduce((msg1, msg2) -> msg1 + "；" + msg2)
                .orElse("参数校验失败");
    }
    
}