package com.kingso.ecommerce.module.goodsCategory.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 商品分类编辑DTO
 */
@Data
public class GoodsCategoryUpdateDTO {
    /**
     * 分类ID（必填）
     */
    @NotNull(message = "分类ID不能为空")
    private Long id;

    /**
     * 分类名称（必填）
     */
    @NotBlank(message = "分类名称不能为空")
    private String categoryName;

    /**
     * 父分类ID（默认0：一级分类）
     */
    @NotNull(message = "父分类ID不能为空")
    private Long parentId = 0L;

    /**
     * 排序号（默认0）
     */
    private Integer sort = 0;

    /**
     * 状态（0：禁用，1：正常，默认1）
     */
    @NotNull(message = "分类状态不能为空")
    private Integer status = 1;
}