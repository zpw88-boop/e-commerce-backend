// com/kingso/ecommerce/module/order/entity/OrderItem.java
package com.kingso.ecommerce.module.order.entity;

import java.math.BigDecimal;

import lombok.Data;

/**
 * 订单明细实体类（映射tb_order_item表）
 */
@Data
public class OrderItem {
    /**
     * 订单明细ID（主键，自增）
     */
    private Long id;

    /**
     * 订单ID（关联tb_order.id）
     */
    private Long orderId;

    /**
     * 商品ID
     */
    private Long goodsId;

    /**
     * 商品名称（下单时快照，不随商品信息变更）
     */
    private String goodsName;

    /**
     * 商品单价（下单时快照）
     */
    private BigDecimal goodsPrice;

    /**
     * 商品数量
     */
    private Integer num;

    /**
     * 该商品总金额（goods_price * num）
     */
    private BigDecimal totalPrice;

    /**
     * 仓库ID（关联仓库表）
     */
    private Integer warehouseId;
}