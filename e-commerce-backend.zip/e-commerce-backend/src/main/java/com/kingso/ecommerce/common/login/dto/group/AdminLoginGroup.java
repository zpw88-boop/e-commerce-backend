package com.kingso.ecommerce.common.login.dto.group;

/**
 * 管理员登录校验分组（前台登录无需此分组，用于差异化校验，预留扩展）
 * 示例：后台登录需验证码，前台无需，可通过该分组控制校验规则
 */
public interface AdminLoginGroup {
}