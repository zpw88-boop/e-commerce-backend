// com/kingso/ecommerce/module/user/dto/UserAddDTO.java
package com.kingso.ecommerce.module.userAdmin.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

/**
 * 新增用户参数DTO
 */
@Data
public class UserAddDTO {
    /**
     * 用户名（非空，2-20位）
     */
    @NotBlank(message = "用户名不能为空")
    @Pattern(regexp = "^.{2,20}$", message = "用户名长度必须为2-20位")
    private String username;

    /**
     * 密码（非空，6-20位）
     */
    @NotBlank(message = "密码不能为空")
    @Pattern(regexp = "^.{6,20}$", message = "密码长度必须为6-20位")
    private String password;

    /**
     * 手机号（11位数字）
     */
    @Pattern(regexp = "^1[3-9]\\d{9}$", message = "手机号格式不正确")
    private String phone;

    /**
     * 邮箱（格式校验）
     */
    @Email(message = "邮箱格式不正确")
    private String email;

    /**
     * 状态（0-禁用，1-正常，默认1）
     */
    private Integer status = 1;

    /**
     * 用户类型（1-普通用户，0-管理员，默认0）
     * 可根据业务需求调整类型含义和默认值
     */
    private Integer userType = 0;
}