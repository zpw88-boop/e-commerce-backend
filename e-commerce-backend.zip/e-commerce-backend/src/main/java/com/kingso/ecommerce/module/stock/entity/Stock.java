package com.kingso.ecommerce.module.stock.entity;

import java.time.LocalDateTime;

import lombok.Data;

/**
 * 库存表实体（tb_stock）
 * 对齐userAdmin的User实体风格
 */
@Data
public class Stock {
    /** 库存ID */
    private Long id;
    /** 商品ID */
    private Long goodsId;
    /** 库存数量 */
    private Integer stockNum;
    /** 锁定库存（下单未支付） */
    private Integer lockNum;
    /** 更新时间 */
    private LocalDateTime updateTime;
    /** 仓库ID（关联warehouse_dict.id） */
    private Long warehouseId;
    /** 长度≤30字 */
    private String warehouseArea;
}