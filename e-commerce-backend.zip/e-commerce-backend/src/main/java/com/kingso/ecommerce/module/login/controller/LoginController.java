package com.kingso.ecommerce.module.login.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kingso.ecommerce.common.jwt.NoAuth;
import com.kingso.ecommerce.common.login.dto.LoginReqDTO;
import com.kingso.ecommerce.common.login.dto.LoginRespVO;
import com.kingso.ecommerce.common.login.exception.LoginFailedException;
import com.kingso.ecommerce.common.result.Result;
import com.kingso.ecommerce.module.login.service.AuthService;


@RestController
@RequestMapping("/api/auth") // 接口前缀，可根据你的需求调整
public class LoginController {

    @Autowired
    private AuthService authService;

    /**
     * 用户登录接口（前后台通用，仅需传递不同的userType）
     * @param loginReqDTO 登录请求参数（自动校验，不符合规则返回异常提示）
     * @return Result<LoginRespVO> 统一响应格式
     */
    @NoAuth
    @PostMapping("/login")
    public Result<LoginRespVO> login(@Validated @RequestBody LoginReqDTO loginReqDTO) {
        try {
            // 调用业务层登录方法
            LoginRespVO loginRespVO = authService.login(loginReqDTO);
            // 返回成功结果
            return Result.success(loginRespVO, "登录成功");
        } catch (LoginFailedException e) {
            // 捕获登录异常，返回失败提示
            return Result.fail(e.getMessage());
        }
    }
}