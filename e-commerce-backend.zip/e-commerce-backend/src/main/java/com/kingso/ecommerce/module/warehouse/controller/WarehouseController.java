// com/kingso/ecommerce/module/warehouse/controller/WarehouseController.java
package com.kingso.ecommerce.module.warehouse.controller;

import java.util.Map;

import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kingso.ecommerce.common.result.Result;
import com.kingso.ecommerce.module.warehouse.dto.WarehouseAddDTO;
import com.kingso.ecommerce.module.warehouse.dto.WarehouseQueryDTO;
import com.kingso.ecommerce.module.warehouse.dto.WarehouseUpdateDTO;
import com.kingso.ecommerce.module.warehouse.entity.Warehouse;
import com.kingso.ecommerce.module.warehouse.service.WarehouseService;

/**
 * 仓库管理接口控制器
 * 接口前缀：/warehouse
 */
@RestController
@RequestMapping("/api/admin/warehouses")
public class WarehouseController {

    private final WarehouseService warehouseService;

    // 构造器注入
    public WarehouseController(WarehouseService warehouseService) {
        this.warehouseService = warehouseService;
    }

    /**
     * 新增仓库
     */
    @PostMapping("/add")
    public Result<Boolean> addWarehouse(
            @RequestBody @Validated WarehouseAddDTO addDTO,
            BindingResult bindingResult
    ) {
        // 参数校验错误处理
        if (bindingResult.hasErrors()) {
            return Result.fail(buildErrorMsg(bindingResult));
        }
        warehouseService.addWarehouse(addDTO);
        return Result.success(true, "仓库新增成功");
    }

    /**
     * 更新仓库
     */
    @PutMapping("/update")
    public Result<Boolean> updateWarehouse(
            @RequestBody @Validated WarehouseUpdateDTO updateDTO,
            BindingResult bindingResult
    ) {
        if (bindingResult.hasErrors()) {
            return Result.fail(buildErrorMsg(bindingResult));
        }
        warehouseService.updateWarehouse(updateDTO);
        return Result.success(true, "仓库更新成功");
    }

    /**
     * 删除仓库
     */
    @DeleteMapping("/delete/{id}")
    public Result<Boolean> deleteWarehouse(@PathVariable Long id) {
        if (id == null || id <= 0) {
            return Result.fail("仓库ID必须为正整数");
        }
        warehouseService.deleteWarehouse(id);
        return Result.success(true, "仓库删除成功");
    }

    /**
     * 根据ID查询仓库
     */
    @GetMapping("/{id}")
    public Result<Warehouse> getWarehouseById(@PathVariable Long id) {
        if (id == null || id <= 0) {
            return Result.fail("仓库ID必须为正整数");
        }
        Warehouse warehouse = warehouseService.getWarehouseById(id);
        return Result.success(warehouse, "仓库查询成功");
    }

    /**
     * 分页查询仓库列表
     */
    @GetMapping("/page")
    public Result<Map<String, Object>> getWarehousePage(WarehouseQueryDTO queryDTO) {
        Map<String, Object> pageResult = warehouseService.getWarehousePage(queryDTO);
        return Result.success(pageResult, "仓库列表查询成功");
    }

    // 构建参数校验错误信息
    private String buildErrorMsg(BindingResult bindingResult) {
        return bindingResult.getFieldErrors().stream()
                .map(FieldError::getDefaultMessage)
                .reduce((msg1, msg2) -> msg1 + "；" + msg2)
                .orElse("参数校验失败");
    }
}