package com.kingso.ecommerce.module.goodsFront.dto;

import java.math.BigDecimal;
import java.math.RoundingMode;

import lombok.Data;

@Data
public class GoodsFrontQueryDTO {
    private Integer pageNum = 1;
    private Integer pageSize = 10;
    private Integer offset;
    private String goodsName;
    private Long categoryId;
    private Integer status;

    private BigDecimal minPrice;
    private BigDecimal maxPrice;
    private String barCode;
    private Integer stockNum;
    private Long warehouseId;
    private String warehouseArea;

    public void setMinPrice(Object minPrice) {
        if (minPrice == null) {
            this.minPrice = null;
        } else if (minPrice instanceof Integer intVal) {
            this.minPrice = BigDecimal.valueOf(intVal)
                    .setScale(2, RoundingMode.HALF_UP);
        } else if (minPrice instanceof String strVal) {
            String trimStr = strVal.trim();
            if (!trimStr.isEmpty()) {
                try {
                    this.minPrice = new BigDecimal(trimStr)
                            .setScale(2, RoundingMode.HALF_UP);
                } catch (Exception e) {
                    this.minPrice = null;
                }
            } else {
                this.minPrice = null;
            }
        } else if (minPrice instanceof BigDecimal bdVal) {
            this.minPrice = bdVal.setScale(2, RoundingMode.HALF_UP);
        } else {
            this.minPrice = null;
        }
        if (this.minPrice != null && this.minPrice.compareTo(BigDecimal.ZERO) < 0) {
            this.minPrice = null;
        }
    }

    public void setMaxPrice(Object maxPrice) {
        if (maxPrice == null) {
            this.maxPrice = null;
        } else if (maxPrice instanceof Integer intVal) {
            this.maxPrice = BigDecimal.valueOf(intVal)
                    .setScale(2, RoundingMode.HALF_UP);
        } else if (maxPrice instanceof String strVal) {
            String trimStr = strVal.trim();
            if (!trimStr.isEmpty()) {
                try {
                    this.maxPrice = new BigDecimal(trimStr)
                            .setScale(2, RoundingMode.HALF_UP);
                } catch (Exception e) {
                    this.maxPrice = null;
                }
            } else {
                this.maxPrice = null;
            }
        } else if (maxPrice instanceof BigDecimal bdVal) {
            this.maxPrice = bdVal.setScale(2, RoundingMode.HALF_UP);
        } else {
            this.maxPrice = null;
        }
        if (this.maxPrice != null && this.maxPrice.compareTo(BigDecimal.ZERO) < 0) {
            this.maxPrice = null;
        }
    }
}

