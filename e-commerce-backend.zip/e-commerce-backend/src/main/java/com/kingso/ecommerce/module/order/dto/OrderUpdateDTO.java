// com/kingso/ecommerce/module/order/dto/OrderUpdateDTO.java
package com.kingso.ecommerce.module.order.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

/**
 * 更新订单参数DTO（与tb_order表字段对应）
 */
@Data
public class OrderUpdateDTO {
    /**
     * 订单ID（必传）
     */
    @NotNull(message = "订单ID不能为空")
    @Positive(message = "订单ID必须为正整数")
    private Long id;

    /**
     * 收货人姓名（可选）
     */
    private String receiverName;

    /**
     * 收货人手机号（可选）
     */
    private String receiverPhone;

    /**
     * 收货人地址（可选）
     */
    private String receiverAddress;

    /**
     * 订单状态（可选：0：待支付，1：待发货，2：待收货，3：已完成，9：已取消）
     */
    private Integer status;

    /**
     * 支付时间（可选，支付后更新）
     */
    private LocalDateTime payTime;

    /**
     * 收货时间（可选，收货后更新）
     */
    private LocalDateTime receiveTime;

    /**
     * 取消时间（可选，取消后更新）
     */
    private LocalDateTime cancelTime;

    /**
     * 订单总金额（可选，仅特殊场景修改）
     */
    private BigDecimal totalAmount;

    /**
     * 备注信息（可选）
     */
    private String remark;

    /**
     * 快递公司名称（可选）
     */
    private String expressName;

    /**
     * 快递公司ID（可选）
     */
    private Integer expressId;

    /**
     * 快递运营商（可选）
     */
    private Integer expressOperator;

    /**
     * 快递单号（可选）
     */
    private String expressNo;

    /**
     * 快递备注（可选）
     */
    private String expressRemark;
}