package com.kingso.ecommerce.module.express.entity;

import java.io.Serializable;

import lombok.Data;

/**
 * 快递公司实体类
 * 对应数据库表 tb_express_dict
 */
@Data
public class Express implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 快递公司ID
     */
    private Integer id;

    /**
     * 快递公司名称
     */
    private String expressName;

    /**
     * 状态
     */
    private String status;
}

