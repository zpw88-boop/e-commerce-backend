// com/kingso/ecommerce/module/user/service/UserService.java
package com.kingso.ecommerce.module.userAdmin.service;

import java.util.Map;

import com.kingso.ecommerce.module.userAdmin.dto.UserAddDTO;
import com.kingso.ecommerce.module.userAdmin.dto.UserQueryDTO;
import com.kingso.ecommerce.module.userAdmin.dto.UserUpdateDTO;
import com.kingso.ecommerce.module.userAdmin.entity.User;

/**
 * 用户服务接口
 */
public interface UserService {
    /**
     * 新增用户
     */
    void addUser(UserAddDTO addDTO);

    /**
     * 更新用户
     */
    void updateUser(UserUpdateDTO updateDTO);

    /**
     * 根据ID删除用户
     */
    void deleteUser(Long id);

    /**
     * 根据ID查询用户
     */
    User getUserById(Long id);

    /**
     * 分页查询用户列表（返回列表+总数）
     */
    Map<String, Object> getUserPage(UserQueryDTO queryDTO);
}