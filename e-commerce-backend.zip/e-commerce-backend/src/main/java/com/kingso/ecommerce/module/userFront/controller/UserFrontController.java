package com.kingso.ecommerce.module.userFront.controller;

import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kingso.ecommerce.common.result.Result;
import com.kingso.ecommerce.module.userAdmin.entity.User;
import com.kingso.ecommerce.module.userFront.dto.UserFrontQueryDTO;
import com.kingso.ecommerce.module.userFront.dto.UserRegisterDTO;
import com.kingso.ecommerce.module.userFront.dto.UserUpdateSelfDTO;
import com.kingso.ecommerce.module.userFront.service.UserFrontService;

/**
 * 前台用户接口控制器
 * 接口前缀：/api/user
 * 包路径：com.kingso.ecommerce.module.userFront.controller
 */
@RestController
@RequestMapping("/api/userfront")
public class UserFrontController {

    private final UserFrontService userFrontService;

    // 构造器注入
    public UserFrontController(UserFrontService userFrontService) {
        this.userFrontService = userFrontService;
    }

    /**
     * 前台用户注册
     */
    @PostMapping("/register")
    public Result<Boolean> register(
            @RequestBody @Validated UserRegisterDTO registerDTO,
            BindingResult bindingResult
    ) {
        // 参数校验错误处理
        if (bindingResult.hasErrors()) {
            String errorMsg = bindingResult.getFieldErrors().stream()
                    .map(FieldError::getDefaultMessage)
                    .collect(Collectors.joining("；"));
            return Result.fail(errorMsg);
        }
        userFrontService.register(registerDTO);
        return Result.success(true, "注册成功，请登录");
    }

    /**
     * 普通用户修改自身信息
     */
    @PutMapping("/update/self")
    public Result<Boolean> updateSelf(
            @RequestBody @Validated UserUpdateSelfDTO updateSelfDTO,
            BindingResult bindingResult
    ) {
        if (bindingResult.hasErrors()) {
            String errorMsg = bindingResult.getFieldErrors().stream()
                    .map(FieldError::getDefaultMessage)
                    .collect(Collectors.joining("；"));
            return Result.fail(errorMsg);
        }
        userFrontService.updateSelf(updateSelfDTO);
        return Result.success(true, "个人信息修改成功");
    }

    /**
     * 获取当前登录用户的信息
     */
    @GetMapping("/info")
    public Result<User> getCurrentUserInfo() {
        User user = userFrontService.getCurrentUserInfo();
        return Result.success(user, "用户信息查询成功");
    }

    /**
     * 根据用户ID获取用户信息
     */
    @GetMapping("/{userId}")
    public Result<User> getUserById(@PathVariable Long userId) {
        User user = userFrontService.getUserById(userId);
        return Result.success(user, "用户信息查询成功");
    }

    /**
     * 分页查询用户列表
     */
    @GetMapping("/page")
    public Result<Map<String, Object>> getUserPage(UserFrontQueryDTO queryDTO) {
        Map<String, Object> pageResult = userFrontService.getUserPage(queryDTO);
        return Result.success(pageResult, "用户列表查询成功");
    }

}