package com.kingso.ecommerce.common.enums;

import lombok.Getter;

/**
 * 用户类型枚举：区分管理员和客户用户
 */
@Getter
public enum UserTypeEnum {
    /**
     * 管理员
     */
    ADMIN("ADMIN", "管理员"),
    /**
     * 客户用户
     */
    USER("USER", "客户用户");

    /**
     * 类型编码（前后端传递的参数值）
     */
    private final String code;
    /**
     * 类型描述
     */
    private final String desc;

    UserTypeEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    /**
     * 根据编码获取枚举
     */
    public static UserTypeEnum getByCode(String code) {
        for (UserTypeEnum enumItem : UserTypeEnum.values()) {
            if (enumItem.getCode().equals(code)) {
                return enumItem;
            }
        }
        throw new IllegalArgumentException("无效的用户类型：" + code);
    }
}