package com.kingso.ecommerce.module.goodsFront.service;

import java.util.Map;

import com.kingso.ecommerce.module.goodsFront.dto.GoodsFrontQueryDTO;

public interface IGoodsFrontService {

    Map<String, Object> pageGoods(GoodsFrontQueryDTO goodsQueryDTO);
}

