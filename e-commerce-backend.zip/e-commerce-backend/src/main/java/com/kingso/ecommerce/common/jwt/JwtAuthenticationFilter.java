package com.kingso.ecommerce.common.jwt;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;

import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.method.HandlerMethod;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.kingso.ecommerce.common.result.Result;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtUtils jwtUtils;
    private final JwtProperties jwtProperties;
    private final ObjectMapper objectMapper;

    // 保留原有构造函数
    public JwtAuthenticationFilter(JwtUtils jwtUtils, JwtProperties jwtProperties, ObjectMapper objectMapper) {
        this.jwtUtils = jwtUtils;
        this.jwtProperties = jwtProperties;
        this.objectMapper = objectMapper;
    }

    public JwtProperties getJwtProperties() {
        return this.jwtProperties;
    }
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        String requestMethod = request.getMethod();
        String requestUri = request.getRequestURI();
        System.out.println("【JWT过滤器】收到请求：方法=" + requestMethod + "，路径=" + requestUri);
        
        // 放行 OPTIONS 预请求（原有逻辑，无修改）
        if (HttpMethod.OPTIONS.name().equalsIgnoreCase(requestMethod)) {
            System.out.println("【JWT过滤器】放行 OPTIONS 预请求：路径=" + requestUri);
            filterChain.doFilter(request, response);
            return;
        }

        // 放行忽略路径 + 带NoAuth注解的接口（原有逻辑，无修改）
        if (isIgnoreUrl(requestUri) || isNoAuthAnnotation(request)) {
            System.out.println("【JWT过滤器】放行忽略路径/无权限注解接口：路径=" + requestUri);
            filterChain.doFilter(request, response);
            return;
        }

        // 获取并校验Token
        String token = request.getHeader(JwtConstants.TOKEN_HEADER);
        System.out.println("【JWT过滤器】获取到的 Token 头：" + token);
        if (token == null || !token.startsWith(JwtConstants.TOKEN_PREFIX)) {
            System.out.println("【JWT过滤器】Token不存在，拦截请求：路径=" + requestUri);
            returnJson(response, Result.fail("请先登录（Token不存在）"));
            return;
        }

        // 截取Bearer后Token串并校验有效性
        token = token.substring(JwtConstants.TOKEN_PREFIX.length());
        if (!jwtUtils.validateToken(token)) {
            System.out.println("【JWT过滤器】Token过期/无效，拦截请求：路径=" + requestUri);
            returnJson(response, Result.fail("登录已过期，请重新登录"));
            return;
        }

        // Token校验通过，存储JwtUser到请求属性
        JwtUser jwtUser = jwtUtils.parseToken(token);
        request.setAttribute("jwtUser", jwtUser);
        System.out.println("【JWT过滤器】Token校验通过，放行请求：路径=" + requestUri);

        // 向Spring Security提交认证信息
        UsernamePasswordAuthenticationToken authenticationToken =
                new UsernamePasswordAuthenticationToken(jwtUser, null, Collections.emptyList());
        authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
        SecurityContextHolder.getContext().setAuthentication(authenticationToken);

        // 继续执行过滤器链
        filterChain.doFilter(request, response);
    }

    // 忽略路径校验逻辑完全保留，无修改
    private boolean isIgnoreUrl(String url) {
        if (jwtProperties.getIgnoreUrls() == null || jwtProperties.getIgnoreUrls().length == 0) {
            return false;
        }
        for (String ignoreUrl : jwtProperties.getIgnoreUrls()) {
            // 兼容**通配符转为正则匹配
            if (url.matches(ignoreUrl.replace("**", ".*"))) {
                return true;
            }
        }
        return false;
    }

    // NoAuth注解校验
    private boolean isNoAuthAnnotation(HttpServletRequest request) {
        try {
            Object handler = request.getAttribute("org.springframework.web.servlet.HandlerMapping.bestMatchingHandler");
            if (handler instanceof HandlerMethod handlerMethod) {
                return handlerMethod.hasMethodAnnotation(NoAuth.class);
            }
        } catch (Exception e) {
            // 异常返回false
            return false;
        }
        return false;
    }

    // JSON错误响应逻辑
    private void returnJson(HttpServletResponse response, Result<?> result) throws IOException {
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        response.setStatus(401);
        try (PrintWriter writer = response.getWriter()) {
            writer.write(objectMapper.writeValueAsString(result));
            writer.flush();
        }
    }
}