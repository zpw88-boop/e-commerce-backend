package com.kingso.ecommerce.module.login.service;

import com.kingso.ecommerce.common.login.dto.LoginReqDTO;
import com.kingso.ecommerce.common.login.dto.LoginRespVO;

/**
 * 登录业务接口（规范方法定义，便于后续扩展）
 */
public interface AuthService {
    /**
     * 用户登录核心方法
     * @param loginReqDTO 登录请求参数（复用common/login的DTO）
     * @return LoginRespVO 登录响应结果（复用common/login的VO）
     */
    LoginRespVO login(LoginReqDTO loginReqDTO);
}