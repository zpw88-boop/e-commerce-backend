package com.kingso.ecommerce.module.order.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.kingso.ecommerce.module.order.dto.OrderQueryDTO;
import com.kingso.ecommerce.module.order.entity.Order;

/**
 * 前台订单Mapper接口（关联查询订单主表和明细表）
 */
@Mapper
public interface OrderFrontMapper {
    /**
     * 分页查询订单列表（关联订单明细表，包含主表信息和明细信息）
     * @param queryDTO 查询参数（必须包含userId）
     * @return 订单列表
     */
    List<Order> selectPage(OrderQueryDTO queryDTO);

    /**
     * 查询订单总数（用于分页）
     * @param queryDTO 查询参数（必须包含userId）
     * @return 订单总数
     */
    Integer selectTotal(OrderQueryDTO queryDTO);
}

