// com/kingso/ecommerce/module/procurement/dto/ProcurementOrderAddDTO.java
package com.kingso.ecommerce.module.procurement.dto;

import java.util.List;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

/**
 * 新增采购订单参数DTO
 */
@Data
public class ProcurementOrderAddDTO {
    /**
     * 操作员ID（必传）
     */
    @NotNull(message = "操作员ID不能为空")
    @Positive(message = "操作员ID必须为正整数")
    private Long operatorId;

    /**
     * 入库仓库ID（必传）
     */
    @NotNull(message = "仓库ID不能为空")
    @Positive(message = "仓库ID必须为正整数")
    private Long warehouseId;

    /**
     * 海关文件地址（可选）
     */
    private String customsFileUrl;

    /**
     * 备注信息（可选）
     */
    private String remark;

    /**
     * 采购订单明细列表（必传，至少包含1条明细）
     */
    @NotNull(message = "采购订单明细不能为空")
    private List<ProcurementOrderItemAddDTO> itemList;
}