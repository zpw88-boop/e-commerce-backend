package com.kingso.ecommerce.module.goodsFront.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kingso.ecommerce.common.result.Result;
import com.kingso.ecommerce.module.goodsFront.dto.GoodsFrontQueryDTO;
import com.kingso.ecommerce.module.goodsFront.service.IGoodsFrontService;

/**
 * 商品前台API RESTful
 */
@RestController
@RequestMapping("/api/front/goods")
public class GoodsFrontController {
    
    private final IGoodsFrontService goodsService;

    public GoodsFrontController(IGoodsFrontService goodsService) {
        this.goodsService = goodsService;
    }

    @GetMapping("/page")
    public Result<?> pageGoods(GoodsFrontQueryDTO goodsQueryDTO) {
        return Result.success(goodsService.pageGoods(goodsQueryDTO), "商品分页查询成功");
    }
    
}