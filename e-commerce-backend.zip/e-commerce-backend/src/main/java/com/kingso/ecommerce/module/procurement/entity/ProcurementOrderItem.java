package com.kingso.ecommerce.module.procurement.entity;

import java.math.BigDecimal;

import lombok.Data;

/**
 * 采购订单明细实体类（映射tb_procurement_order_item表）
 */
@Data
public class ProcurementOrderItem {
    /**
     * 明细ID（主键，自增）
     */
    private Long id;

    /**
     * 采购订单ID（关联tb_procurement_order.id）
     */
    private Long procurementOrderId;

    /**
     * 商品名称
     */
    private String goodsName;

    /**
     * 商品条码
     */
    private String goodsBarcode;

    /**
     * 商品数量
     */
    private Integer quantity;

    /**
     * 采购金额
     */
    private BigDecimal procurementAmount;
     /** 商品ID */
    private Long goodsId;

    /** 仓库区域 */
    private String warehouseArea;
}