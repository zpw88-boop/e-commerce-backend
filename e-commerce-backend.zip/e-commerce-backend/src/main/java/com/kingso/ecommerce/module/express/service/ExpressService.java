package com.kingso.ecommerce.module.express.service;

import com.kingso.ecommerce.module.express.dto.ExpressAddDTO;
import com.kingso.ecommerce.module.express.dto.ExpressDeleteDTO;
import com.kingso.ecommerce.module.express.dto.ExpressPageDTO;
import com.kingso.ecommerce.module.express.dto.ExpressUpdateDTO;
import com.kingso.ecommerce.module.express.entity.Express;

/**
 * 快递公司 Service 接口
 */
public interface ExpressService {

    /**
     * 分页查询快递公司
     * @param pageNum 页码
     * @param pageSize 每页条数
     * @param expressName 快递公司名称（模糊查询，可为null）
     * @return 分页结果
     */
    ExpressPageDTO getExpressPage(Integer pageNum, Integer pageSize, String expressName);

    /**
     * 新增快递公司
     * @param expressAddDTO 新增参数
     */
    void addExpress(ExpressAddDTO expressAddDTO);

    /**
     * 编辑快递公司
     * @param expressUpdateDTO 编辑参数
     */
    void updateExpress(ExpressUpdateDTO expressUpdateDTO);

    /**
     * 删除快递公司
     * @param expressDeleteDTO 删除参数
     */
    void deleteExpress(ExpressDeleteDTO expressDeleteDTO);

    /**
     * 根据ID查询快递公司详情
     * @param id 快递公司ID
     * @return 快递公司详情
     */
    Express getExpressById(Integer id);
}

