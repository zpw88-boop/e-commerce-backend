package com.kingso.ecommerce.module.goodsFront.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kingso.ecommerce.module.goodsFront.dto.GoodsFrontQueryDTO;
import com.kingso.ecommerce.module.goodsFront.entity.GoodsFront;
import com.kingso.ecommerce.module.goodsFront.mapper.GoodsFrontMapper;
import com.kingso.ecommerce.module.goodsFront.service.IGoodsFrontService;

@Service
@Transactional
public class GoodsFrontServiceImpl implements IGoodsFrontService {

    private final GoodsFrontMapper goodsFrontMapper;

    public GoodsFrontServiceImpl(GoodsFrontMapper goodsFrontMapper) {
        this.goodsFrontMapper = goodsFrontMapper;
    }

    @Override
    public Map<String, Object> pageGoods(GoodsFrontQueryDTO goodsQueryDTO) {
        if (goodsQueryDTO.getPageNum() == null || goodsQueryDTO.getPageNum() < 1) {
            goodsQueryDTO.setPageNum(1);
        }
        if (goodsQueryDTO.getPageSize() == null || goodsQueryDTO.getPageSize() < 1) {
            goodsQueryDTO.setPageSize(10);
        }
        goodsQueryDTO.setOffset((goodsQueryDTO.getPageNum() - 1) * goodsQueryDTO.getPageSize());

        List<GoodsFront> goodsList = goodsFrontMapper.getGoodsList(goodsQueryDTO);
        Long total = goodsFrontMapper.getGoodsTotal(goodsQueryDTO);

        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("list", goodsList);
        resultMap.put("total", total);
        resultMap.put("pageNum", goodsQueryDTO.getPageNum());
        resultMap.put("pageSize", goodsQueryDTO.getPageSize());
        resultMap.put("totalPages", (total + goodsQueryDTO.getPageSize() - 1) / goodsQueryDTO.getPageSize());

        return resultMap;
    }
}

