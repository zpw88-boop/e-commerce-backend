package com.kingso.ecommerce.module.stock.dto;

import lombok.Data;

/**
 * 库存分页查询参数（对齐userAdmin的UserQueryDTO）
 */
@Data
public class StockQueryDTO {
    /** 页码（默认1） */
    private Integer pageNum = 1;
    /** 页大小（默认10） */
    private Integer pageSize = 10;
    /** 商品名称（模糊搜索） */
    private String goodsName;
    /** 仓库名称（模糊搜索） */
    private String warehouseName;
}