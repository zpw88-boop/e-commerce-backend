package com.kingso.ecommerce.module.goods.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.kingso.ecommerce.module.goods.dto.GoodsAddDTO;
import com.kingso.ecommerce.module.goods.dto.GoodsQueryDTO;
import com.kingso.ecommerce.module.goods.entity.Goods;

/**
 * 商品服务接口
 * 定义商品业务逻辑规范（包含前台+后台所有商品操作）
 */
public interface IGoodsService {
    /**
     * 新增商品（后台管理/前台）
     */
    void addGoods(GoodsAddDTO goodsAddDTO);

    /**
     * 上传商品图片（后台管理）
     */
    String uploadGoodsImg(MultipartFile file);

    /**
     * 根据ID查询商品（前台+后台）
     */
    Goods getGoodsById(Long id);

    /**
     * 条件查询商品列表（前台）
     */
    List<Goods> getGoodsList(GoodsQueryDTO goodsQueryDTO);

    /**
     * 分页查询商品（后台管理）
     */
    Map<String, Object> pageGoods(GoodsQueryDTO goodsQueryDTO);

    /**
     * 更新商品（后台管理，带独立ID参数）
     */
    void updateGoods(Long id, GoodsAddDTO goodsAddDTO);

    /**
     * 更新商品（前台/后台，单参数：ID包含在DTO中
     */
    void updateGoods(GoodsAddDTO goodsAddDTO);

    /**
     * 商品上下架（更新状态，后台管理）
     */
    void updateGoodsStatus(Long id, Integer status);

    /**
     * 删除商品（后台管理/前台）
     */
    void deleteGoods(Long id);
}