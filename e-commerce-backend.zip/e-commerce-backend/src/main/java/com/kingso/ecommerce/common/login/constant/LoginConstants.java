package com.kingso.ecommerce.common.login.constant;

/**
 * 登录通用常量（前后台所有登录场景复用，避免硬编码）
 * 字段值参考User.java的枚举类型字段（userType、status等）
 */
public class LoginConstants {
    /**
     * JWT Token前缀（前端请求头中携带时需拼接该前缀，如：Bearer xxxxxx）
     */
    public static final String JWT_TOKEN_PREFIX = "Bearer ";

    /**
     * 用户类型 - 普通用户（对应User.java的userType=0）
     */
    public static final Integer USER_TYPE_NORMAL = 0;

    /**
     * 用户类型 - VIP用户（对应User.java的userType=1）
     */
    public static final Integer USER_TYPE_VIP = 1;

    /**
     * 用户类型 - 管理员（扩展字段，对应User.java的role=ADMIN，便于后台登录区分）
     */
    public static final String USER_TYPE_ADMIN = "ADMIN";

    /**
     * 用户状态 - 正常（对应User.java的status=1）
     */
    public static final Integer USER_STATUS_NORMAL = 1;

    /**
     * 用户状态 - 禁用（对应User.java的status=0）
     */
    public static final Integer USER_STATUS_DISABLE = 0;

    /**
     * 登录请求头名称（前端携带Token的请求头，如：Authorization）
     */
    public static final String LOGIN_TOKEN_HEADER = "Authorization";
}