package com.kingso.ecommerce.common.jwt;

import java.security.Key;
import java.util.Date;

import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

/**
 * JWT工具类（生成、解析、验证token）
 */
@Component
public class JwtUtils {

    private final JwtProperties jwtProperties;
    private final Key secretKey;

    public JwtUtils(JwtProperties jwtProperties) {
        this.jwtProperties = jwtProperties;
        // 初始化签名密钥（使用HS256算法需256位密钥）
        this.secretKey = Keys.hmacShaKeyFor(jwtProperties.getSecret().getBytes());
    }
    public JwtProperties getJwtProperties() {
        return this.jwtProperties;
    }

    /**
     * 生成Token
     */
    public String generateToken(JwtUser jwtUser) {
        // 计算过期时间
        Date expireDate = new Date(System.currentTimeMillis() + jwtProperties.getExpireMs());
        return Jwts.builder()
                // 存入自定义用户信息：Payload
                .claim("id", jwtUser.getUserId())
                .claim("username", jwtUser.getUsername())
                .claim("role", jwtUser.getRole())
                .claim("userType", jwtUser.getUserType())
                // 签发时间
                .setIssuedAt(new Date())
                // 过期时间
                .setExpiration(expireDate)
                // 签名算法+密钥
                .signWith(secretKey, SignatureAlgorithm.HS256)
                .compact();
    }

    /**
     * 解析Token获取用户信息
     */
    public JwtUser parseToken(String token) {
        Claims claims = Jwts.parserBuilder()
                .setSigningKey(secretKey) //签名密钥
                .build()
                .parseClaimsJws(token)
                .getBody();
        //
        JwtUser jwtUser = new JwtUser();
        jwtUser.setUserId(claims.get("id", Long.class));
        jwtUser.setUsername(claims.get("username", String.class));
        jwtUser.setRole(claims.get("role", String.class));
        jwtUser.setUserType(claims.get("userType", Integer.class));

        return jwtUser;
    }

    /**
     * 验证Token有效性（未过期+签名正确）
     */
    public boolean validateToken(String token) {
    try {
            Jwts.parserBuilder()
                    .setSigningKey(secretKey)
                    .build()
                    .parseClaimsJws(token);
            return true;
        } catch (JwtException e) { // 捕获JWT相关的具体异常
            // 仅处理JWT解析异常（签名错误、过期、格式错误等）
            return false;
        }
    }
}