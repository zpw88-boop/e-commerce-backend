package com.kingso.ecommerce.module.goodsCategory.dto;

import java.util.List;

import com.kingso.ecommerce.module.goodsCategory.entity.GoodsCategory;

import lombok.Data;

/**
 * 商品分类分页结果DTO
 */
@Data
public class GoodsCategoryPageDTO {
    /**
     * 总记录数
     */
    private Long total;

    /**
     * 分页分类列表
     */
    private List<GoodsCategory> categoryList;
}